# Divergences from the independent expectation

One entry per (pair, mode) whose decision outcome is not `correct`, or whose
explanation missed an expected detail. Excerpts are the first lines of the raw report.

## `c_core.struct_append_field@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: rec Added_Field_And_Size extra
binary/low: rec DataType_Size 
source/low: rec Added_Field extra
```

## `c_core.struct_append_field@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: rec Added_Field_And_Size extra
binary/low: rec DataType_Size 
source/low: rec Added_Field extra
```

## `c_core.struct_append_field@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 2 Changed, 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
2 functions with some indirect sub-type change:
  [C] 'function void fill_rec(rec*, int)' at edit_seed.c:10:1 has some indirect sub-type changes:
    parameter 1 of type 'rec*' has sub-type changes:
      in pointed to type 'struct rec' at edit_seed.h:5:1:
        type size changed from 192 to 256 (in bits)
        1 data member insertion:
```

## `c_core.struct_append_field@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.struct_append_field@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: rec Added_Field_And_Size extra
binary/low: rec DataType_Size 
source/low: rec Added_Field extra
```

## `c_core.struct_append_field@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'size'] (expected {'entity': ['rec'], 'fields': ['extra'], 'functions': ['fill_rec', 'make_rec'], 'size': [24, 32]})

## `cxx_classes.struct_append_field@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['fill_rec', 'make_rec']})
```text
binary/low: rec Added_Field_And_Size extra
binary/low: rec DataType_Size 
source/low: rec Added_Field extra
```

## `cxx_classes.struct_append_field@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['fill_rec', 'make_rec']})
```text
binary/low: rec Added_Field_And_Size extra
binary/low: rec DataType_Size 
source/low: rec Added_Field extra
```

## `cxx_classes.struct_append_field@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 2 Changed, 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
2 functions with some indirect sub-type change:
  [C] 'function void fill_rec(rec*, int)' at edit_seed.cpp:13:1 has some indirect sub-type changes:
    parameter 1 of type 'rec*' has sub-type changes:
      in pointed to type 'struct rec' at edit_seed.h:5:1:
        type size changed from 192 to 256 (in bits)
        1 data member insertion:
```

## `cxx_classes.struct_append_field@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.struct_append_field@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['fill_rec', 'make_rec']})
```text
binary/low: rec Added_Field_And_Size extra
binary/low: rec DataType_Size 
source/low: rec Added_Field extra
```

## `cxx_classes.struct_append_field@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'size'] (expected {'entity': ['rec'], 'fields': ['extra'], 'functions': ['fill_rec', 'make_rec'], 'size': [24, 32]})

## `c_core.struct_remove_trailing_field@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 2 Changed, 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
2 functions with some indirect sub-type change:
  [C] 'function void fill_rec(rec*, int)' at edit_seed.c:10:1 has some indirect sub-type changes:
    parameter 1 of type 'rec*' has sub-type changes:
      in pointed to type 'struct rec' at edit_seed.h:5:1:
        type size changed from 192 to 128 (in bits)
        1 data member deletion:
```

## `c_core.struct_remove_trailing_field@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.struct_remove_trailing_field@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'size'] (expected {'entity': ['rec'], 'fields': ['tag'], 'functions': ['fill_rec', 'make_rec'], 'size': [24, 16]})

## `cxx_classes.struct_remove_trailing_field@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['fill_rec', 'make_rec']})
```text
binary/medium: rec Removed_Field_And_Size tag
binary/low: rec DataType_Size 
source/high: rec Removed_Field tag
```

## `cxx_classes.struct_remove_trailing_field@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['fill_rec', 'make_rec']})
```text
binary/medium: rec Removed_Field_And_Size tag
binary/low: rec DataType_Size 
source/high: rec Removed_Field tag
```

## `cxx_classes.struct_remove_trailing_field@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 2 Changed, 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
2 functions with some indirect sub-type change:
  [C] 'function void fill_rec(rec*, int)' at edit_seed.cpp:13:1 has some indirect sub-type changes:
    parameter 1 of type 'rec*' has sub-type changes:
      in pointed to type 'struct rec' at edit_seed.h:5:1:
        type size changed from 192 to 128 (in bits)
        1 data member deletion:
```

## `cxx_classes.struct_remove_trailing_field@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.struct_remove_trailing_field@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['fill_rec', 'make_rec']})
```text
binary/medium: rec Removed_Field_And_Size tag
binary/low: rec DataType_Size 
source/high: rec Removed_Field tag
```

## `cxx_classes.struct_remove_trailing_field@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'size'] (expected {'entity': ['rec'], 'fields': ['tag'], 'functions': ['fill_rec', 'make_rec'], 'size': [24, 16]})

## `c_core.struct_swap_fields@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function double scale(point, double)' at edit_seed.c:5:1 has some indirect sub-type changes:
    parameter 1 of type 'struct point' has sub-type changes:
      type size hasn't changed
      2 data member changes:
        'int x' offset changed from 0 to 32 (in bits) (by +32 bits)
```

## `c_core.struct_swap_fields@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.struct_swap_fields@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions', 'offsets'] (expected {'entity': ['point'], 'functions': ['scale'], 'offsets': ['x', 'y']})

## `cxx_classes.struct_swap_fields@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['scale']})
```text
binary/medium: point Moved_Field x
binary/medium: point Moved_Field y
source/safe: point Moved_Field x
source/safe: point Moved_Field y
```

## `cxx_classes.struct_swap_fields@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['scale']})
```text
binary/medium: point Moved_Field x
binary/medium: point Moved_Field y
source/safe: point Moved_Field x
source/safe: point Moved_Field y
```

## `cxx_classes.struct_swap_fields@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function double scale(point, double)' at edit_seed.cpp:7:1 has some indirect sub-type changes:
    parameter 1 of type 'struct point' has sub-type changes:
      type size hasn't changed
      2 data member changes:
        'int x' offset changed from 0 to 32 (in bits) (by +32 bits)
```

## `cxx_classes.struct_swap_fields@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.struct_swap_fields@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['scale']})
```text
binary/medium: point Moved_Field x
binary/medium: point Moved_Field y
source/safe: point Moved_Field x
source/safe: point Moved_Field y
```

## `cxx_classes.struct_swap_fields@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions', 'offsets'] (expected {'entity': ['point'], 'functions': ['scale'], 'offsets': ['x', 'y']})

## `c_core.struct_field_widen@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['size'] (expected {'size': [8, 16]})
```text
binary/high: point DataType_Size_And_Stack 
binary/medium: point Field_Type_And_Size_And_Layout_And_Type_Size x
source/low: point Field_Type x
```

## `c_core.struct_field_widen@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['size'] (expected {'size': [8, 16]})
```text
binary/high: point DataType_Size_And_Stack 
binary/medium: point Field_Type_And_Size_And_Layout_And_Type_Size x
source/low: point Field_Type x
```

## `c_core.struct_field_widen@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function double scale(point, double)' at edit_seed.c:5:1 has some indirect sub-type changes:
    parameter 1 of type 'struct point' has sub-type changes:
      type size changed from 64 to 128 (in bits)
      2 data member changes:
        type of 'int x' changed:
```

## `c_core.struct_field_widen@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.struct_field_widen@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['size'] (expected {'size': [8, 16]})
```text
binary/high: point DataType_Size_And_Stack 
binary/medium: point Field_Type_And_Size_And_Layout_And_Type_Size x
source/low: point Field_Type x
```

## `c_core.struct_field_widen@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'offsets', 'size'] (expected {'entity': ['point'], 'fields': ['x'], 'functions': ['scale'], 'offsets': ['y'], 'size': [8, 16]})

## `cxx_classes.struct_field_widen@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['functions', 'size'] (expected {'functions': ['scale'], 'size': [8, 16]})
```text
binary/high: point DataType_Size_And_Stack 
binary/medium: point Field_Type_And_Size_And_Layout_And_Type_Size x
source/low: point Field_Type x
```

## `cxx_classes.struct_field_widen@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['functions', 'size'] (expected {'functions': ['scale'], 'size': [8, 16]})
```text
binary/high: point DataType_Size_And_Stack 
binary/medium: point Field_Type_And_Size_And_Layout_And_Type_Size x
source/low: point Field_Type x
```

## `cxx_classes.struct_field_widen@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function double scale(point, double)' at edit_seed.cpp:7:1 has some indirect sub-type changes:
    parameter 1 of type 'struct point' has sub-type changes:
      type size changed from 64 to 128 (in bits)
      2 data member changes:
        type of 'int x' changed:
```

## `cxx_classes.struct_field_widen@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.struct_field_widen@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['functions', 'size'] (expected {'functions': ['scale'], 'size': [8, 16]})
```text
binary/high: point DataType_Size_And_Stack 
binary/medium: point Field_Type_And_Size_And_Layout_And_Type_Size x
source/low: point Field_Type x
```

## `cxx_classes.struct_field_widen@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'offsets', 'size'] (expected {'entity': ['point'], 'fields': ['x'], 'functions': ['scale'], 'offsets': ['y'], 'size': [8, 16]})

## `c_core.struct_array_grow@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: rec DataType_Size 
binary/low: rec Field_Type tag
source/low: rec Field_Type tag
```

## `c_core.struct_array_grow@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: rec DataType_Size 
binary/low: rec Field_Type tag
source/low: rec Field_Type tag
```

## `c_core.struct_array_grow@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 2 Changed, 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
2 functions with some indirect sub-type change:
  [C] 'function void fill_rec(rec*, int)' at edit_seed.c:10:1 has some indirect sub-type changes:
    parameter 1 of type 'rec*' has sub-type changes:
      in pointed to type 'struct rec' at edit_seed.h:5:1:
        type size changed from 192 to 256 (in bits)
        1 data member change:
```

## `c_core.struct_array_grow@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.struct_array_grow@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: rec DataType_Size 
binary/low: rec Field_Type tag
source/low: rec Field_Type tag
```

## `c_core.struct_array_grow@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'size'] (expected {'entity': ['rec'], 'fields': ['tag'], 'functions': ['fill_rec', 'make_rec'], 'size': [24, 32]})

## `cxx_classes.struct_array_grow@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['fill_rec', 'make_rec']})
```text
binary/low: rec DataType_Size 
binary/low: rec Field_Type tag
source/low: rec Field_Type tag
```

## `cxx_classes.struct_array_grow@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['fill_rec', 'make_rec']})
```text
binary/low: rec DataType_Size 
binary/low: rec Field_Type tag
source/low: rec Field_Type tag
```

## `cxx_classes.struct_array_grow@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 2 Changed, 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
2 functions with some indirect sub-type change:
  [C] 'function void fill_rec(rec*, int)' at edit_seed.cpp:13:1 has some indirect sub-type changes:
    parameter 1 of type 'rec*' has sub-type changes:
      in pointed to type 'struct rec' at edit_seed.h:5:1:
        type size changed from 192 to 256 (in bits)
        1 data member change:
```

## `cxx_classes.struct_array_grow@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.struct_array_grow@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['fill_rec', 'make_rec']})
```text
binary/low: rec DataType_Size 
binary/low: rec Field_Type tag
source/low: rec Field_Type tag
```

## `cxx_classes.struct_array_grow@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'size'] (expected {'entity': ['rec'], 'fields': ['tag'], 'functions': ['fill_rec', 'make_rec'], 'size': [24, 32]})

## `c_core.enum_append_member@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
compatible: enum_member_added color::ALPHA: Enum member added: color::ALPHA
```

## `c_core.enum_append_member@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `c_core.enum_append_member@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.enum_append_member@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
compatible: enum_member_added color::ALPHA: Enum member added: color::ALPHA
```

## `c_core.enum_append_member@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})

## `cxx_classes.enum_append_member@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
binary/safe: color Added_Enum_Member ALPHA
source/safe: color Added_Enum_Member ALPHA
```

## `cxx_classes.enum_append_member@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
binary/safe: color Added_Enum_Member ALPHA
source/safe: color Added_Enum_Member ALPHA
```

## `cxx_classes.enum_append_member@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
compatible: enum_member_added color::ALPHA: Enum member added: color::ALPHA
```

## `cxx_classes.enum_append_member@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `cxx_classes.enum_append_member@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.enum_append_member@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
binary/safe: color Added_Enum_Member ALPHA
source/safe: color Added_Enum_Member ALPHA
```

## `cxx_classes.enum_append_member@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
compatible: enum_member_added color::ALPHA: Enum member added: color::ALPHA
```

## `cxx_classes.enum_append_member@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})

## `c_core.enum_remove_member@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
```text
binary/low: color Enum_Member_Removed BLUE
source/high: color Enum_Member_Removed BLUE
```

## `c_core.enum_remove_member@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
```text
binary/low: color Enum_Member_Removed BLUE
source/high: color Enum_Member_Removed BLUE
```

## `c_core.enum_remove_member@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
breaking: enum_member_removed color::BLUE: Enum member removed: color::BLUE
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_core.enum_remove_member@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int color_code(color)' at edit_seed.c:8:1 has some indirect sub-type changes:
    parameter 1 of type 'enum color' has sub-type changes:
      type size hasn't changed
      1 enumerator deletion:
        'color::BLUE' value '2'
```

## `c_core.enum_remove_member@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.enum_remove_member@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
```text
binary/low: color Enum_Member_Removed BLUE
source/high: color Enum_Member_Removed BLUE
```

## `c_core.enum_remove_member@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
breaking: enum_member_removed color::BLUE: Enum member removed: color::BLUE
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_core.enum_remove_member@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})

## `cxx_classes.enum_remove_member@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
binary/low: color Enum_Member_Removed BLUE
source/high: color Enum_Member_Removed BLUE
```

## `cxx_classes.enum_remove_member@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
binary/low: color Enum_Member_Removed BLUE
source/high: color Enum_Member_Removed BLUE
```

## `cxx_classes.enum_remove_member@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
breaking: enum_member_removed color::BLUE: Enum member removed: color::BLUE
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.enum_remove_member@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int color_code(color)' at edit_seed.cpp:10:1 has some indirect sub-type changes:
    parameter 1 of type 'enum color' has sub-type changes:
      type size hasn't changed
      1 enumerator deletion:
        'color::BLUE' value '2'
```

## `cxx_classes.enum_remove_member@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.enum_remove_member@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
binary/low: color Enum_Member_Removed BLUE
source/high: color Enum_Member_Removed BLUE
```

## `cxx_classes.enum_remove_member@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
breaking: enum_member_removed color::BLUE: Enum member removed: color::BLUE
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.enum_remove_member@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})

## `c_core.enum_change_value@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
breaking: enum_member_value_changed color::BLUE: Enum member value changed: color::BLUE (2 → 11)
breaking: enum_member_value_changed color::GREEN: Enum member value changed: color::GREEN (1 → 10)
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_core.enum_change_value@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int color_code(color)' at edit_seed.c:8:1 has some indirect sub-type changes:
    parameter 1 of type 'enum color' has sub-type changes:
      type size hasn't changed
      2 enumerator changes:
        'color::GREEN' from value '1' to '10' at edit_seed.h:6:1
```

## `c_core.enum_change_value@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.enum_change_value@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
breaking: enum_member_value_changed color::GREEN: Enum member value changed: color::GREEN
breaking: enum_member_value_changed color::BLUE: Enum member value changed: color::BLUE
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_core.enum_change_value@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})

## `cxx_classes.enum_change_value@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
binary/medium: color Enum_Member_Value BLUE
binary/medium: color Enum_Member_Value GREEN
source/safe: color Enum_Member_Value BLUE
source/safe: color Enum_Member_Value GREEN
```

## `cxx_classes.enum_change_value@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
binary/medium: color Enum_Member_Value BLUE
binary/medium: color Enum_Member_Value GREEN
source/safe: color Enum_Member_Value BLUE
source/safe: color Enum_Member_Value GREEN
```

## `cxx_classes.enum_change_value@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
breaking: enum_member_value_changed color::BLUE: Enum member value changed: color::BLUE (2 → 11)
breaking: enum_member_value_changed color::GREEN: Enum member value changed: color::GREEN (1 → 10)
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.enum_change_value@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int color_code(color)' at edit_seed.cpp:10:1 has some indirect sub-type changes:
    parameter 1 of type 'enum color' has sub-type changes:
      type size hasn't changed
      2 enumerator changes:
        'color::GREEN' from value '1' to '10' at edit_seed.h:6:1
```

## `cxx_classes.enum_change_value@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.enum_change_value@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
binary/medium: color Enum_Member_Value BLUE
binary/medium: color Enum_Member_Value GREEN
source/safe: color Enum_Member_Value BLUE
source/safe: color Enum_Member_Value GREEN
```

## `cxx_classes.enum_change_value@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
breaking: enum_member_value_changed color::GREEN: Enum member value changed: color::GREEN
breaking: enum_member_value_changed color::BLUE: Enum member value changed: color::BLUE
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.enum_change_value@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})

## `cxx_classes.enum_class_append@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['slow', 'turbo'], 'functions': ['mode_code']})
```text
binary/safe: mode Added_Enum_Member turbo
source/safe: mode Added_Enum_Member turbo
```

## `cxx_classes.enum_class_append@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['slow', 'turbo'], 'functions': ['mode_code']})
```text
binary/safe: mode Added_Enum_Member turbo
source/safe: mode Added_Enum_Member turbo
```

## `cxx_classes.enum_class_append@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['slow', 'turbo'], 'functions': ['mode_code']})
```text
compatible: enum_member_added mode::turbo: Enum member added: mode::turbo
```

## `cxx_classes.enum_class_append@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['mode'], 'fields': ['slow', 'turbo'], 'functions': ['mode_code']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `cxx_classes.enum_class_append@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.enum_class_append@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['slow', 'turbo'], 'functions': ['mode_code']})
```text
binary/safe: mode Added_Enum_Member turbo
source/safe: mode Added_Enum_Member turbo
```

## `cxx_classes.enum_class_append@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['slow', 'turbo'], 'functions': ['mode_code']})
```text
compatible: enum_member_added mode::turbo: Enum member added: mode::turbo
```

## `cxx_classes.enum_class_append@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['mode'], 'fields': ['slow', 'turbo'], 'functions': ['mode_code']})

## `cxx_classes.enum_class_remove@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['fast', 'slow'], 'functions': ['mode_code']})
```text
binary/low: mode Enum_Member_Removed slow
source/high: mode Enum_Member_Removed slow
```

## `cxx_classes.enum_class_remove@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['fast', 'slow'], 'functions': ['mode_code']})
```text
binary/low: mode Enum_Member_Removed slow
source/high: mode Enum_Member_Removed slow
```

## `cxx_classes.enum_class_remove@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['fast', 'slow'], 'functions': ['mode_code']})
```text
breaking: enum_member_removed mode::slow: Enum member removed: mode::slow
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.enum_class_remove@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
- missed details: ['fields'] (expected {'fields': ['fast', 'slow']})
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int mode_code(mode)' at edit_seed.cpp:16:1 has some indirect sub-type changes:
    parameter 1 of type 'enum mode' has sub-type changes:
      type size hasn't changed
      1 enumerator deletion:
        'mode::slow' value '1'
```

## `cxx_classes.enum_class_remove@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.enum_class_remove@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['fast', 'slow'], 'functions': ['mode_code']})
```text
binary/low: mode Enum_Member_Removed slow
source/high: mode Enum_Member_Removed slow
```

## `cxx_classes.enum_class_remove@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['fast', 'slow'], 'functions': ['mode_code']})
```text
breaking: enum_member_removed mode::slow: Enum member removed: mode::slow
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.enum_class_remove@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['mode'], 'fields': ['fast', 'slow'], 'functions': ['mode_code']})

## `cxx_classes.enum_class_change_value@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['5', 'slow'], 'functions': ['mode_code']})
```text
binary/medium: mode Enum_Member_Value slow
source/safe: mode Enum_Member_Value slow
```

## `cxx_classes.enum_class_change_value@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['5', 'slow'], 'functions': ['mode_code']})
```text
binary/medium: mode Enum_Member_Value slow
source/safe: mode Enum_Member_Value slow
```

## `cxx_classes.enum_class_change_value@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['5', 'slow'], 'functions': ['mode_code']})
```text
breaking: enum_member_value_changed mode::slow: Enum member value changed: mode::slow (1 → 5)
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.enum_class_change_value@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
- missed details: ['fields'] (expected {'fields': ['5', 'slow']})
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int mode_code(mode)' at edit_seed.cpp:16:1 has some indirect sub-type changes:
    parameter 1 of type 'enum mode' has sub-type changes:
      type size hasn't changed
      1 enumerator change:
        'mode::slow' from value '1' to '5' at edit_seed.h:16:1
```

## `cxx_classes.enum_class_change_value@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.enum_class_change_value@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['5', 'slow'], 'functions': ['mode_code']})
```text
binary/medium: mode Enum_Member_Value slow
source/safe: mode Enum_Member_Value slow
```

## `cxx_classes.enum_class_change_value@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['5', 'slow'], 'functions': ['mode_code']})
```text
breaking: enum_member_value_changed mode::slow: Enum member value changed: mode::slow
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.enum_class_change_value@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['mode'], 'fields': ['5', 'slow'], 'functions': ['mode_code']})

## `c_core.typedef_retarget@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: handle_t DataType_Size 
binary/low: handle_t Typedef_BaseType 
source/low: handle_t Typedef_BaseType 
```

## `c_core.typedef_retarget@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: handle_t DataType_Size 
binary/low: handle_t Typedef_BaseType 
source/low: handle_t Typedef_BaseType 
```

## `c_core.typedef_retarget@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
- missed details: ['entity'] (expected {'entity': ['handle_t']})
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function handle_t handle_of(int)' at edit_seed.c:9:1 has some indirect sub-type changes:
    return type changed:
      underlying type 'int' changed:
        type name changed from 'int' to 'long long int'
        type size changed from 32 to 64 (in bits)
```

## `c_core.typedef_retarget@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.typedef_retarget@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: handle_t DataType_Size 
binary/low: handle_t Typedef_BaseType 
source/low: handle_t Typedef_BaseType 
```

## `c_core.typedef_retarget@stripped+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['handle_t'], 'functions': ['handle_of']})

## `cxx_classes.typedef_retarget@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['handle_of']})
```text
binary/low: handle_t DataType_Size 
binary/low: handle_t Typedef_BaseType 
source/low: handle_t Typedef_BaseType 
```

## `cxx_classes.typedef_retarget@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['handle_of']})
```text
binary/low: handle_t DataType_Size 
binary/low: handle_t Typedef_BaseType 
source/low: handle_t Typedef_BaseType 
```

## `cxx_classes.typedef_retarget@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
- missed details: ['entity'] (expected {'entity': ['handle_t']})
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function handle_t handle_of(int)' at edit_seed.cpp:11:1 has some indirect sub-type changes:
    return type changed:
      underlying type 'int' changed:
        type name changed from 'int' to 'long long int'
        type size changed from 32 to 64 (in bits)
```

## `cxx_classes.typedef_retarget@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.typedef_retarget@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['handle_of']})
```text
binary/low: handle_t DataType_Size 
binary/low: handle_t Typedef_BaseType 
source/low: handle_t Typedef_BaseType 
```

## `cxx_classes.typedef_retarget@stripped+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['handle_t'], 'functions': ['handle_of']})

## `c_core.func_param_type_change@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int add_ints(int, int)' at edit_seed.c:4:1 has some indirect sub-type changes:
    parameter 1 of type 'int' changed:
      type name changed from 'int' to 'long long int'
      type size changed from 32 to 64 (in bits)
```

## `c_core.func_param_type_change@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.func_param_type_change@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})

## `cxx_classes.func_param_type_change@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsxi
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsxi
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_classes.func_param_type_change@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsxi
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsxi
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_classes.func_param_type_change@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
breaking: func_params_changed _Z8add_intsii: Parameters changed: add_ints(int, int) -> (long long, int) (replacement symbol _Z8add_intsxi)
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.func_param_type_change@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.func_param_type_change@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsxi
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsxi
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_classes.func_param_type_change@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
breaking: func_params_changed _Z8add_intsii: Parameters changed: add_ints(int, int) -> (long long, int) (replacement symbol _Z8add_intsxi)
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.func_param_type_change@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z8add_intsii
1 Added function symbol not referenced by debug info:
  [A] _Z8add_intsxi
```

## `cxx_stdlib.func_param_type_change@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsxi
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsxi
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_stdlib.func_param_type_change@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsxi
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsxi
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_stdlib.func_param_type_change@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
breaking: func_params_changed _Z8add_intsii: Parameters changed: add_ints(int, int) -> (long long, int) (replacement symbol _Z8add_intsxi)
risk: exported_not_public _ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_: Symbol '_ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_' is exported by the binary but originates fro
risk: exported_not_public _ZN9__gnu_cxx11char_traitsIcE6lengthEPKc: Symbol '_ZN9__gnu_cxx11char_traitsIcE6lengthEPKc' is exported by the binary but originates f
risk: exported_not_public _ZNSt11char_traitsIcE6lengthEPKc: Symbol '_ZNSt11char_traitsIcE6lengthEPKc' is exported by the binary but originates from an external 
risk: exported_not_public _ZNSt15__new_allocatorIcED1Ev: Symbol '_ZNSt15__new_allocatorIcED1Ev' is exported by the binary but originates from an external depend
risk: exported_not_public _ZNSt15__new_allocatorIcED2Ev: Symbol '_ZNSt15__new_allocatorIcED2Ev' is exported by the binary but originates from an external depend
risk: exported_not_public _ZSt12__str_concatINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEET_PKNS6_10value_typeENS6_9size_typeES9_SA_RKNS6_14allocator_ty
risk: exported_not_public _ZSt23__is_constant_evaluatedv: Symbol '_ZSt23__is_constant_evaluatedv' is exported by the binary but originates from an external depe
```

## `cxx_stdlib.func_param_type_change@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_stdlib.func_param_type_change@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsxi
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsxi
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_stdlib.func_param_type_change@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
breaking: func_params_changed _Z8add_intsii: Parameters changed: add_ints(int, int) -> (long long, int) (replacement symbol _Z8add_intsxi)
risk: exported_not_public _ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_: Symbol '_ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_' is exported by the binary but originates fro
risk: exported_not_public _ZN9__gnu_cxx11char_traitsIcE6lengthEPKc: Symbol '_ZN9__gnu_cxx11char_traitsIcE6lengthEPKc' is exported by the binary but originates f
risk: exported_not_public _ZNSt11char_traitsIcE6lengthEPKc: Symbol '_ZNSt11char_traitsIcE6lengthEPKc' is exported by the binary but originates from an external 
risk: exported_not_public _ZNSt15__new_allocatorIcED1Ev: Symbol '_ZNSt15__new_allocatorIcED1Ev' is exported by the binary but originates from an external depend
risk: exported_not_public _ZNSt15__new_allocatorIcED2Ev: Symbol '_ZNSt15__new_allocatorIcED2Ev' is exported by the binary but originates from an external depend
risk: exported_not_public _ZSt12__str_concatINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEET_PKNS6_10value_typeENS6_9size_typeES9_SA_RKNS6_14allocator_ty
risk: exported_not_public _ZSt23__is_constant_evaluatedv: Symbol '_ZSt23__is_constant_evaluatedv' is exported by the binary but originates from an external depe
```

## `cxx_stdlib.func_param_type_change@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z8add_intsii
1 Added function symbol not referenced by debug info:
  [A] _Z8add_intsxi
```

## `c_core.params_reordered@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function void fill_rec(rec*, int)' at edit_seed.c:10:1 has some indirect sub-type changes:
    parameter 1 of type 'rec*' changed:
      entity changed from 'rec*' to 'int'
      type size changed from 64 to 32 (in bits)
    parameter 2 of type 'int' changed:
```

## `c_core.params_reordered@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.params_reordered@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['fill_rec'], 'functions': ['fill_rec']})

## `cxx_classes.params_reordered@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['fill_rec'], 'functions': ['fill_rec']})
```text
binary: removed _Z8fill_recP3reci
binary: added _Z8fill_reciP3rec
binary/high: _Z8fill_recP3reci Symbol_Changed_Parameters
source: removed _Z8fill_recP3reci
source: added _Z8fill_reciP3rec
source/medium: _Z8fill_recP3reci Symbol_Changed_Parameters
```

## `cxx_classes.params_reordered@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['fill_rec'], 'functions': ['fill_rec']})
```text
binary: removed _Z8fill_recP3reci
binary: added _Z8fill_reciP3rec
binary/high: _Z8fill_recP3reci Symbol_Changed_Parameters
source: removed _Z8fill_recP3reci
source: added _Z8fill_reciP3rec
source/medium: _Z8fill_recP3reci Symbol_Changed_Parameters
```

## `cxx_classes.params_reordered@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['fill_rec'], 'functions': ['fill_rec']})
```text
breaking: func_params_changed _Z8fill_recP3reci: Parameters changed: fill_rec(rec*, int) -> (int, rec*) (replacement symbol _Z8fill_reciP3rec)
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.params_reordered@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.params_reordered@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['fill_rec'], 'functions': ['fill_rec']})
```text
binary: removed _Z8fill_recP3reci
binary: added _Z8fill_reciP3rec
binary/high: _Z8fill_recP3reci Symbol_Changed_Parameters
source: removed _Z8fill_recP3reci
source: added _Z8fill_reciP3rec
source/medium: _Z8fill_recP3reci Symbol_Changed_Parameters
```

## `cxx_classes.params_reordered@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['fill_rec'], 'functions': ['fill_rec']})
```text
breaking: func_params_changed _Z8fill_recP3reci: Parameters changed: fill_rec(rec*, int) -> (int, rec*) (replacement symbol _Z8fill_reciP3rec)
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.params_reordered@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['fill_rec'], 'functions': ['fill_rec']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z8fill_recP3reci
1 Added function symbol not referenced by debug info:
  [A] _Z8fill_reciP3rec
```

## `c_core.func_param_append@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int add_ints(int, int)' at edit_seed.c:4:1 has some indirect sub-type changes:
    parameter 3 of type 'int' was added
```

## `c_core.func_param_append@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.func_param_append@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})

## `cxx_classes.func_param_append@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsiii
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsiii
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_classes.func_param_append@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsiii
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsiii
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_classes.func_param_append@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
breaking: func_params_changed _Z8add_intsii: Parameters changed: add_ints(int, int) -> (int, int, int) (replacement symbol _Z8add_intsiii)
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.func_param_append@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.func_param_append@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsiii
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsiii
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_classes.func_param_append@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
breaking: func_params_changed _Z8add_intsii: Parameters changed: add_ints(int, int) -> (int, int, int) (replacement symbol _Z8add_intsiii)
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.func_param_append@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z8add_intsii
1 Added function symbol not referenced by debug info:
  [A] _Z8add_intsiii
```

## `cxx_stdlib.func_param_append@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsiii
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsiii
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_stdlib.func_param_append@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsiii
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsiii
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_stdlib.func_param_append@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
breaking: func_params_changed _Z8add_intsii: Parameters changed: add_ints(int, int) -> (int, int, int) (replacement symbol _Z8add_intsiii)
risk: exported_not_public _ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_: Symbol '_ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_' is exported by the binary but originates fro
risk: exported_not_public _ZN9__gnu_cxx11char_traitsIcE6lengthEPKc: Symbol '_ZN9__gnu_cxx11char_traitsIcE6lengthEPKc' is exported by the binary but originates f
risk: exported_not_public _ZNSt11char_traitsIcE6lengthEPKc: Symbol '_ZNSt11char_traitsIcE6lengthEPKc' is exported by the binary but originates from an external 
risk: exported_not_public _ZNSt15__new_allocatorIcED1Ev: Symbol '_ZNSt15__new_allocatorIcED1Ev' is exported by the binary but originates from an external depend
risk: exported_not_public _ZNSt15__new_allocatorIcED2Ev: Symbol '_ZNSt15__new_allocatorIcED2Ev' is exported by the binary but originates from an external depend
risk: exported_not_public _ZSt12__str_concatINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEET_PKNS6_10value_typeENS6_9size_typeES9_SA_RKNS6_14allocator_ty
risk: exported_not_public _ZSt23__is_constant_evaluatedv: Symbol '_ZSt23__is_constant_evaluatedv' is exported by the binary but originates from an external depe
```

## `cxx_stdlib.func_param_append@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_stdlib.func_param_append@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsiii
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsiii
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_stdlib.func_param_append@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
breaking: func_params_changed _Z8add_intsii: Parameters changed: add_ints(int, int) -> (int, int, int) (replacement symbol _Z8add_intsiii)
risk: exported_not_public _ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_: Symbol '_ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_' is exported by the binary but originates fro
risk: exported_not_public _ZN9__gnu_cxx11char_traitsIcE6lengthEPKc: Symbol '_ZN9__gnu_cxx11char_traitsIcE6lengthEPKc' is exported by the binary but originates f
risk: exported_not_public _ZNSt11char_traitsIcE6lengthEPKc: Symbol '_ZNSt11char_traitsIcE6lengthEPKc' is exported by the binary but originates from an external 
risk: exported_not_public _ZNSt15__new_allocatorIcED1Ev: Symbol '_ZNSt15__new_allocatorIcED1Ev' is exported by the binary but originates from an external depend
risk: exported_not_public _ZNSt15__new_allocatorIcED2Ev: Symbol '_ZNSt15__new_allocatorIcED2Ev' is exported by the binary but originates from an external depend
risk: exported_not_public _ZSt12__str_concatINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEET_PKNS6_10value_typeENS6_9size_typeES9_SA_RKNS6_14allocator_ty
risk: exported_not_public _ZSt23__is_constant_evaluatedv: Symbol '_ZSt23__is_constant_evaluatedv' is exported by the binary but originates from an external depe
```

## `cxx_stdlib.func_param_append@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z8add_intsii
1 Added function symbol not referenced by debug info:
  [A] _Z8add_intsiii
```

## `c_core.func_param_remove@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int add_ints(int, int)' at edit_seed.c:4:1 has some indirect sub-type changes:
    parameter 2 of type 'int' was removed
```

## `c_core.func_param_remove@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.func_param_remove@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})

## `cxx_classes.func_param_remove@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsi
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsi
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_classes.func_param_remove@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsi
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsi
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_classes.func_param_remove@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
breaking: func_params_changed _Z8add_intsii: Parameters changed: add_ints(int, int) -> (int) (replacement symbol _Z8add_intsi)
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.func_param_remove@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.func_param_remove@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsi
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsi
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_classes.func_param_remove@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
breaking: func_params_changed _Z8add_intsii: Parameters changed: add_ints(int, int) -> (int) (replacement symbol _Z8add_intsi)
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.func_param_remove@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z8add_intsii
1 Added function symbol not referenced by debug info:
  [A] _Z8add_intsi
```

## `cxx_stdlib.func_param_remove@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsi
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsi
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_stdlib.func_param_remove@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsi
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsi
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_stdlib.func_param_remove@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
breaking: func_params_changed _Z8add_intsii: Parameters changed: add_ints(int, int) -> (int) (replacement symbol _Z8add_intsi)
risk: exported_not_public _ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_: Symbol '_ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_' is exported by the binary but originates fro
risk: exported_not_public _ZN9__gnu_cxx11char_traitsIcE6lengthEPKc: Symbol '_ZN9__gnu_cxx11char_traitsIcE6lengthEPKc' is exported by the binary but originates f
risk: exported_not_public _ZNSt11char_traitsIcE6lengthEPKc: Symbol '_ZNSt11char_traitsIcE6lengthEPKc' is exported by the binary but originates from an external 
risk: exported_not_public _ZNSt15__new_allocatorIcED1Ev: Symbol '_ZNSt15__new_allocatorIcED1Ev' is exported by the binary but originates from an external depend
risk: exported_not_public _ZNSt15__new_allocatorIcED2Ev: Symbol '_ZNSt15__new_allocatorIcED2Ev' is exported by the binary but originates from an external depend
risk: exported_not_public _ZSt12__str_concatINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEET_PKNS6_10value_typeENS6_9size_typeES9_SA_RKNS6_14allocator_ty
risk: exported_not_public _ZSt23__is_constant_evaluatedv: Symbol '_ZSt23__is_constant_evaluatedv' is exported by the binary but originates from an external depe
```

## `cxx_stdlib.func_param_remove@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_stdlib.func_param_remove@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
binary: removed _Z8add_intsii
binary: added _Z8add_intsi
binary/high: _Z8add_intsii Symbol_Changed_Parameters
source: removed _Z8add_intsii
source: added _Z8add_intsi
source/medium: _Z8add_intsii Symbol_Changed_Parameters
```

## `cxx_stdlib.func_param_remove@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
breaking: func_params_changed _Z8add_intsii: Parameters changed: add_ints(int, int) -> (int) (replacement symbol _Z8add_intsi)
risk: exported_not_public _ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_: Symbol '_ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_' is exported by the binary but originates fro
risk: exported_not_public _ZN9__gnu_cxx11char_traitsIcE6lengthEPKc: Symbol '_ZN9__gnu_cxx11char_traitsIcE6lengthEPKc' is exported by the binary but originates f
risk: exported_not_public _ZNSt11char_traitsIcE6lengthEPKc: Symbol '_ZNSt11char_traitsIcE6lengthEPKc' is exported by the binary but originates from an external 
risk: exported_not_public _ZNSt15__new_allocatorIcED1Ev: Symbol '_ZNSt15__new_allocatorIcED1Ev' is exported by the binary but originates from an external depend
risk: exported_not_public _ZNSt15__new_allocatorIcED2Ev: Symbol '_ZNSt15__new_allocatorIcED2Ev' is exported by the binary but originates from an external depend
risk: exported_not_public _ZSt12__str_concatINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEET_PKNS6_10value_typeENS6_9size_typeES9_SA_RKNS6_14allocator_ty
risk: exported_not_public _ZSt23__is_constant_evaluatedv: Symbol '_ZSt23__is_constant_evaluatedv' is exported by the binary but originates from an external depe
```

## `cxx_stdlib.func_param_remove@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['add_ints'], 'functions': ['add_ints']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z8add_intsii
1 Added function symbol not referenced by debug info:
  [A] _Z8add_intsi
```

## `c_core.func_return_type_change@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int get_count()' at edit_seed.c:6:1 has some indirect sub-type changes:
    return type changed:
      type name changed from 'int' to 'long long int'
      type size changed from 32 to 64 (in bits)
```

## `c_core.func_return_type_change@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.func_return_type_change@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['get_count'], 'functions': ['get_count']})

## `cxx_classes.func_return_type_change@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get_count'], 'functions': ['get_count']})
```text
binary/medium: _Z9get_countv Return_Type_And_Size
source/low: _Z9get_countv Return_Type
```

## `cxx_classes.func_return_type_change@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get_count'], 'functions': ['get_count']})
```text
binary/medium: _Z9get_countv Return_Type_And_Size
source/low: _Z9get_countv Return_Type
```

## `cxx_classes.func_return_type_change@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['get_count'], 'functions': ['get_count']})
```text
breaking: func_return_changed _Z9get_countv: Return type changed: get_count
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.func_return_type_change@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int get_count()' at edit_seed.cpp:8:1 has some indirect sub-type changes:
    return type changed:
      type name changed from 'int' to 'long long int'
      type size changed from 32 to 64 (in bits)
```

## `cxx_classes.func_return_type_change@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.func_return_type_change@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get_count'], 'functions': ['get_count']})
```text
binary/medium: _Z9get_countv Return_Type_And_Size
source/low: _Z9get_countv Return_Type
```

## `cxx_classes.func_return_type_change@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['get_count'], 'functions': ['get_count']})
```text
breaking: func_return_changed _Z9get_countv: Return type changed: get_count
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.func_return_type_change@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['get_count'], 'functions': ['get_count']})

## `c_core.func_remove@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.func_remove@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get_count'], 'functions': ['get_count']})
```text
binary: removed _Z9get_countv
source: removed _Z9get_countv
```

## `cxx_classes.func_remove@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get_count'], 'functions': ['get_count']})
```text
binary: removed _Z9get_countv
source: removed _Z9get_countv
```

## `cxx_classes.func_remove@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['get_count'], 'functions': ['get_count']})
```text
breaking: func_removed _Z9get_countv: Public function removed: get_count
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_shrank <surface>: public surface shrank: 58 → 57 declarations (-1)
```

## `cxx_classes.func_remove@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.func_remove@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get_count'], 'functions': ['get_count']})
```text
binary: removed _Z9get_countv
source: removed _Z9get_countv
```

## `cxx_classes.func_remove@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['get_count'], 'functions': ['get_count']})
```text
breaking: func_removed _Z9get_countv: Public function removed: get_count
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_shrank <surface>: public surface shrank: 58 → 57 declarations (-1)
```

## `cxx_classes.func_remove@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['get_count'], 'functions': ['get_count']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z9get_countv
```

## `c_core.func_add@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.func_add@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add3'], 'functions': ['add3']})
```text
binary: added _Z4add3i
source: added _Z4add3i
```

## `cxx_classes.func_add@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add3'], 'functions': ['add3']})
```text
binary: added _Z4add3i
source: added _Z4add3i
```

## `cxx_classes.func_add@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['add3'], 'functions': ['add3']})
```text
compatible: func_added _Z4add3i: New public function: add3
compatible: public_surface_grew <surface>: public surface grew: 58 → 59 declarations (+1)
```

## `cxx_classes.func_add@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.func_add@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['add3'], 'functions': ['add3']})
```text
binary: added _Z4add3i
source: added _Z4add3i
```

## `cxx_classes.func_add@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['add3'], 'functions': ['add3']})
```text
compatible: func_added _Z4add3i: New public function: add3
compatible: public_surface_grew <surface>: public surface grew: 58 → 59 declarations (+1)
```

## `cxx_classes.func_add@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['add3'], 'functions': ['add3']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 1 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Added function symbol not referenced by debug info:
  [A] _Z4add3i
```

## `cxx_classes.func_out_of_line_to_inline@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['twice'], 'functions': ['twice']})
```text
binary: removed _Z5twicei
source: removed _Z5twicei
```

## `cxx_classes.func_out_of_line_to_inline@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['twice'], 'functions': ['twice']})
```text
binary: removed _Z5twicei
```

## `cxx_classes.func_out_of_line_to_inline@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['twice'], 'functions': ['twice']})
```text
breaking: func_visibility_changed _Z5twicei: Function no longer exported by the binary, but its declaration remains present: twice
risk: func_became_inline _Z5twicei: Function became inline and its symbol is no longer exported: twice
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.func_out_of_line_to_inline@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.func_out_of_line_to_inline@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['twice'], 'functions': ['twice']})
```text
binary: removed _Z5twicei
```

## `cxx_classes.func_out_of_line_to_inline@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['twice'], 'functions': ['twice']})
```text
breaking: func_visibility_changed _Z5twicei: Function no longer exported by the binary, but its declaration remains present: twice
risk: func_became_inline _Z5twicei: Function became inline and its symbol is no longer exported: twice
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.func_out_of_line_to_inline@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['twice'], 'functions': ['twice']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z5twicei
```

## `c_core.param_rename_header_only@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.param_rename_header_only@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_stdlib.param_rename_header_only@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.var_type_change@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 1 Changed, 0 Added variable
1 Changed variable:
  [C] 'int g_counter' was changed to 'long long int g_counter' at edit_seed.h:15:1:
    size of symbol changed from 4 to 8
    type of variable changed:
      type name changed from 'int' to 'long long int'
      type size changed from 32 to 64 (in bits)
```

## `c_core.var_type_change@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.var_type_change@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['g_counter']})

## `cxx_classes.var_type_change@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 1 Changed, 0 Added variable
1 Changed variable:
  [C] 'int g_counter' was changed to 'long long int g_counter' at edit_seed.h:34:1:
    size of symbol changed from 4 to 8
    type of variable changed:
      type name changed from 'int' to 'long long int'
      type size changed from 32 to 64 (in bits)
```

## `cxx_classes.var_type_change@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.var_type_change@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['g_counter']})

## `c_core.comment_only@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.comment_only@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.reorder_declarations@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.reorder_declarations@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.static_inline_helper_added@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.static_inline_helper_added@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.virtual_method_add@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['perimeter'], 'functions': ['perimeter']})
```text
binary/high: Shape Added_Virtual_Method _ZNK5Shape9perimeterEv
binary: added _ZNK5Shape9perimeterEv
source: added _ZNK5Shape9perimeterEv
```

## `cxx_classes.virtual_method_add@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['perimeter'], 'functions': ['perimeter']})
```text
binary/high: Shape Added_Virtual_Method _ZNK5Shape9perimeterEv
binary: added _ZNK5Shape9perimeterEv
source: added _ZNK5Shape9perimeterEv
```

## `cxx_classes.virtual_method_add@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['perimeter'], 'functions': ['perimeter']})
```text
breaking: type_vtable_changed Shape: vtable changed: Shape
breaking: vtable_slot_count_changed _ZTV5Shape: Vtable for 'Shape' changed size: 32 → 40 bytes (+1 pointer-sized word). Virtual functions were net added or remo
compatible: func_added _ZNK5Shape9perimeterEv: New public function: perimeter
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_grew <surface>: public surface grew: 58 → 59 declarations (+1)
```

## `cxx_classes.virtual_method_add@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed (2 filtered out), 1 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 Added function:
  [A] 'method virtual int Shape::perimeter() const'    {_ZNK5Shape9perimeterEv}
    note that this adds a new entry to the vtable of class Shape
1 function with some indirect sub-type change:
  [C] 'method virtual int Shape::area() const' at edit_seed.cpp:4:1 has some indirect sub-type changes:
    implicit parameter 0 of type 'const Shape*' has sub-type changes:
```

## `cxx_classes.virtual_method_add@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.virtual_method_add@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['perimeter'], 'functions': ['perimeter']})
```text
binary/high: Shape Added_Virtual_Method _ZNK5Shape9perimeterEv
binary: added _ZNK5Shape9perimeterEv
source: added _ZNK5Shape9perimeterEv
```

## `cxx_classes.virtual_method_add@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['perimeter'], 'functions': ['perimeter']})
```text
breaking: type_vtable_changed Shape: vtable changed: Shape
breaking: vtable_slot_count_changed _ZTV5Shape: Vtable for 'Shape' changed size: 32 → 40 bytes (+1 pointer-sized word). Virtual functions were net added or remo
compatible: func_added _ZNK5Shape9perimeterEv: New public function: perimeter
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_grew <surface>: public surface grew: 58 → 59 declarations (+1)
```

## `cxx_classes.virtual_method_add@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['perimeter'], 'functions': ['perimeter']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 1 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Added function symbol not referenced by debug info:
  [A] _ZNK5Shape9perimeterEv
```

## `cxx_classes.virtual_reorder@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['area', 'kind'], 'functions': ['area', 'kind']})
```text
binary/high: Shape Virtual_Method_Position _ZNK5Shape4areaEv
binary/high: Shape Virtual_Method_Position _ZNK5Shape4kindEv
```

## `cxx_classes.virtual_reorder@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['area', 'kind'], 'functions': ['area', 'kind']})
```text
binary/high: Shape Virtual_Method_Position _ZNK5Shape4areaEv
binary/high: Shape Virtual_Method_Position _ZNK5Shape4kindEv
```

## `cxx_classes.virtual_reorder@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['area', 'kind'], 'functions': ['area', 'kind']})
```text
breaking: type_vtable_changed Shape: vtable reordered: Shape
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.virtual_reorder@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['area', 'kind'], 'functions': ['area', 'kind']})
```text
Functions changes summary: 0 Removed, 1 Changed (2 filtered out), 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'method virtual int Shape::area() const' at edit_seed.cpp:4:1 has some indirect sub-type changes:
    the vtable offset of method virtual int Shape::area() const changed from 0 to 1
      note that this is an ABI incompatible change to the vtable of class Shape
    implicit parameter 0 of type 'const Shape*' has sub-type changes:
      in pointed to type 'const Shape':
```

## `cxx_classes.virtual_reorder@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.virtual_reorder@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['area', 'kind'], 'functions': ['area', 'kind']})
```text
binary/high: Shape Virtual_Method_Position _ZNK5Shape4areaEv
binary/high: Shape Virtual_Method_Position _ZNK5Shape4kindEv
```

## `cxx_classes.virtual_reorder@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['area', 'kind'], 'functions': ['area', 'kind']})
```text
breaking: type_vtable_changed Shape: vtable reordered: Shape
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.virtual_reorder@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['area', 'kind'], 'functions': ['area', 'kind']})

## `cxx_classes.virtual_remove@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kind'], 'functions': ['kind']})
```text
binary/high: Shape Removed_Virtual_Method _ZNK5Shape4kindEv
binary: removed _ZNK5Shape4kindEv
source: removed _ZNK5Shape4kindEv
```

## `cxx_classes.virtual_remove@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kind'], 'functions': ['kind']})
```text
binary: removed _ZNK5Shape4kindEv
source: removed _ZNK5Shape4kindEv
```

## `cxx_classes.virtual_remove@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['kind'], 'functions': ['kind']})
```text
breaking: type_vtable_changed Shape: vtable changed: Shape
breaking: vtable_slot_count_changed _ZTV5Shape: Vtable for 'Shape' changed size: 32 → 24 bytes (-1 pointer-sized word). Virtual functions were net added or remo
breaking: func_removed _ZNK5Shape4kindEv: Public function removed: kind
breaking: func_virtual_removed _ZNK5Shape4kindEv: Virtual method removed with its vtable slot: kind (Shape)
compatible: soname_bump_recommended DT_SONAME: 3 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_shrank <surface>: public surface shrank: 58 → 57 declarations (-1)
```

## `cxx_classes.virtual_remove@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.virtual_remove@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kind'], 'functions': ['kind']})
```text
binary: removed _ZNK5Shape4kindEv
source: removed _ZNK5Shape4kindEv
```

## `cxx_classes.virtual_remove@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['kind'], 'functions': ['kind']})
```text
breaking: type_vtable_changed Shape: vtable changed: Shape
breaking: vtable_slot_count_changed _ZTV5Shape: Vtable for 'Shape' changed size: 32 → 24 bytes (-1 pointer-sized word). Virtual functions were net added or remo
breaking: func_removed _ZNK5Shape4kindEv: Public function removed: kind
breaking: func_virtual_removed _ZNK5Shape4kindEv: Virtual method removed with its vtable slot: kind (Shape)
compatible: soname_bump_recommended DT_SONAME: 3 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_shrank <surface>: public surface shrank: 58 → 57 declarations (-1)
```

## `cxx_classes.virtual_remove@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['kind'], 'functions': ['kind']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _ZNK5Shape4kindEv
```

## `cxx_classes.virtual_become_pure@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kind'], 'functions': ['kind']})
```text
binary/medium: Shape Virtual_Method_Became_Pure _ZNK5Shape4kindEv
binary: removed _ZNK5Shape4kindEv
source/medium: Shape Virtual_Method_Became_Pure _ZNK5Shape4kindEv
```

## `cxx_classes.virtual_become_pure@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kind'], 'functions': ['kind']})
```text
binary/medium: Shape Virtual_Method_Became_Pure _ZNK5Shape4kindEv
binary: removed _ZNK5Shape4kindEv
source/medium: Shape Virtual_Method_Became_Pure _ZNK5Shape4kindEv
```

## `cxx_classes.virtual_become_pure@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['kind'], 'functions': ['kind']})
```text
breaking: func_visibility_changed _ZNK5Shape4kindEv: Function no longer exported by the binary, but its declaration remains present: kind
api_break: type_became_abstract Shape: Class became abstract: Shape — direct instantiation no longer compiles
breaking: func_virtual_became_pure _ZNK5Shape4kindEv: Function became pure virtual: kind
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.virtual_become_pure@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.virtual_become_pure@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kind'], 'functions': ['kind']})
```text
binary/medium: Shape Virtual_Method_Became_Pure _ZNK5Shape4kindEv
binary: removed _ZNK5Shape4kindEv
source/medium: Shape Virtual_Method_Became_Pure _ZNK5Shape4kindEv
```

## `cxx_classes.virtual_become_pure@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['kind'], 'functions': ['kind']})
```text
breaking: func_visibility_changed _ZNK5Shape4kindEv: Function no longer exported by the binary, but its declaration remains present: kind
api_break: type_became_abstract Shape: Class became abstract: Shape — direct instantiation no longer compiles
breaking: func_virtual_became_pure _ZNK5Shape4kindEv: Function became pure virtual: kind
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.virtual_become_pure@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['kind'], 'functions': ['kind']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _ZNK5Shape4kindEv
```

## `cxx_classes.method_const_drop@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['area'], 'functions': ['area']})
```text
binary/medium: Shape Virtual_Replacement _ZN5Shape4areaEv
binary: removed _ZNK5Shape4areaEv
binary: added _ZN5Shape4areaEv
binary/high: _ZNK5Shape4areaEv Method_Became_Non_Const
source/medium: _ZNK5Shape4areaEv Method_Became_Non_Const
```

## `cxx_classes.method_const_drop@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['area'], 'functions': ['area']})
```text
binary/medium: Shape Virtual_Replacement _ZN5Shape4areaEv
binary: removed _ZNK5Shape4areaEv
binary: added _ZN5Shape4areaEv
binary/high: _ZNK5Shape4areaEv Method_Became_Non_Const
source/medium: _ZNK5Shape4areaEv Method_Became_Non_Const
```

## `cxx_classes.method_const_drop@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['area'], 'functions': ['area']})
```text
breaking: type_vtable_changed Shape: vtable changed: Shape
breaking: func_removed _ZNK5Shape4areaEv: Public function removed: area
compatible: func_added _ZN5Shape4areaEv: New public function: area
breaking: func_cv_changed _ZNK5Shape4areaEv: CV qualifier changed: area
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.method_const_drop@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.method_const_drop@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['area'], 'functions': ['area']})
```text
binary/medium: Shape Virtual_Replacement _ZN5Shape4areaEv
binary: removed _ZNK5Shape4areaEv
binary: added _ZN5Shape4areaEv
binary/high: _ZNK5Shape4areaEv Method_Became_Non_Const
source/medium: _ZNK5Shape4areaEv Method_Became_Non_Const
```

## `cxx_classes.method_const_drop@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['area'], 'functions': ['area']})
```text
breaking: type_vtable_changed Shape: vtable changed: Shape
breaking: func_removed _ZNK5Shape4areaEv: Public function removed: area
compatible: func_added _ZN5Shape4areaEv: New public function: area
breaking: func_cv_changed _ZNK5Shape4areaEv: CV qualifier changed: area
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_classes.method_const_drop@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['area'], 'functions': ['area']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _ZNK5Shape4areaEv
1 Added function symbol not referenced by debug info:
  [A] _ZN5Shape4areaEv
```

## `cxx_classes.method_noexcept_add@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['area'], 'functions': ['area']})

## `cxx_classes.method_noexcept_add@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['area'], 'functions': ['area']})

## `cxx_classes.method_noexcept_add@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['area'], 'functions': ['area']})
```text
compatible: func_noexcept_added _ZNK5Shape4areaEv: noexcept specifier added: area
api_break: func_virtual_noexcept_added _ZNK5Shape4areaEv: noexcept added to virtual method: area (an overrider without noexcept no longer compiles)
```

## `cxx_classes.method_noexcept_add@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['area'], 'functions': ['area']})

## `cxx_classes.method_noexcept_add@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.method_noexcept_add@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['area'], 'functions': ['area']})

## `cxx_classes.method_noexcept_add@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['area'], 'functions': ['area']})
```text
compatible: func_noexcept_added _ZNK5Shape4areaEv: noexcept specifier added: area
api_break: func_virtual_noexcept_added _ZNK5Shape4areaEv: noexcept added to virtual method: area (an overrider without noexcept no longer compiles)
```

## `cxx_classes.method_noexcept_add@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['area'], 'functions': ['area']})

## `cxx_classes.base_class_add@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_classes.base_class_add@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed (2 filtered out), 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 2 Added variable symbols not referenced by debug info
1 function with some indirect sub-type change:
  [C] 'method virtual int Shape::area() const' at edit_seed.cpp:4:1 has some indirect sub-type changes:
    implicit parameter 0 of type 'const Shape*' has sub-type changes:
      in pointed to type 'const Shape':
```

## `cxx_classes.base_class_add@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.base_class_add@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_classes.base_class_add@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 2 Added variable symbols not referenced by debug info
2 Added variable symbols not referenced by debug info:
  [A] _ZTI4Base
  [A] _ZTS4Base
```

## `cxx_classes.template_default_arg_change@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_classes.template_default_arg_change@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_classes.template_default_arg_change@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_classes.template_default_arg_change@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.template_default_arg_change@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_classes.template_default_arg_change@stripped+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_core.enum_append_wide_value@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
compatible: enum_member_added color::WIDE: Enum member added: color::WIDE
```

## `c_core.enum_append_wide_value@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `c_core.enum_append_wide_value@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.enum_append_wide_value@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
compatible: enum_member_added color::WIDE: Enum member added: color::WIDE
```

## `c_core.enum_append_wide_value@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})

## `cxx_classes.enum_append_wide_value@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
binary/safe: color Added_Enum_Member WIDE
source/safe: color Added_Enum_Member WIDE
```

## `cxx_classes.enum_append_wide_value@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
binary/safe: color Added_Enum_Member WIDE
source/safe: color Added_Enum_Member WIDE
```

## `cxx_classes.enum_append_wide_value@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
compatible: enum_member_added color::WIDE: Enum member added: color::WIDE
```

## `cxx_classes.enum_append_wide_value@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `cxx_classes.enum_append_wide_value@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.enum_append_wide_value@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
binary/safe: color Added_Enum_Member WIDE
source/safe: color Added_Enum_Member WIDE
```

## `cxx_classes.enum_append_wide_value@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['functions'] (expected {'functions': ['color_code']})
```text
compatible: enum_member_added color::WIDE: Enum member added: color::WIDE
```

## `cxx_classes.enum_append_wide_value@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})

## `c_core.struct_array_shrink_in_padding@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: rec Field_Type tag
source/low: rec Field_Type tag
```

## `c_core.struct_array_shrink_in_padding@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: rec Field_Type tag
source/low: rec Field_Type tag
```

## `c_core.struct_array_shrink_in_padding@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 2 Changed, 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
2 functions with some indirect sub-type change:
  [C] 'function void fill_rec(rec*, int)' at edit_seed.c:10:1 has some indirect sub-type changes:
    parameter 1 of type 'rec*' has sub-type changes:
      in pointed to type 'struct rec' at edit_seed.h:5:1:
        type size hasn't changed
        1 data member change:
```

## `c_core.struct_array_shrink_in_padding@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.struct_array_shrink_in_padding@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: rec Field_Type tag
source/low: rec Field_Type tag
```

## `c_core.struct_array_shrink_in_padding@stripped+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['rec'], 'fields': ['tag'], 'functions': ['fill_rec', 'make_rec']})

## `cxx_classes.struct_array_shrink_in_padding@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['fill_rec', 'make_rec']})
```text
binary/low: rec Field_Type tag
source/low: rec Field_Type tag
```

## `cxx_classes.struct_array_shrink_in_padding@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['fill_rec', 'make_rec']})
```text
binary/low: rec Field_Type tag
source/low: rec Field_Type tag
```

## `cxx_classes.struct_array_shrink_in_padding@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 2 Changed, 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
2 functions with some indirect sub-type change:
  [C] 'function void fill_rec(rec*, int)' at edit_seed.cpp:13:1 has some indirect sub-type changes:
    parameter 1 of type 'rec*' has sub-type changes:
      in pointed to type 'struct rec' at edit_seed.h:5:1:
        type size hasn't changed
        1 data member change:
```

## `cxx_classes.struct_array_shrink_in_padding@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.struct_array_shrink_in_padding@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['fill_rec', 'make_rec']})
```text
binary/low: rec Field_Type tag
source/low: rec Field_Type tag
```

## `cxx_classes.struct_array_shrink_in_padding@stripped+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['rec'], 'fields': ['tag'], 'functions': ['fill_rec', 'make_rec']})

## `c_core.func_lose_default_visibility@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.func_lose_default_visibility@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

- `c_core.enum_underlying_narrow@dwarf+headers`: not run (infeasible: c17 is outside the standards this edit is defined in: c c23-on (cited: ISO/IEC 9899:2024 6.7.2.2 (fixed underlying type of an enumeration)); c++ c++11-on (cited: ISO/IEC 14882:2011 [dcl.enum] (underlying type)))
- `c_core.enum_underlying_narrow@stripped+headers`: not run (infeasible: c17 is outside the standards this edit is defined in: c c23-on (cited: ISO/IEC 9899:2024 6.7.2.2 (fixed underlying type of an enumeration)); c++ c++11-on (cited: ISO/IEC 14882:2011 [dcl.enum] (underlying type)))
## `cxx_classes.enum_underlying_narrow@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})

## `cxx_classes.enum_underlying_narrow@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})

## `cxx_classes.enum_underlying_narrow@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int color_code(color)' at edit_seed.cpp:10:1 has some indirect sub-type changes:
    parameter 1 of type 'enum color' has sub-type changes:
      type size changed from 32 to 8 (in bits)
      type alignment changed from 32 to 8
      type size changed from 32 to 8 (in bits)
```

## `cxx_classes.enum_underlying_narrow@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.enum_underlying_narrow@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})

## `cxx_classes.enum_underlying_narrow@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['color'], 'functions': ['color_code']})

## `cxx_classes.enum_class_underlying_narrow@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['mode'], 'functions': ['mode_code']})

## `cxx_classes.enum_class_underlying_narrow@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['mode'], 'functions': ['mode_code']})

## `cxx_classes.enum_class_underlying_narrow@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int mode_code(mode)' at edit_seed.cpp:16:1 has some indirect sub-type changes:
    parameter 1 of type 'enum mode' has sub-type changes:
      type size changed from 32 to 8 (in bits)
      type alignment changed from 32 to 8
      type size changed from 32 to 8 (in bits)
```

## `cxx_classes.enum_class_underlying_narrow@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.enum_class_underlying_narrow@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['mode'], 'functions': ['mode_code']})

## `cxx_classes.enum_class_underlying_narrow@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['mode'], 'functions': ['mode_code']})

- `cxx_classes.no_unique_address_added@dwarf+headers`: not run (infeasible: c++17 is outside the standards this edit is defined in: c++ c++20-on (cited: P0840R2 ([[no_unique_address]]), [dcl.attr.nouniqueaddr]))
- `cxx_classes.no_unique_address_added@stripped+headers`: not run (infeasible: c++17 is outside the standards this edit is defined in: c++ c++20-on (cited: P0840R2 ([[no_unique_address]]), [dcl.attr.nouniqueaddr]))
- `cxx_classes.concept_constraint_added@dwarf+headers`: not run (infeasible: c++17 is outside the standards this edit is defined in: c++ c++20-on (cited: P0734R0 (concepts), [temp.concept]))
- `cxx_classes.concept_constraint_added@stripped+headers`: not run (infeasible: c++17 is outside the standards this edit is defined in: c++ c++20-on (cited: P0734R0 (concepts), [temp.concept]))
- `cxx_classes.concept_constraint_relaxed@dwarf+headers`: not run (infeasible: c++17 is outside the standards this edit is defined in: c++ c++20-on (cited: P0734R0 (concepts), [temp.concept]))
- `cxx_classes.concept_constraint_relaxed@stripped+headers`: not run (infeasible: c++17 is outside the standards this edit is defined in: c++ c++20-on (cited: P0734R0 (concepts), [temp.concept]))
## `c_core.rebuild_short_enums@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_core.rebuild_short_enums@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_core.rebuild_short_enums@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int color_code(color)' at edit_seed.c:8:1 has some indirect sub-type changes:
    parameter 1 of type 'enum color' has sub-type changes:
      type size changed from 32 to 8 (in bits)
      type alignment changed from 32 to 8
      type size changed from 32 to 8 (in bits)
```

## `c_core.rebuild_short_enums@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.rebuild_short_enums@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_core.rebuild_short_enums@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**

## `c_core.rebuild_short_enums@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_classes.rebuild_short_enums@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_classes.rebuild_short_enums@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_classes.rebuild_short_enums@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int color_code(color)' at edit_seed.cpp:10:1 has some indirect sub-type changes:
    parameter 1 of type 'enum color' has sub-type changes:
      type size changed from 32 to 8 (in bits)
      type alignment changed from 32 to 8
      type size changed from 32 to 8 (in bits)
```

## `cxx_classes.rebuild_short_enums@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.rebuild_short_enums@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_classes.rebuild_short_enums@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**

## `cxx_classes.rebuild_short_enums@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_core.rebuild_pack_struct@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: rec DataType_Size 
```

## `c_core.rebuild_pack_struct@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: rec DataType_Size 
```

## `c_core.rebuild_pack_struct@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 2 Changed, 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
2 functions with some indirect sub-type change:
  [C] 'function void fill_rec(rec*, int)' at edit_seed.c:10:1 has some indirect sub-type changes:
    parameter 1 of type 'rec*' has sub-type changes:
      in pointed to type 'struct rec' at edit_seed.h:5:1:
        type size changed from 192 to 160 (in bits)
        2 data member changes:
```

## `c_core.rebuild_pack_struct@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.rebuild_pack_struct@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_core.rebuild_pack_struct@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**

## `c_core.rebuild_pack_struct@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_classes.rebuild_pack_struct@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: Shape DataType_Size 
binary/low: rec DataType_Size 
binary/low: Tagged DataType_Size 
```

## `cxx_classes.rebuild_pack_struct@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 4 Changed (2 filtered out), 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
4 functions with some indirect sub-type change:
  [C] 'method virtual int Shape::area() const' at edit_seed.cpp:4:1 has some indirect sub-type changes:
    implicit parameter 0 of type 'const Shape*' has sub-type changes:
      in pointed to type 'const Shape':
        in unqualified underlying type 'class Shape' at edit_seed.h:9:1:
          type size changed from 128 to 96 (in bits)
```

## `cxx_classes.rebuild_pack_struct@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.rebuild_pack_struct@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_classes.rebuild_pack_struct@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**

## `cxx_classes.rebuild_pack_struct@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_stdlib.rebuild_cxx11_abi_off@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

- `cxx_stdlib.rebuild_against_libcxx@dwarf+headers`: not run (infeasible: -stdlib=libc++ is a clang switch; the corpus pairs it with ELF)
- `cxx_stdlib.rebuild_against_libcxx@stripped+headers`: not run (infeasible: -stdlib=libc++ is a clang switch; the corpus pairs it with ELF)
## `c_core.rebuild_hidden_visibility@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.rebuild_hidden_visibility@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_stdlib.rebuild_hidden_visibility@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_core.rebuild_optimized@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.rebuild_optimized@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_stdlib.rebuild_optimized@dwarf+headers` · libabigail abidiff
- expected: NO_CHANGE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; exit bits ['abi_change', 'incompatible_change']
```text
Functions changes summary: 7 Removed, 0 Changed, 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
7 Removed functions:
  [D] 'method bool __gnu_cxx::char_traits<char>::eq(const __gnu_cxx::char_traits<char>::char_type&)'    {_ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_}
  [D] 'method std::size_t __gnu_cxx::char_traits<char>::length()'    {_ZN9__gnu_cxx11char_traitsIcE6lengthEPKc}
  [D] 'function bool std::__is_constant_evaluated()'    {_ZSt23__is_constant_evaluatedv}
  [D] 'method std::__new_allocator<char>::~__new_allocator(int)'    {_ZNSt15__new_allocatorIcED2Ev, aliases _ZNSt15__new_allocatorIcED1Ev}
  [D] 'function std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > std::__str_concat<std::__cxx11::basic_string<char> >(const std::
```

## `cxx_stdlib.rebuild_optimized@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_stdlib.rebuild_optimized@stripped+headers` · abicheck compare
- expected: NO_CHANGE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**
```text
compatible: needed_removed DT_NEEDED: Dependency removed: libc.so.6
risk: stack_canary_removed __stack_chk_fail: Stack canary removed: -fstack-protector no longer referenced
compatible: symbol_version_required_removed GLIBC_2.2.5: Symbol version requirement removed: GLIBC_2.2.5 (from libc.so.6)
compatible: symbol_version_required_removed GLIBC_2.4: Symbol version requirement removed: GLIBC_2.4 (from libc.so.6)
compatible: symbol_version_required_added_compat GLIBCXX_3.4: New symbol version requirement: GLIBCXX_3.4 (from libstdc++.so.6) — not newer than previous max, b
compatible: imported_symbol_added _ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_disposeEv: New imported symbol: _ZNSt7__cxx1112basic_stringIcSt11cha
compatible: imported_symbol_added _ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm: New imported symbol: _ZNSt7__cxx1112basic_stringIcSt11ch
compatible: imported_symbol_added _ZSt20__throw_length_errorPKc: New imported symbol: _ZSt20__throw_length_errorPKc@GLIBCXX_3.4
```

## `cxx_stdlib.rebuild_optimized@stripped+headers` · libabigail abidiff
- expected: NO_CHANGE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; exit bits ['abi_change', 'incompatible_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 8 Removed, 0 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
8 Removed function symbols not referenced by debug info:
  [D] _ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_
  [D] _ZN9__gnu_cxx11char_traitsIcE6lengthEPKc
  [D] _ZNSt11char_traitsIcE6lengthEPKc
```

## `c_elf.version_node_added_for_new_symbol@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.version_script_dropped@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; sides {'binary': 'COMPATIBLE', 'source': 'NO_CHANGE'}
```text
binary: added t_slot
```

## `c_elf.version_script_dropped@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.version_script_dropped@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.version_script_dropped@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.version_node_renamed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.symbol_moved_version_node@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.symbol_moved_version_node_keeping_alias@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.symbol_moved_version_node_keeping_alias@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.symbol_moved_version_node_keeping_alias@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.soname_changed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.soname_changed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.soname_changed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.soname_changed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.soname_dropped@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.soname_dropped@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.soname_dropped@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.soname_dropped@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.needed_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.needed_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.needed_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.needed_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.needed_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.needed_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.needed_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.needed_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.needed_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.needed_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.needed_removed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.needed_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.needed_reordered@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.needed_reordered@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.needed_reordered@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.needed_reordered@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.needed_reordered@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.needed_reordered@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.rpath_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.rpath_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.rpath_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.rpath_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.rpath_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.rpath_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.runpath_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.runpath_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.runpath_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.runpath_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.runpath_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.runpath_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.executable_stack@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.executable_stack@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.executable_stack@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.executable_stack@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.executable_stack@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.executable_stack@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.relro_disabled@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.relro_disabled@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.relro_disabled@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.relro_disabled@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.relro_disabled@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.relro_disabled@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.bind_now_dropped@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.bind_now_dropped@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.bind_now_dropped@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.bind_now_dropped@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.bind_now_dropped@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.bind_now_dropped@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.symbolic_binding@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.symbolic_binding@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.symbolic_binding@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.symbolic_binding@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.symbolic_binding@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.symbolic_binding@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.gnu_hash_dropped@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.gnu_hash_dropped@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.gnu_hash_dropped@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.gnu_hash_dropped@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.gnu_hash_dropped@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.gnu_hash_dropped@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.stack_protector_dropped@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.stack_protector_dropped@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.stack_protector_dropped@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.stack_protector_dropped@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.stack_protector_dropped@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.stack_protector_dropped@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.tls_initial_exec@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.tls_initial_exec@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.tls_initial_exec@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.tls_initial_exec@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.tls_initial_exec@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.tls_initial_exec@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.char_made_unsigned@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.char_made_unsigned@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.char_made_unsigned@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.char_made_unsigned@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.char_made_unsigned@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.char_made_unsigned@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**
```text
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.char_made_unsigned@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.relr_packed_relocs@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.relr_packed_relocs@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.relr_packed_relocs@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.relr_packed_relocs@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.relr_packed_relocs@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.relr_packed_relocs@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.cet_disabled@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.cet_disabled@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.cet_disabled@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.cet_disabled@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.cet_disabled@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.cet_disabled@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

- `c_elf.cet_enabled@dwarf+headers`: not run (infeasible: gcc13 predefines __CET__ by default: the edit leaves the binary as it was)
- `c_elf.cet_enabled@stripped+headers`: not run (infeasible: gcc13 predefines __CET__ by default: the edit leaves the binary as it was)
## `c_elf.nodelete_flag@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.nodelete_flag@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.nodelete_flag@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.nodelete_flag@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.nodelete_flag@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.nodelete_flag@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.no_common_spelled@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.no_common_spelled@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.no_common_spelled@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.no_common_spelled@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.no_common_spelled@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.no_common_spelled@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**
```text
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.no_common_spelled@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.func_became_weak@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.func_became_weak@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.func_became_weak@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.func_became_weak@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.func_became_weak@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.func_became_weak@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.weak_became_global@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.weak_became_global@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.weak_became_global@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.weak_became_global@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.weak_became_global@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.weak_became_global@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.func_became_protected@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['vget'], 'functions': ['vget']})

## `c_elf.func_became_protected@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['vget'], 'functions': ['vget']})

## `c_elf.func_became_protected@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['vget'], 'functions': ['vget']})

## `c_elf.func_became_protected@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.func_became_protected@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['vget'], 'functions': ['vget']})

## `c_elf.func_became_protected@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['vget'], 'functions': ['vget']})

## `c_elf.object_became_protected@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj'], 'functions': ['__attribute__', 'dupc']})

## `c_elf.object_became_protected@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj'], 'functions': ['__attribute__', 'dupc']})

## `c_elf.object_became_protected@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj'], 'functions': ['__attribute__', 'dupc']})
```text
risk: protected_visibility_changed g_obj: Data symbol visibility changed: g_obj (default → protected); may break copy relocations
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.object_became_protected@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj'], 'functions': ['__attribute__', 'dupc']})

## `c_elf.object_became_protected@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.object_became_protected@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj'], 'functions': ['__attribute__', 'dupc']})

## `c_elf.object_became_protected@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj'], 'functions': ['__attribute__', 'dupc']})
```text
risk: protected_visibility_changed g_obj: Data symbol visibility changed: g_obj (default → protected); may break copy relocations
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.object_became_protected@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj'], 'functions': ['__attribute__', 'dupc']})

## `c_elf.object_hidden@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj'], 'functions': ['__attribute__', 'dupc']})
```text
binary: removed g_obj@@LIBEDIT_1.0
```

## `c_elf.object_hidden@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj'], 'functions': ['__attribute__', 'dupc']})
```text
binary: removed g_obj@@LIBEDIT_1.0
```

## `c_elf.object_hidden@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj'], 'functions': ['__attribute__', 'dupc']})
```text
breaking: var_visibility_changed g_obj: Variable no longer exported by the binary, but its declaration remains present: g_obj
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported g_obj: Public header declares extern variable 'g_obj' (expected symbol 'g_obj') but the binary does not export it. Consumers linking a
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.object_hidden@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj'], 'functions': ['__attribute__', 'dupc']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 1 Removed, 0 Changed, 0 Added variable
1 Removed variable:
  [D] 'int g_obj'    {g_obj@@LIBEDIT_1.0}
```

## `c_elf.object_hidden@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.object_hidden@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj'], 'functions': ['__attribute__', 'dupc']})
```text
binary: removed g_obj@@LIBEDIT_1.0
```

## `c_elf.object_hidden@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj'], 'functions': ['__attribute__', 'dupc']})
```text
breaking: var_visibility_changed g_obj: Variable no longer exported by the binary, but its declaration remains present: g_obj
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported g_obj: Public header declares extern variable 'g_obj' (expected symbol 'g_obj') but the binary does not export it. Consumers linking a
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.object_hidden@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj'], 'functions': ['__attribute__', 'dupc']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 1 Removed, 0 Added variable symbol not referenced by debug info
1 Removed variable symbol not referenced by debug info:
  [D] g_obj@@LIBEDIT_1.0
```

## `c_elf.object_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.object_removed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.object_became_const@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 1 Changed, 0 Added variable
1 Changed variable:
  [C] 'int g_obj' was changed to 'const int g_obj' at edit_seed.h:31:1:
    type of variable changed:
      entity changed from 'int' to 'const int'
      type size hasn't changed
```

## `c_elf.object_became_const@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.object_became_const@stripped+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['g_obj']})

## `c_elf.object_lost_const@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.object_lost_const@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['g_k']})

## `c_elf.const_object_value_changed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.const_object_value_changed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.const_object_value_changed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.const_object_value_changed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.const_object_value_changed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.const_object_value_changed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.object_array_grew@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
- missed details: ['entity'] (expected {'entity': ['g_tab']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 1 Changed, 0 Added variable
1 Changed variable:
  [C] 'const int g_tab[4]' was changed to 'const int g_tab[8]' at edit_seed.h:32:1:
    size of symbol changed from 16 to 32
    type of variable changed:
      type name changed from 'const int[4]' to 'const int[8]'
      array type size changed from 128 to 256
```

## `c_elf.object_array_grew@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.object_array_grew@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['g_tab']})

## `c_elf.const_string_object_grew@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.const_string_object_grew@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.tls_object_grew@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 1 Changed, 0 Added variable
1 Changed variable:
  [C] 'int t_slot' was changed to 'long long int t_slot' at edit_seed.h:29:1:
    size of symbol changed from 4 to 8
    type of variable changed:
      type name changed from 'int' to 'long long int'
      type size changed from 32 to 64 (in bits)
```

## `c_elf.tls_object_grew@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.tls_object_grew@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['t_slot']})

## `c_elf.object_became_tls@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['g_obj']})

## `c_elf.object_became_tls@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['g_obj']})
```text
binary: removed g_obj@@LIBEDIT_1.0
```

## `c_elf.object_became_tls@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 1 Changed, 0 Added variable
1 Changed variable:
  [C] 'int g_obj' was changed at edit_seed.h:31:1:
    symbol type changed from 'variable symbol type' to 'thread local data object symbol type'
```

## `c_elf.object_became_tls@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.object_became_tls@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['g_obj']})
```text
binary: removed g_obj@@LIBEDIT_1.0
```

## `c_elf.object_became_tls@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['g_obj']})

## `c_elf.func_became_ifunc@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
```text
binary/medium: wget@@LIBEDIT_1.0 Removed_Parameter
binary/medium: wget@@LIBEDIT_1.0 Return_Type_And_Size
binary/low: wget@@LIBEDIT_1.0 Return_PointerLevel_Increased
source: added wget_resolve
source/medium: wget Removed_Parameter
source/medium: wget Return_PointerLevel
source/low: wget Return_Type
```

## `c_elf.func_became_ifunc@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.func_became_ifunc@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.func_became_ifunc@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.func_became_ifunc@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.func_became_ifunc@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.header_constant_changed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.header_constant_changed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
```text
binary/low: EDIT_LIMIT Global_Data_Value_Changed
source/safe: EDIT_LIMIT Global_Data_Value_Changed
```

## `c_elf.header_constant_changed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.header_constant_changed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.header_constant_changed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
```text
binary/low: EDIT_LIMIT Global_Data_Value_Changed
source/safe: EDIT_LIMIT Global_Data_Value_Changed
```

## `c_elf.header_constant_changed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.header_constant_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.header_constant_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.header_constant_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.header_constant_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.header_constant_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.header_constant_removed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.header_constant_removed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.header_constant_removed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.union_member_added@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int num_i(num)' at edit_seed.c:13:1 has some indirect sub-type changes:
    parameter 1 of type 'union num' has sub-type changes:
      type size changed from 32 to 64 (in bits)
      1 data member insertion:
        'double d' at edit_seed.h:6:1
```

## `c_elf.union_member_added@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.union_member_added@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['num'], 'fields': ['d'], 'functions': ['num_i']})

## `c_elf.union_member_removed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['num'], 'fields': ['f'], 'functions': ['num_i']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `c_elf.union_member_removed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.union_member_removed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['num'], 'fields': ['f'], 'functions': ['num_i']})

## `c_elf.union_member_retyped@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int num_i(num)' at edit_seed.c:13:1 has some indirect sub-type changes:
    parameter 1 of type 'union num' has sub-type changes:
      type size changed from 32 to 64 (in bits)
      1 data member change:
        type of 'float f' changed:
```

## `c_elf.union_member_retyped@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.union_member_retyped@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['num'], 'fields': ['f'], 'functions': ['num_i']})

## `c_elf.field_became_bitfield@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['functions'] (expected {'functions': ['flags_b']})
```text
binary/medium: flags Field_Size b
```

## `c_elf.field_became_bitfield@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['flags'], 'fields': ['b'], 'functions': ['flags_b']})

## `c_elf.field_became_bitfield@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.field_became_bitfield@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['functions'] (expected {'functions': ['flags_b']})
```text
binary/medium: flags Field_Size b
```

## `c_elf.field_became_bitfield@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['flags_b']})
```text
breaking: field_bitfield_changed flags: Bitfield layout changed: flags::b
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.field_became_bitfield@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['flags'], 'fields': ['b'], 'functions': ['flags_b']})

## `c_elf.field_renamed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['fields'] (expected {'fields': ['c', 'count']})
```text
binary/low: flags Renamed_Field c
source/high: flags Renamed_Field c
```

## `c_elf.field_renamed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['fields'] (expected {'fields': ['c', 'count']})
```text
binary/low: flags Renamed_Field c
source/high: flags Renamed_Field c
```

## `c_elf.field_renamed@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['c', 'count'], 'functions': ['flags_b']})
```text
api_break: field_renamed flags: Field renamed: flags::c → count
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.field_renamed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['flags'], 'fields': ['c', 'count'], 'functions': ['flags_b']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `c_elf.field_renamed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.field_renamed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['fields'] (expected {'fields': ['c', 'count']})
```text
binary/low: flags Renamed_Field c
source/high: flags Renamed_Field c
```

## `c_elf.field_renamed@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['c', 'count'], 'functions': ['flags_b']})
```text
api_break: field_renamed flags: Field renamed: flags::c → count
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.field_renamed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['flags'], 'fields': ['c', 'count'], 'functions': ['flags_b']})

## `c_elf.field_became_const@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['functions'] (expected {'functions': ['flags_b']})
```text
api_break: field_became_const flags: Field became const: flags::b
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.field_became_const@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **unsupported**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int flags_b(flags*)' at edit_seed.c:14:1 has some indirect sub-type changes:
    parameter 1 of type 'flags*' has sub-type changes:
      in pointed to type 'struct flags' at edit_seed.h:7:1:
        type size hasn't changed
        1 data member change:
```

## `c_elf.field_became_const@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.field_became_const@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['functions'] (expected {'functions': ['flags_b']})
```text
api_break: field_became_const flags: Field became const: flags::b
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.field_became_const@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['flags'], 'fields': ['b'], 'functions': ['flags_b']})

## `c_elf.field_became_volatile@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..API_BREAK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['functions'] (expected {'functions': ['flags_b']})
```text
risk: field_became_volatile flags: Field became volatile: flags::b
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.field_became_volatile@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..API_BREAK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.field_became_volatile@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..API_BREAK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['functions'] (expected {'functions': ['flags_b']})
```text
risk: field_became_volatile flags: Field became volatile: flags::b
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.field_became_volatile@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..API_BREAK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['flags'], 'fields': ['b'], 'functions': ['flags_b']})

## `c_elf.field_became_atomic@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['flags'], 'fields': ['b'], 'functions': ['flags_b']})

## `c_elf.field_became_atomic@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **error**
- reason: exit 6: ERROR: some errors occurred when compiling headers
ERROR: see log for details:
  OUT/pairs/c_elf.field_became_atomic__dwarf_headers/logs/edit/2.0/log.txt

## `c_elf.field_became_atomic@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['b'], 'functions': ['flags_b']})
```text
breaking: atomic_qualifier_changed flags: _Atomic qualifier added on field 'b' of 'flags': int → _Atomic(int). _Atomic size/alignment may differ from the unqual
risk: abi_equivalent_type_changed flags::b: Type spelling changed between ABI-identical types: flags::b int -> _Atomic int (same size, alignment and register cl
risk: abi_equivalent_type_changed flags: Type spelling changed between ABI-identical types: flags int -> _Atomic(int) (same size, alignment and register class; 
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.field_became_atomic@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.field_became_atomic@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **error**
- reason: exit 6: ERROR: some errors occurred when compiling headers
ERROR: see log for details:
  OUT/pairs/c_elf.field_became_atomic__stripped_headers/logs/edit/2.0/log.txt

## `c_elf.field_became_atomic@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['b'], 'functions': ['flags_b']})
```text
breaking: atomic_qualifier_changed flags: _Atomic qualifier added on field 'b' of 'flags': int → _Atomic(int). _Atomic size/alignment may differ from the unqual
risk: abi_equivalent_type_changed flags: Type spelling changed between ABI-identical types: flags int -> _Atomic(int) (same size, alignment and register class; 
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.field_became_atomic@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['flags'], 'fields': ['b'], 'functions': ['flags_b']})

## `c_elf.flexible_array_member@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: buf DataType_Size 
binary/low: buf Field_Type d
source/low: buf Field_Type d
```

## `c_elf.flexible_array_member@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: buf DataType_Size 
binary/low: buf Field_Type d
source/low: buf Field_Type d
```

## `c_elf.flexible_array_member@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int buf_n(buf*)' at edit_seed.c:15:1 has some indirect sub-type changes:
    parameter 1 of type 'buf*' has sub-type changes:
      in pointed to type 'struct buf' at edit_seed.h:8:1:
        type size changed from 64 to 32 (in bits)
        1 data member change:
```

## `c_elf.flexible_array_member@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.flexible_array_member@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: buf DataType_Size 
binary/low: buf Field_Type d
source/low: buf Field_Type d
```

## `c_elf.flexible_array_member@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'size'] (expected {'entity': ['buf'], 'fields': ['d'], 'functions': ['buf_n'], 'size': [8, 4]})

## `c_elf.record_became_opaque@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.record_became_opaque@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.record_became_opaque@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.record_became_opaque@stripped+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.record_became_packed@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: ctx DataType_Size 
```

## `c_elf.record_became_packed@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: ctx DataType_Size 
```

## `c_elf.record_became_packed@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ctx_a(ctx*)' at edit_seed.c:16:1 has some indirect sub-type changes:
    parameter 1 of type 'ctx*' has sub-type changes:
      in pointed to type 'struct ctx' at edit_seed.h:9:1:
        type size changed from 64 to 40 (in bits)
        1 data member change:
```

## `c_elf.record_became_packed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.record_became_packed@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: ctx DataType_Size 
```

## `c_elf.record_became_packed@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.struct_became_union@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['ctx_a']})
```text
breaking: type_kind_changed ctx: Aggregate kind changed: ctx (struct → union)
breaking: type_size_changed ctx: Size changed: ctx (64 → 32 bits)
breaking: type_field_offset_changed ctx: Field offset changed: ctx::b (32 → 0 bits)
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.struct_became_union@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ctx_a(ctx*)' at edit_seed.c:16:1 has some indirect sub-type changes:
    parameter 1 of type 'ctx*' has sub-type changes:
      in pointed to type 'struct ctx' at edit_seed.h:9:1:
        entity changed from 'struct ctx' to 'union ctx' at edit_seed.h:9:1
        type size changed from 64 to 32 (in bits)
```

## `c_elf.struct_became_union@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.struct_became_union@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['ctx_a']})
```text
breaking: type_kind_changed ctx: Aggregate kind changed: ctx (struct → union)
breaking: type_size_changed ctx: Size changed: ctx (64 → 32 bits)
breaking: type_field_offset_changed ctx: Field offset changed: ctx::b (32 → 0 bits)
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.struct_became_union@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['ctx_a'], 'functions': ['ctx_a']})

## `c_elf.record_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.record_removed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.typedef_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['entity'] (expected {'entity': ['count_t', 'counted']})
```text
binary/low: counted@@LIBEDIT_1.0 Parameter_Type
binary/low: counted@@LIBEDIT_1.0 Return_Type
source/low: counted Return_Type
```

## `c_elf.typedef_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['entity'] (expected {'entity': ['count_t', 'counted']})
```text
binary/low: counted@@LIBEDIT_1.0 Parameter_Type
binary/low: counted@@LIBEDIT_1.0 Return_Type
source/low: counted Return_Type
```

## `c_elf.typedef_removed@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['functions'] (expected {'functions': ['counted']})
```text
risk: abi_equivalent_type_changed counted: Type spelling changed between ABI-identical types: counted count_t -> int (same size, alignment and register class; a
api_break: typedef_removed count_t: Typedef removed: count_t
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.typedef_removed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['count_t', 'counted'], 'functions': ['counted']})

## `c_elf.typedef_removed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.typedef_removed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['entity'] (expected {'entity': ['count_t', 'counted']})
```text
binary/low: counted@@LIBEDIT_1.0 Parameter_Type
binary/low: counted@@LIBEDIT_1.0 Return_Type
source/low: counted Return_Type
```

## `c_elf.typedef_removed@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['functions'] (expected {'functions': ['counted']})
```text
risk: abi_equivalent_type_changed counted: Type spelling changed between ABI-identical types: counted count_t -> int (same size, alignment and register class; a
api_break: typedef_removed count_t: Typedef removed: count_t
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.typedef_removed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['count_t', 'counted'], 'functions': ['counted']})

## `c_elf.enum_member_renamed@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['functions'] (expected {'functions': ['level_code']})
```text
api_break: enum_member_renamed level: Enum member renamed: level::MID → MEDIUM (value=1)
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.enum_member_renamed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **unsupported**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int level_code(level)' at edit_seed.c:17:1 has some indirect sub-type changes:
    parameter 1 of type 'enum level' has sub-type changes:
      type size hasn't changed
      1 enumerator deletion:
        'level::MID' value '1'
```

## `c_elf.enum_member_renamed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.enum_member_renamed@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['functions'] (expected {'functions': ['level_code']})
```text
api_break: enum_member_renamed level: Enum member renamed: level::MID → MEDIUM (value=1)
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.enum_member_renamed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['level'], 'functions': ['level_code']})

## `c_elf.enum_sentinel_moved@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['functions'] (expected {'functions': ['level_code']})
```text
risk: enum_last_member_value_changed level::LEVEL_LAST: Enum member value changed: level::LEVEL_LAST (2 → 3)
compatible: enum_member_added level::HIGH: Enum member added: level::HIGH
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.enum_sentinel_moved@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.enum_sentinel_moved@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['functions'] (expected {'functions': ['level_code']})
```text
risk: enum_last_member_value_changed level::LEVEL_LAST: Enum member value changed: level::LEVEL_LAST
compatible: enum_member_added level::HIGH: Enum member added: level::HIGH
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.enum_sentinel_moved@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['level'], 'functions': ['level_code']})

## `c_elf.api_deprecated@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['__attribute__', 'g_obj', 'level', 'num', 'vget'], 'fields': ['f'], 'functions': ['__attribute__', 'dupc', 'level_code', 'num_i', 'vget']})

## `c_elf.api_deprecated@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['__attribute__', 'g_obj', 'level', 'num', 'vget'], 'fields': ['f'], 'functions': ['__attribute__', 'dupc', 'level_code', 'num_i', 'vget']})

## `c_elf.api_deprecated@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj', 'level', 'num', 'vget'], 'functions': ['__attribute__', 'dupc', 'level_code', 'num_i', 'vget']})
```text
compatible: func_deprecated_added vget: Function marked deprecated: vget ()
compatible: var_deprecated_added g_obj: Variable marked deprecated: g_obj ()
compatible: field_deprecated_added num: Field marked deprecated: num::f ()
compatible: type_deprecated_added flags: Type marked deprecated: flags ()
compatible: enum_deprecated_added level: Enum marked deprecated: level ()
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.api_deprecated@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['__attribute__', 'g_obj', 'level', 'num', 'vget'], 'fields': ['f'], 'functions': ['__attribute__', 'dupc', 'level_code', 'num_i', 'vget']})

## `c_elf.api_deprecated@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.api_deprecated@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['__attribute__', 'g_obj', 'level', 'num', 'vget'], 'fields': ['f'], 'functions': ['__attribute__', 'dupc', 'level_code', 'num_i', 'vget']})

## `c_elf.api_deprecated@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_obj', 'level', 'num', 'vget'], 'functions': ['__attribute__', 'dupc', 'level_code', 'num_i', 'vget']})
```text
compatible: func_deprecated_added vget: Function marked deprecated: vget ()
compatible: var_deprecated_added g_obj: Variable marked deprecated: g_obj ()
compatible: field_deprecated_added num: Field marked deprecated: num::f ()
compatible: type_deprecated_added flags: Type marked deprecated: flags ()
compatible: enum_deprecated_added level: Enum marked deprecated: level ()
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.api_deprecated@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['__attribute__', 'g_obj', 'level', 'num', 'vget'], 'fields': ['f'], 'functions': ['__attribute__', 'dupc', 'level_code', 'num_i', 'vget']})

## `c_elf.api_undeprecated@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_old', 'old_api', 'old_mode'], 'functions': ['__attribute__', 'dupc', 'old_api']})

## `c_elf.api_undeprecated@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_old', 'old_api', 'old_mode'], 'functions': ['__attribute__', 'dupc', 'old_api']})

## `c_elf.api_undeprecated@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_old', 'old_api', 'old_mode'], 'functions': ['__attribute__', 'dupc', 'old_api']})
```text
compatible: func_deprecated_removed old_api: Function no longer marked deprecated: old_api
compatible: var_deprecated_removed g_old: Variable no longer marked deprecated: g_old
compatible: type_deprecated_removed legacy: Type no longer marked deprecated: legacy
compatible: enum_deprecated_removed old_mode: Enum no longer marked deprecated: old_mode
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.api_undeprecated@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_old', 'old_api', 'old_mode'], 'functions': ['__attribute__', 'dupc', 'old_api']})

## `c_elf.api_undeprecated@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.api_undeprecated@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_old', 'old_api', 'old_mode'], 'functions': ['__attribute__', 'dupc', 'old_api']})

## `c_elf.api_undeprecated@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_old', 'old_api', 'old_mode'], 'functions': ['__attribute__', 'dupc', 'old_api']})
```text
compatible: func_deprecated_removed old_api: Function no longer marked deprecated: old_api
compatible: var_deprecated_removed g_old: Variable no longer marked deprecated: g_old
compatible: type_deprecated_removed legacy: Type no longer marked deprecated: legacy
compatible: enum_deprecated_removed old_mode: Enum no longer marked deprecated: old_mode
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.api_undeprecated@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'g_old', 'old_api', 'old_mode'], 'functions': ['__attribute__', 'dupc', 'old_api']})

## `c_elf.func_became_variadic@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['vsum'], 'functions': ['vsum']})

## `c_elf.func_became_variadic@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['vsum'], 'functions': ['vsum']})

## `c_elf.func_became_variadic@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int vsum(int)' at edit_seed.c:8:1 has some indirect sub-type changes:
    parameter 2 of type '...' was added
```

## `c_elf.func_became_variadic@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.func_became_variadic@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['vsum'], 'functions': ['vsum']})

## `c_elf.func_became_variadic@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['vsum'], 'functions': ['vsum']})

## `c_elf.func_lost_variadic@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['vfmt'], 'functions': ['vfmt']})

## `c_elf.func_lost_variadic@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['vfmt'], 'functions': ['vfmt']})

## `c_elf.func_lost_variadic@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int vfmt(int, ...)' at edit_seed.c:9:1 has some indirect sub-type changes:
    parameter 2 of type '...' was removed
```

## `c_elf.func_lost_variadic@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.func_lost_variadic@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['vfmt'], 'functions': ['vfmt']})

## `c_elf.func_lost_variadic@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['vfmt'], 'functions': ['vfmt']})

## `c_elf.param_restrict_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
```text
binary/medium: pread_int@@LIBEDIT_1.0 Parameter_Became_Restrict
binary/low: pread_int@@LIBEDIT_1.0 Parameter_Type
source/safe: pread_int Parameter_Became_Restrict
```

## `c_elf.param_restrict_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **error**
- reason: exit 6: ERROR: some errors occurred when compiling headers
ERROR: see log for details:
  OUT/pairs/c_elf.param_restrict_added__dwarf_headers/logs/edit/2.0/log.txt

## `c_elf.param_restrict_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['pread_int'], 'functions': ['pread_int']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `c_elf.param_restrict_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.param_restrict_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **error**
- reason: exit 6: ERROR: some errors occurred when compiling headers
ERROR: see log for details:
  OUT/pairs/c_elf.param_restrict_added__stripped_headers/logs/edit/2.0/log.txt

## `c_elf.param_restrict_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['pread_int'], 'functions': ['pread_int']})

## `c_elf.param_pointer_level_changed@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int pread_int(int*)' at edit_seed.c:10:1 has some indirect sub-type changes:
    parameter 1 of type 'int*' changed:
      in pointed to type 'int':
        entity changed from 'int' to 'int*'
        type size changed from 32 to 64 (in bits)
```

## `c_elf.param_pointer_level_changed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.param_pointer_level_changed@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['pread_int'], 'functions': ['pread_int']})

## `c_elf.return_pointer_level_changed@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
```text
binary/low: pref@@LIBEDIT_1.0 Return_PointerLevel_Increased
binary/low: pref@@LIBEDIT_1.0 Return_Type
source/medium: pref Return_PointerLevel
source/low: pref Return_Type
```

## `c_elf.return_pointer_level_changed@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
```text
binary/low: pref@@LIBEDIT_1.0 Return_PointerLevel_Increased
binary/low: pref@@LIBEDIT_1.0 Return_Type
source/medium: pref Return_PointerLevel
source/low: pref Return_Type
```

## `c_elf.return_pointer_level_changed@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int* pref()' at edit_seed.c:12:1 has some indirect sub-type changes:
    return type changed:
      in pointed to type 'int':
        entity changed from 'int' to 'int*'
        type size changed from 32 to 64 (in bits)
```

## `c_elf.return_pointer_level_changed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.return_pointer_level_changed@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
```text
binary/low: pref@@LIBEDIT_1.0 Return_PointerLevel_Increased
binary/low: pref@@LIBEDIT_1.0 Return_Type
source/medium: pref Return_PointerLevel
source/low: pref Return_Type
```

## `c_elf.return_pointer_level_changed@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['pref'], 'functions': ['pref']})

## `c_elf.param_pointee_const_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['pread_int'], 'functions': ['pread_int']})
```text
binary/low: pread_int@@LIBEDIT_1.0 Parameter_Type
```

## `c_elf.param_pointee_const_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['pread_int'], 'functions': ['pread_int']})
```text
binary/low: pread_int@@LIBEDIT_1.0 Parameter_Type
```

## `c_elf.param_pointee_const_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['pread_int'], 'functions': ['pread_int']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `c_elf.param_pointee_const_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.param_pointee_const_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['pread_int'], 'functions': ['pread_int']})
```text
binary/low: pread_int@@LIBEDIT_1.0 Parameter_Type
```

## `c_elf.param_pointee_const_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['pread_int'], 'functions': ['pread_int']})

## `c_elf.return_pointee_const_added@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
```text
binary/medium: pref@@LIBEDIT_1.0 Return_Type_Became_Const
binary/low: pref@@LIBEDIT_1.0 Return_Type
source/medium: pref Return_Type_Became_Const
```

## `c_elf.return_pointee_const_added@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
```text
binary/medium: pref@@LIBEDIT_1.0 Return_Type_Became_Const
binary/low: pref@@LIBEDIT_1.0 Return_Type
source/medium: pref Return_Type_Became_Const
```

## `c_elf.return_pointee_const_added@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['pref'], 'functions': ['pref']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `c_elf.return_pointee_const_added@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.return_pointee_const_added@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
```text
binary/medium: pref@@LIBEDIT_1.0 Return_Type_Became_Const
binary/low: pref@@LIBEDIT_1.0 Return_Type
source/medium: pref Return_Type_Became_Const
```

## `c_elf.return_pointee_const_added@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['pref'], 'functions': ['pref']})

- `c_elf.rebuild_m32@dwarf+headers`: not run (infeasible: gcc13 cannot build with -O0 -m32: collect2: error: ld returned 1 exit status)
- `c_elf.rebuild_m32@stripped+headers`: not run (infeasible: gcc13 cannot build with -O0 -m32: collect2: error: ld returned 1 exit status)
- `c_elf.rebuild_x32@dwarf+headers`: not run (infeasible: gcc13 does not accept -mx32 here)
- `c_elf.rebuild_x32@stripped+headers`: not run (infeasible: gcc13 does not accept -mx32 here)
## `c_elf.text_relocation_introduced@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.text_relocation_introduced@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.text_relocation_introduced@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.text_relocation_introduced@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.text_relocation_introduced@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.text_relocation_introduced@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.writable_executable_segment@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.writable_executable_segment@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.writable_executable_segment@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.writable_executable_segment@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.writable_executable_segment@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.writable_executable_segment@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.init_fini_dropped@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.init_fini_dropped@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.init_fini_dropped@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.init_fini_dropped@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.init_fini_dropped@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.init_fini_dropped@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.x86_isa_level_raised@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.x86_isa_level_raised@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.x86_isa_level_raised@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.x86_isa_level_raised@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.x86_isa_level_raised@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.x86_isa_level_raised@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.target_isa_raised@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.target_isa_raised@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.target_isa_raised@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.target_isa_raised@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.target_isa_raised@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.target_isa_raised@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**
```text
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.target_isa_raised@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.debug_info_dropped@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **error**
- reason: exit 10: ERROR: can't find debug info in object(s)

## `c_elf.debug_info_dropped@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.debug_info_dropped@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.debug_info_dropped@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.debug_info_dropped@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.debug_info_dropped@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**
```text
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.debug_info_dropped@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.vector_math_abi_changed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.vector_math_abi_changed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.vector_math_abi_changed@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **error**
- reason: exit 1: r a compile database, or compile.frontend: castxml):
Error: Failed to dump 'OUT/pairs/c_elf.vector_math_abi_changed__dwarf_headers/new/libedit.so': castxml failed (exit 1):
error: unknown argument: '-mvecliba

## `c_elf.vector_math_abi_changed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.vector_math_abi_changed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.vector_math_abi_changed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.vector_math_abi_changed@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**
```text
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.vector_math_abi_changed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.short_wchar@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.short_wchar@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.short_wchar@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.short_wchar@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.short_wchar@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.short_wchar@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**
```text
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.short_wchar@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.object_alignment_reduced@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__'], 'functions': ['__attribute__', 'dupc']})

## `c_elf.object_alignment_reduced@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__'], 'functions': ['__attribute__', 'dupc']})

## `c_elf.object_alignment_reduced@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__'], 'functions': ['__attribute__', 'dupc']})
```text
breaking: var_alignment_changed g_al: Variable alignment changed: g_al (128 → 16 bits)
risk: exported_object_alignment_reduced g_al: Exported object alignment reduced: g_al (32 → 4 bytes)
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.object_alignment_reduced@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__'], 'functions': ['__attribute__', 'dupc']})

## `c_elf.object_alignment_reduced@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.object_alignment_reduced@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__'], 'functions': ['__attribute__', 'dupc']})

## `c_elf.object_alignment_reduced@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__'], 'functions': ['__attribute__', 'dupc']})
```text
breaking: var_alignment_changed g_al: Variable alignment changed: g_al (128 → 16 bits)
risk: exported_object_alignment_reduced g_al: Exported object alignment reduced: g_al (32 → 4 bytes)
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.object_alignment_reduced@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__'], 'functions': ['__attribute__', 'dupc']})

- `c_elf.field_became_bit_int@dwarf+headers`: not run (infeasible: c17 is outside the standards this edit is defined in: c c23-on (cited: ISO/IEC 9899:2024 6.2.5 (bit-precise integer types)))
- `c_elf.field_became_bit_int@stripped+headers`: not run (infeasible: c17 is outside the standards this edit is defined in: c c23-on (cited: ISO/IEC 9899:2024 6.2.5 (bit-precise integer types)))
## `c_elf.imported_symbol_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.imported_symbol_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.imported_symbol_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.imported_symbol_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.imported_symbol_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.imported_symbol_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.glibc_version_required_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.glibc_version_required_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.glibc_version_required_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.glibc_version_required_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.glibc_version_required_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.glibc_version_required_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.glibc_older_version_required@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.glibc_older_version_required@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.glibc_older_version_required@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.glibc_older_version_required@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.glibc_older_version_required@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.glibc_older_version_required@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.export_surface_exploded@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.unversioned_export_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.declared_but_not_exported@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['edit_missing'], 'functions': ['edit_missing']})

## `c_elf.declared_but_not_exported@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['edit_missing'], 'functions': ['edit_missing']})

## `c_elf.declared_but_not_exported@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.declared_but_not_exported@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['edit_missing'], 'functions': ['edit_missing']})

## `c_elf.exported_but_undeclared@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['wget'], 'functions': ['wget']})

## `c_elf.exported_but_undeclared@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['wget'], 'functions': ['wget']})

## `c_elf.exported_but_undeclared@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.exported_but_undeclared@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['wget'], 'functions': ['wget']})

## `c_elf.export_localized_header_kept@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.executable_stack_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.executable_stack_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.executable_stack_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.executable_stack_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.executable_stack_removed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.executable_stack_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.bind_now_dropped_without_relro@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.bind_now_dropped_without_relro@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.bind_now_dropped_without_relro@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.bind_now_dropped_without_relro@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.bind_now_dropped_without_relro@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.bind_now_dropped_without_relro@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.relr_relocs_unpacked@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.relr_relocs_unpacked@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.relr_relocs_unpacked@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.relr_relocs_unpacked@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.relr_relocs_unpacked@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.relr_relocs_unpacked@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.rpath_became_runpath@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.rpath_became_runpath@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.rpath_became_runpath@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.rpath_became_runpath@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.rpath_became_runpath@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.rpath_became_runpath@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.soname_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.soname_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.soname_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; exit bits ['abi_change', 'incompatible_change']
```text
ELF SONAME changed
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
SONAME changed from '' to 'libedit.so'
```

## `c_elf_alt.soname_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.soname_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.soname_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; exit bits ['abi_change', 'incompatible_change']
```text
ELF SONAME changed
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
SONAME changed from '' to 'libedit.so'
```

## `c_elf_alt.text_relocation_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.text_relocation_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.text_relocation_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.text_relocation_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.text_relocation_removed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.text_relocation_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.static_tls_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.static_tls_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.static_tls_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.static_tls_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.static_tls_removed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.static_tls_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.ifunc_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
```text
binary/medium: fast@@LIBEDIT_1.0 Added_Parameter
binary/medium: fast@@LIBEDIT_1.0 Return_PointerLevel_Decreased
binary/medium: fast@@LIBEDIT_1.0 Return_Type_And_Size
source: removed fast_resolve
source/medium: fast Added_Parameter
source/medium: fast Return_PointerLevel
source/low: fast Return_Type
```

## `c_elf_alt.ifunc_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.ifunc_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.ifunc_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.ifunc_removed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.ifunc_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.imported_symbol_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.imported_symbol_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.imported_symbol_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.imported_symbol_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.imported_symbol_removed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.imported_symbol_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.glibc_version_requirement_dropped@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.glibc_version_requirement_dropped@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.glibc_version_requirement_dropped@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.glibc_version_requirement_dropped@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.glibc_version_requirement_dropped@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.glibc_version_requirement_dropped@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.fortified_call_dropped@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.fortified_call_dropped@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.fortified_call_dropped@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.fortified_call_dropped@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.fortified_call_dropped@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.fortified_call_dropped@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.empty_version_node_dropped@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.empty_version_node_dropped@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.empty_version_node_dropped@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.empty_version_node_dropped@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.empty_version_node_dropped@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.empty_version_node_dropped@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.api_version_suffix_bumped@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.returned_struct_grew_past_registers@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: pair2 Added_Field_And_Size c
binary/low: pair2 DataType_Size 
source/low: pair2 Added_Field c
```

## `c_elf_alt.returned_struct_grew_past_registers@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: pair2 Added_Field_And_Size c
binary/low: pair2 DataType_Size 
source/low: pair2 Added_Field c
```

## `c_elf_alt.returned_struct_grew_past_registers@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
- missed details: ['entity', 'fields', 'size'] (expected {'entity': ['pair2'], 'fields': ['c'], 'size': [16, 24]})
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function pair2 mkpair(long int)' at edit_seed.c:23:1 has some indirect sub-type changes:
    return type changed:
      type size changed from 128 to 192 (in bits)
      1 data member insertion:
        'long int c', at offset 128 (in bits) at edit_seed.h:14:1
```

## `c_elf_alt.returned_struct_grew_past_registers@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.returned_struct_grew_past_registers@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: pair2 Added_Field_And_Size c
binary/low: pair2 DataType_Size 
source/low: pair2 Added_Field c
```

## `c_elf_alt.returned_struct_grew_past_registers@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'size'] (expected {'entity': ['pair2'], 'fields': ['c'], 'functions': ['mkpair'], 'size': [16, 24]})

## `c_elf_alt.long_double_made_64bit@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.long_double_made_64bit@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.long_double_made_64bit@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function long double ld_half(long double)' at edit_seed.c:24:1 has some indirect sub-type changes:
    return type changed:
      type size changed from 128 to 64 (in bits)
    parameter 1 of type 'long double' has sub-type changes:
      type size changed from 128 to 64 (in bits)
```

## `c_elf_alt.long_double_made_64bit@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.long_double_made_64bit@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.long_double_made_64bit@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**

## `c_elf_alt.long_double_made_64bit@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf_alt.integer_typedef_widened@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
- missed details: ['entity'] (expected {'entity': ['edit_int']})
```text
Functions changes summary: 0 Removed, 3 Changed, 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
3 functions with some indirect sub-type change:
  [C] 'function edit_int imix(edit_int, edit_int)' at edit_seed.c:27:1 has some indirect sub-type changes:
    return type changed:
      underlying type 'int' changed:
        type name changed from 'int' to 'long int'
        type size changed from 32 to 64 (in bits)
```

## `c_elf_alt.integer_typedef_widened@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.integer_typedef_widened@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['edit_int'], 'functions': ['imix', 'iscale', 'ishift']})

- `c_elf_alt.time_bits_64@dwarf+headers`: not run (infeasible: time_t is already 64-bit)
- `c_elf_alt.time_bits_64@stripped+headers`: not run (infeasible: time_t is already 64-bit)
## `c_elf_alt.header_only_function_params_changed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf_alt.header_only_function_params_changed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []

## `c_elf_alt.header_only_function_params_changed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.header_only_function_params_changed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []

## `c_elf_alt.internal_helper_hidden@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_alt.gnu_unique_disabled@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_alt.gnu_unique_disabled@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_alt.gnu_unique_disabled@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_alt.gnu_unique_disabled@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_alt.gnu_unique_disabled@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_alt.gnu_unique_disabled@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_alt.allocator_replacement_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_alt.allocator_replacement_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_alt.allocator_replacement_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; exit bits ['abi_change', 'incompatible_change']
```text
Functions changes summary: 5 Removed, 0 Changed, 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
5 Removed functions:
  [D] 'function void operator delete(void*)'    {_ZdlPv}
  [D] 'function void operator delete(void*, std::size_t)'    {_ZdlPvm}
  [D] 'function void* operator new(std::size_t)'    {_Znwm}
  [D] 'method std::bad_alloc::bad_alloc()'    {_ZNSt9bad_allocC2Ev, aliases _ZNSt9bad_allocC1Ev}
  [D] 'method std::exception::exception()'    {_ZNSt9exceptionC2Ev, aliases _ZNSt9exceptionC1Ev}
```

## `cxx_alt.allocator_replacement_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_alt.allocator_replacement_removed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_alt.allocator_replacement_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; exit bits ['abi_change', 'incompatible_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 7 Removed, 0 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
7 Removed function symbols not referenced by debug info:
  [D] _ZNSt9bad_allocC1Ev, aliases _ZNSt9bad_allocC2Ev
  [D] _ZNSt9bad_allocC2Ev
  [D] _ZNSt9exceptionC1Ev, aliases _ZNSt9exceptionC2Ev
```

## `cxx_alt.std_string_abi_flipped@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_alt.by_value_struct_became_nontrivial@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
```text
binary: added _ZN2TvD1Ev
binary: added _ZN2TvD2Ev
source: added _ZN2TvD1Ev
source: added _ZN2TvD2Ev
```

## `cxx_alt.by_value_struct_became_nontrivial@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
```text
binary: added _ZN2TvD1Ev
binary: added _ZN2TvD2Ev
source: added _ZN2TvD0Ev
source: added _ZN2TvD1Ev
source: added _ZN2TvD2Ev
```

## `cxx_alt.by_value_struct_became_nontrivial@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 1 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 Added function:
  [A] 'method Tv::~Tv(int)'    {_ZN2TvD2Ev, aliases _ZN2TvD1Ev}
```

## `cxx_alt.by_value_struct_became_nontrivial@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_alt.by_value_struct_became_nontrivial@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
```text
binary: added _ZN2TvD1Ev
binary: added _ZN2TvD2Ev
source: added _ZN2TvD0Ev
source: added _ZN2TvD1Ev
source: added _ZN2TvD2Ev
```

## `cxx_alt.by_value_struct_became_nontrivial@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 2 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
2 Added function symbols not referenced by debug info:
  [A] _ZN2TvD1Ev, aliases _ZN2TvD2Ev
  [A] _ZN2TvD2Ev
```

## `cxx_alt.internal_type_grew@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Impl'], 'fields': ['b']})
```text
binary/medium: lib::Holder Private_Field_Size_And_Layout_And_Type_Size impl
binary/low: lib::Holder DataType_Size 
```

## `cxx_alt.internal_type_grew@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Impl'], 'fields': ['b']})
```text
binary/medium: lib::Holder Private_Field_Size_And_Layout_And_Type_Size impl
binary/low: lib::Holder DataType_Size 
```

## `cxx_alt.internal_type_grew@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
- missed details: ['entity', 'fields'] (expected {'entity': ['Impl'], 'fields': ['b']})
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int lib::holder_get(const lib::Holder*)' at edit_seed.cpp:15:1 has some indirect sub-type changes:
    parameter 1 of type 'const lib::Holder*' has sub-type changes:
      in pointed to type 'const lib::Holder':
        in unqualified underlying type 'struct lib::Holder' at edit_seed.h:17:1:
          type size changed from 64 to 96 (in bits)
```

## `cxx_alt.internal_type_grew@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_alt.internal_type_grew@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Impl'], 'fields': ['b']})
```text
binary/medium: lib::Holder Private_Field_Size_And_Layout_And_Type_Size impl
binary/low: lib::Holder DataType_Size 
```

## `cxx_alt.internal_type_grew@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Impl'], 'fields': ['b']})

## `cxx_alt.header_inline_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_alt.header_inline_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_alt.header_inline_removed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []

## `cxx_alt.header_inline_removed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_alt.header_inline_removed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_alt.header_inline_removed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []

- `cxx_alt.char_param_became_char8@dwarf+headers`: not run (infeasible: c++17 is outside the standards this edit is defined in: c++ c++20-on (cited: P0482R6 (char8_t), [lex.ccon]))
- `cxx_alt.char_param_became_char8@stripped+headers`: not run (infeasible: c++17 is outside the standards this edit is defined in: c++ c++20-on (cited: P0482R6 (char8_t), [lex.ccon]))
## `cxx_alt.internal_template_instance_dropped@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_alt.internal_template_instance_dropped@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'NO_CHANGE', 'source': 'INCOMPATIBLE'}
```text
source: removed _ZN3lib8__detail4walkIfEET_PS2_S3_
source: added _ZN3lib8__detail4walkIdEET_PS2_S3_
```

## `cxx_alt.internal_template_instance_dropped@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_alt.internal_template_instance_dropped@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'NO_CHANGE', 'source': 'INCOMPATIBLE'}
```text
source: removed _ZN3lib8__detail4walkIfEET_PS2_S3_
source: added _ZN3lib8__detail4walkIdEET_PS2_S3_
```

## `cxx_more.gnu_unique_static_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['edit_bump'], 'functions': ['edit_bump']})
```text
binary: added _Z9edit_bumpv
source: added _Z9edit_bumpv
```

## `cxx_more.gnu_unique_static_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['edit_bump'], 'functions': ['edit_bump']})
```text
binary: added _Z9edit_bumpv
source: added _Z9edit_bumpv
```

## `cxx_more.gnu_unique_static_added@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['edit_bump'], 'functions': ['edit_bump']})
```text
compatible: func_added _Z8edit_ctrv: New public function: edit_ctr
compatible: func_added _Z9edit_bumpv: New public function: edit_bump
risk: symbol_binding_became_unique _ZZ8edit_ctrvE1n: Symbol binding became GNU_UNIQUE: _ZZ8edit_ctrvE1n — inhibits dlclose() on this library
compatible: var_added_elf_only _ZZ8edit_ctrvE1n: New exported symbol not declared in any public header: _ZZ8edit_ctrvE1n
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: public_surface_grew <surface>: public surface grew: 688 → 690 declarations (+2)
```

## `cxx_more.gnu_unique_static_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.gnu_unique_static_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['edit_bump'], 'functions': ['edit_bump']})
```text
binary: added _Z9edit_bumpv
source: added _Z9edit_bumpv
```

## `cxx_more.gnu_unique_static_added@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['edit_bump'], 'functions': ['edit_bump']})
```text
compatible: func_added _Z8edit_ctrv: New public function: edit_ctr
compatible: func_added _Z9edit_bumpv: New public function: edit_bump
risk: symbol_binding_became_unique _ZZ8edit_ctrvE1n: Symbol binding became GNU_UNIQUE: _ZZ8edit_ctrvE1n — inhibits dlclose() on this library
compatible: var_added_elf_only _ZZ8edit_ctrvE1n: New exported symbol not declared in any public header: _ZZ8edit_ctrvE1n
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: public_surface_grew <surface>: public surface grew: 688 → 690 declarations (+2)
```

## `cxx_more.gnu_unique_static_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['edit_bump'], 'functions': ['edit_bump']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 2 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 1 Added variable symbol not referenced by debug info
2 Added function symbols not referenced by debug info:
  [A] _Z8edit_ctrv
  [A] _Z9edit_bumpv
1 Added variable symbol not referenced by debug info:
```

## `cxx_more.allocator_replacement_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.allocator_replacement_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.allocator_replacement_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 5 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
5 Added functions:
  [A] 'function void operator delete(void*)'    {_ZdlPv}
  [A] 'function void operator delete(void*, std::size_t)'    {_ZdlPvm}
  [A] 'function void* operator new(std::size_t)'    {_Znwm}
  [A] 'method std::bad_alloc::bad_alloc()'    {_ZNSt9bad_allocC2Ev, aliases _ZNSt9bad_allocC1Ev}
  [A] 'method std::exception::exception()'    {_ZNSt9exceptionC2Ev, aliases _ZNSt9exceptionC1Ev}
```

## `cxx_more.allocator_replacement_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.allocator_replacement_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.allocator_replacement_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 7 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
7 Added function symbols not referenced by debug info:
  [A] _ZNSt9bad_allocC1Ev
  [A] _ZNSt9bad_allocC2Ev, aliases _ZNSt9bad_allocC1Ev
  [A] _ZNSt9exceptionC1Ev, aliases _ZNSt9exceptionC2Ev
```

## `cxx_more.std_template_instance_exported@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['vec_sum'], 'functions': ['vec_sum']})
```text
binary: added _Z7vec_sumi
source: added _Z7vec_sumi
```

## `cxx_more.std_template_instance_exported@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['vec_sum'], 'functions': ['vec_sum']})
```text
binary: added _Z7vec_sumi
source: added _Z7vec_sumi
```

## `cxx_more.std_template_instance_exported@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['vec_sum'], 'functions': ['vec_sum']})
```text
compatible: func_added _Z7vec_sumi: New public function: vec_sum
compatible: needed_added DT_NEEDED: New dependency added: libgcc_s.so.1
risk: symbol_version_required_added GCC_3.0: New symbol version requirement: GCC_3.0 (from libgcc_s.so.1)
risk: runtime_floor_raised libgcc_s.so.1:GCC: Runtime floor raised for libgcc_s.so.1:  → GCC_3.0 (required by: _Unwind_Resume@GCC_3.0)
risk: symbol_version_required_added GLIBCXX_3.4.29: New symbol version requirement: GLIBCXX_3.4.29 (from libstdc++.so.6)
risk: runtime_floor_raised libstdc++.so.6:GLIBCXX: Runtime floor raised for libstdc++.so.6: GLIBCXX_3.4 → GLIBCXX_3.4.29 (required by: _ZSt28__throw_bad_array_n
risk: imported_symbol_added _Unwind_Resume: New imported symbol: _Unwind_Resume@GCC_3.0
compatible: imported_symbol_added _ZSt17__throw_bad_allocv: New imported symbol: _ZSt17__throw_bad_allocv@GLIBCXX_3.4
```

## `cxx_more.std_template_instance_exported@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.std_template_instance_exported@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['vec_sum'], 'functions': ['vec_sum']})
```text
binary: added _Z7vec_sumi
source: added _Z7vec_sumi
```

## `cxx_more.std_template_instance_exported@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['vec_sum'], 'functions': ['vec_sum']})
```text
compatible: func_added _Z7vec_sumi: New public function: vec_sum
compatible: needed_added DT_NEEDED: New dependency added: libgcc_s.so.1
risk: symbol_version_required_added GCC_3.0: New symbol version requirement: GCC_3.0 (from libgcc_s.so.1)
risk: runtime_floor_raised libgcc_s.so.1:GCC: Runtime floor raised for libgcc_s.so.1:  → GCC_3.0 (required by: _Unwind_Resume@GCC_3.0)
risk: symbol_version_required_added GLIBCXX_3.4.29: New symbol version requirement: GLIBCXX_3.4.29 (from libstdc++.so.6)
risk: runtime_floor_raised libstdc++.so.6:GLIBCXX: Runtime floor raised for libstdc++.so.6: GLIBCXX_3.4 → GLIBCXX_3.4.29 (required by: _ZSt28__throw_bad_array_n
risk: imported_symbol_added _Unwind_Resume: New imported symbol: _Unwind_Resume@GCC_3.0
compatible: imported_symbol_added _ZSt17__throw_bad_allocv: New imported symbol: _ZSt17__throw_bad_allocv@GLIBCXX_3.4
```

## `cxx_more.std_template_instance_exported@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['vec_sum'], 'functions': ['vec_sum']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 39 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
39 Added function symbols not referenced by debug info:
  [A] _Z7vec_sumi
  [A] _ZNKSt6vectorIiSaIiEE4sizeEv
  [A] _ZNSt12_Destroy_auxILb1EE9__destroyIPiEEvT_S3_
```

## `cxx_more.class_rtti_became_protected@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})

## `cxx_more.class_rtti_became_protected@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})

## `cxx_more.class_rtti_became_protected@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})
```text
risk: func_visibility_protected_changed _ZN4Base1mEv: ELF symbol visibility changed: _ZN4Base1mEv (default → protected); symbol still exported, interposition se
risk: func_visibility_protected_changed _ZN4BaseD0Ev: ELF symbol visibility changed: _ZN4BaseD0Ev (default → protected); symbol still exported, interposition se
risk: func_visibility_protected_changed _ZN4BaseD1Ev: ELF symbol visibility changed: _ZN4BaseD1Ev (default → protected); symbol still exported, interposition se
risk: func_visibility_protected_changed _ZN4BaseD2Ev: ELF symbol visibility changed: _ZN4BaseD2Ev (default → protected); symbol still exported, interposition se
risk: protected_visibility_changed _ZTS4Base: Data symbol visibility changed: _ZTS4Base (default → protected); may break copy relocations
risk: protected_visibility_changed _ZTI4Base: Data symbol visibility changed: _ZTI4Base (default → protected); may break copy relocations
risk: protected_visibility_changed _ZTV4Base: Data symbol visibility changed: _ZTV4Base (default → protected); may break copy relocations
risk: vtable_symbol_identity_changed _ZTS4Base: RTTI/vtable symbol changed: _ZTS4Base (visibility default → protected); may break cross-DSO RTTI
```

## `cxx_more.class_rtti_became_protected@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})

## `cxx_more.class_rtti_became_protected@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.class_rtti_became_protected@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})

## `cxx_more.class_rtti_became_protected@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})
```text
risk: func_visibility_protected_changed _ZN4Base1mEv: ELF symbol visibility changed: _ZN4Base1mEv (default → protected); symbol still exported, interposition se
risk: func_visibility_protected_changed _ZN4BaseD0Ev: ELF symbol visibility changed: _ZN4BaseD0Ev (default → protected); symbol still exported, interposition se
risk: func_visibility_protected_changed _ZN4BaseD1Ev: ELF symbol visibility changed: _ZN4BaseD1Ev (default → protected); symbol still exported, interposition se
risk: func_visibility_protected_changed _ZN4BaseD2Ev: ELF symbol visibility changed: _ZN4BaseD2Ev (default → protected); symbol still exported, interposition se
risk: protected_visibility_changed _ZTS4Base: Data symbol visibility changed: _ZTS4Base (default → protected); may break copy relocations
risk: protected_visibility_changed _ZTI4Base: Data symbol visibility changed: _ZTI4Base (default → protected); may break copy relocations
risk: protected_visibility_changed _ZTV4Base: Data symbol visibility changed: _ZTV4Base (default → protected); may break copy relocations
risk: vtable_symbol_identity_changed _ZTS4Base: RTTI/vtable symbol changed: _ZTS4Base (visibility default → protected); may break cross-DSO RTTI
```

## `cxx_more.class_rtti_became_protected@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})

## `cxx_more.ctor_explicit_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['Widget'], 'functions': ['Widget']})

## `cxx_more.ctor_explicit_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['Widget'], 'functions': ['Widget']})

## `cxx_more.ctor_explicit_removed@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['Widget'], 'functions': ['Widget']})
```text
risk: ctor_explicit_removed __abicheck_ctor__Widget(int): Constructor/conversion lost `explicit` specifier: Widget
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.ctor_explicit_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['Widget'], 'functions': ['Widget']})

## `cxx_more.ctor_explicit_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.ctor_explicit_removed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['Widget'], 'functions': ['Widget']})

## `cxx_more.ctor_explicit_removed@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['Widget'], 'functions': ['Widget']})
```text
risk: ctor_explicit_removed __abicheck_ctor__Widget(int): Constructor/conversion lost `explicit` specifier: Widget
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.ctor_explicit_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['Widget'], 'functions': ['Widget']})

## `cxx_more.ctor_explicit_added@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['Gadget']})

## `cxx_more.ctor_explicit_added@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['Gadget']})

## `cxx_more.ctor_explicit_added@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity'] (expected {'entity': ['Gadget']})
```text
api_break: ctor_explicit_added __abicheck_ctor__Gadget(long int): Constructor/conversion gained `explicit` specifier: Gadget
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.ctor_explicit_added@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity'] (expected {'entity': ['Gadget']})

## `cxx_more.ctor_explicit_added@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.ctor_explicit_added@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['Gadget']})

## `cxx_more.ctor_explicit_added@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity'] (expected {'entity': ['Gadget']})
```text
api_break: ctor_explicit_added __abicheck_ctor__Gadget(long int): Constructor/conversion gained `explicit` specifier: Gadget
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.ctor_explicit_added@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity'] (expected {'entity': ['Gadget']})

## `cxx_more.class_became_final@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['Widget'], 'functions': ['Widget']})

## `cxx_more.class_became_final@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['Widget'], 'functions': ['Widget']})

## `cxx_more.class_became_final@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['functions'] (expected {'functions': ['Widget']})
```text
api_break: type_became_final Widget: Class gained `final` specifier: Widget — consumers that derive from it no longer compile
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.class_became_final@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['Widget'], 'functions': ['Widget']})

## `cxx_more.class_became_final@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.class_became_final@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['Widget'], 'functions': ['Widget']})

## `cxx_more.class_became_final@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['functions'] (expected {'functions': ['Widget']})
```text
api_break: type_became_final Widget: Class gained `final` specifier: Widget — consumers that derive from it no longer compile
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.class_became_final@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['Widget'], 'functions': ['Widget']})

## `cxx_more.class_lost_final@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.class_lost_final@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.class_lost_final@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.class_lost_final@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.class_lost_final@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.class_lost_final@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.override_specifier_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})

## `cxx_more.override_specifier_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})

## `cxx_more.override_specifier_added@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})
```text
compatible: func_override_specifier_added _ZN7Derived1mEv: Method gained `override` specifier: m
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.override_specifier_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})

## `cxx_more.override_specifier_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.override_specifier_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})

## `cxx_more.override_specifier_added@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})
```text
compatible: func_override_specifier_added _ZN7Derived1mEv: Method gained `override` specifier: m
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.override_specifier_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})

## `cxx_more.member_noexcept_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['safe'], 'functions': ['safe']})

## `cxx_more.member_noexcept_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['safe'], 'functions': ['safe']})

## `cxx_more.member_noexcept_removed@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['safe'], 'functions': ['safe']})
```text
risk: func_noexcept_removed _ZN4Calc4safeEv: noexcept specifier removed: safe
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.member_noexcept_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['safe'], 'functions': ['safe']})

## `cxx_more.member_noexcept_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.member_noexcept_removed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['safe'], 'functions': ['safe']})

## `cxx_more.member_noexcept_removed@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['safe'], 'functions': ['safe']})
```text
risk: func_noexcept_removed _ZN4Calc4safeEv: noexcept specifier removed: safe
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.member_noexcept_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['safe'], 'functions': ['safe']})

## `cxx_more.method_access_narrowed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['n', 'r'], 'functions': ['fill', 'n', 'r']})
```text
binary/low: _ZN4Calc1nEi Method_Became_Protected
source/medium: _ZN4Calc1nEi Method_Became_Protected
```

## `cxx_more.method_access_narrowed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['n', 'r'], 'functions': ['fill', 'n', 'r']})
```text
binary/low: _ZN4Calc1nEi Method_Became_Protected
source/medium: _ZN4Calc1nEi Method_Became_Protected
```

## `cxx_more.method_access_narrowed@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['n', 'r'], 'functions': ['fill', 'n', 'r']})
```text
api_break: method_access_changed _ZN4Calc1nEi: Method access level narrowed: n (public → protected)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.method_access_narrowed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['n', 'r'], 'functions': ['fill', 'n', 'r']})

## `cxx_more.method_access_narrowed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.method_access_narrowed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['n', 'r'], 'functions': ['fill', 'n', 'r']})
```text
binary/low: _ZN4Calc1nEi Method_Became_Protected
source/medium: _ZN4Calc1nEi Method_Became_Protected
```

## `cxx_more.method_access_narrowed@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['n', 'r'], 'functions': ['fill', 'n', 'r']})
```text
api_break: method_access_changed _ZN4Calc1nEi: Method access level narrowed: n (public → protected)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.method_access_narrowed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['n', 'r'], 'functions': ['fill', 'n', 'r']})

## `cxx_more.field_access_narrowed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
```text
Functions changes summary: 0 Removed, 0 Changed (6 filtered out), 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `cxx_more.field_access_narrowed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_access_narrowed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []

## `cxx_more.field_became_mutable@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Calc'], 'fields': ['cache']})

## `cxx_more.field_became_mutable@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Calc'], 'fields': ['cache']})

## `cxx_more.field_became_mutable@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_became_mutable@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Calc'], 'fields': ['cache']})

## `cxx_more.hidden_friend_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.hidden_friend_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.hidden_friend_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.hidden_friend_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.hidden_friend_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.hidden_friend_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.hidden_friend_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.hidden_friend_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.hidden_friend_removed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []

## `cxx_more.hidden_friend_removed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.hidden_friend_removed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.hidden_friend_removed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []

## `cxx_more.enum_became_scoped@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['tone'], 'functions': ['tone_code']})

## `cxx_more.enum_became_scoped@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['tone'], 'functions': ['tone_code']})

## `cxx_more.enum_became_scoped@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['functions'] (expected {'functions': ['tone_code']})
```text
api_break: enum_became_scoped tone: Enum became scoped: tone — unqualified enumerator lookup and implicit int conversion no longer compile
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.enum_became_scoped@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['tone'], 'functions': ['tone_code']})

## `cxx_more.enum_became_scoped@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.enum_became_scoped@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['tone'], 'functions': ['tone_code']})

## `cxx_more.enum_became_scoped@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['functions'] (expected {'functions': ['tone_code']})
```text
api_break: enum_became_scoped tone: Enum became scoped: tone — unqualified enumerator lookup and implicit int conversion no longer compile
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.enum_became_scoped@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['tone'], 'functions': ['tone_code']})

## `cxx_more.enum_lost_scoped@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['shade'], 'functions': ['shade_code']})

## `cxx_more.enum_lost_scoped@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['shade'], 'functions': ['shade_code']})

## `cxx_more.enum_lost_scoped@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['functions'] (expected {'functions': ['shade_code']})
```text
risk: enum_lost_scoped shade: Enum lost scoped status: shade — implicit int conversion silently reappears
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.enum_lost_scoped@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['shade'], 'functions': ['shade_code']})

## `cxx_more.enum_lost_scoped@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.enum_lost_scoped@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['shade'], 'functions': ['shade_code']})

## `cxx_more.enum_lost_scoped@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['functions'] (expected {'functions': ['shade_code']})
```text
risk: enum_lost_scoped shade: Enum lost scoped status: shade — implicit int conversion silently reappears
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.enum_lost_scoped@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['shade'], 'functions': ['shade_code']})

## `cxx_more.method_became_static@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})
```text
binary/high: _ZN4Calc1mEi Method_Became_Static
source/safe: _ZN4Calc1mEi Method_Became_Static
```

## `cxx_more.method_became_static@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})
```text
binary/high: _ZN4Calc1mEi Method_Became_Static
source/safe: _ZN4Calc1mEi Method_Became_Static
```

## `cxx_more.method_became_static@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})
```text
breaking: func_static_changed _ZN4Calc1mEi: Static qualifier changed: m
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.method_became_static@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'method int Calc::m(int)' at edit_seed.h:16:1 has some indirect sub-type changes:
    'method int Calc::m(int)'  at edit_seed.h:16:1 became static
    parameter 0 of type 'Calc*' was removed
```

## `cxx_more.method_became_static@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.method_became_static@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})
```text
binary/high: _ZN4Calc1mEi Method_Became_Static
source/safe: _ZN4Calc1mEi Method_Became_Static
```

## `cxx_more.method_became_static@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})
```text
breaking: func_static_changed _ZN4Calc1mEi: Static qualifier changed: m
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.method_became_static@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['m'], 'functions': ['m']})

## `cxx_more.method_ref_qualified@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['r'], 'functions': ['r']})
```text
binary: removed _ZN4Calc1rEv
binary: added _ZNR4Calc1rEv
source: removed _ZN4Calc1rEv
source: added _ZNR4Calc1rEv
```

## `cxx_more.method_ref_qualified@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['r'], 'functions': ['r']})
```text
binary: removed _ZN4Calc1rEv
```

## `cxx_more.method_ref_qualified@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['r'], 'functions': ['r']})
```text
breaking: func_removed _ZN4Calc1rEv: Public function removed: r
compatible: func_added _ZNR4Calc1rEv: New public function: r
breaking: func_ref_qual_changed _ZN4Calc1rEv: Ref-qualifier changed: r ('' → '&')
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.method_ref_qualified@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.method_ref_qualified@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['r'], 'functions': ['r']})
```text
binary: removed _ZN4Calc1rEv
```

## `cxx_more.method_ref_qualified@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['r'], 'functions': ['r']})
```text
breaking: func_removed _ZN4Calc1rEv: Public function removed: r
compatible: func_added _ZNR4Calc1rEv: New public function: r
breaking: func_ref_qual_changed _ZN4Calc1rEv: Ref-qualifier changed: r ('' → '&')
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.method_ref_qualified@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['r'], 'functions': ['r']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _ZN4Calc1rEv
1 Added function symbol not referenced by debug info:
  [A] _ZNR4Calc1rEv
```

## `cxx_more.method_deleted@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['n'], 'functions': ['fill', 'n']})
```text
binary: removed _ZN4Calc1nEi
source: removed _ZN4Calc1nEi
```

## `cxx_more.method_deleted@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['n'], 'functions': ['fill', 'n']})
```text
binary: removed _ZN4Calc1nEi
```

## `cxx_more.method_deleted@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['n'], 'functions': ['fill', 'n']})
```text
breaking: func_removed _ZN4Calc1nEi: Public function removed: n
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_shrank <surface>: public surface shrank: 688 → 687 declarations (-1)
```

## `cxx_more.method_deleted@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['functions'] (expected {'functions': ['fill', 'n']})
```text
Functions changes summary: 1 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 Removed function:
  [D] 'method int Calc::n(int)'    {_ZN4Calc1nEi}
```

## `cxx_more.method_deleted@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.method_deleted@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['n'], 'functions': ['fill', 'n']})
```text
binary: removed _ZN4Calc1nEi
```

## `cxx_more.method_deleted@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['n'], 'functions': ['fill', 'n']})
```text
breaking: func_removed _ZN4Calc1nEi: Public function removed: n
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_shrank <surface>: public surface shrank: 688 → 687 declarations (-1)
```

## `cxx_more.method_deleted@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['n'], 'functions': ['fill', 'n']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _ZN4Calc1nEi
```

## `cxx_more.const_overload_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
binary: removed _ZNK4Calc1gEv
source/medium: Calc Removed_Const_Overload _ZN4Calc1gEv
source: removed _ZNK4Calc1gEv
```

## `cxx_more.const_overload_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
binary: removed _ZNK4Calc1gEv
source/medium: Calc Removed_Const_Overload _ZN4Calc1gEv
source: removed _ZNK4Calc1gEv
```

## `cxx_more.const_overload_removed@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
breaking: func_removed _ZNK4Calc1gEv: Public function removed: g
api_break: removed_const_overload _ZNK4Calc1gEv: Const method overload removed: g (non-const version still exists)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_shrank <surface>: public surface shrank: 688 → 687 declarations (-1)
```

## `cxx_more.const_overload_removed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.const_overload_removed@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
binary: removed _ZNK4Calc1gEv
source/medium: Calc Removed_Const_Overload _ZN4Calc1gEv
source: removed _ZNK4Calc1gEv
```

## `cxx_more.const_overload_removed@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
breaking: func_removed _ZNK4Calc1gEv: Public function removed: g
api_break: removed_const_overload _ZNK4Calc1gEv: Const method overload removed: g (non-const version still exists)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_shrank <surface>: public surface shrank: 688 → 687 declarations (-1)
```

## `cxx_more.const_overload_removed@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _ZNK4Calc1gEv
```

## `cxx_more.overload_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['pick'], 'functions': ['pick']})
```text
binary: added _Z4pickd
source: added _Z4pickd
```

## `cxx_more.overload_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['pick'], 'functions': ['pick']})
```text
binary: added _Z4pickd
source: added _Z4pickd
```

## `cxx_more.overload_added@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['pick'], 'functions': ['pick']})
```text
compatible: func_added _Z4pickd: New public function: pick
risk: overload_added _Z4picki: Overload added to previously non-overloaded function: pick — `&pick` becomes ambiguous and overload resolution may change
risk: overload_ambiguity_introduced _Z4pickd: Overload makes an existing call ambiguous: pick({}) — was (int), new (double)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: public_surface_grew <surface>: public surface grew: 688 → 689 declarations (+1)
```

## `cxx_more.overload_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.overload_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['pick'], 'functions': ['pick']})
```text
binary: added _Z4pickd
source: added _Z4pickd
```

## `cxx_more.overload_added@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['pick'], 'functions': ['pick']})
```text
compatible: func_added _Z4pickd: New public function: pick
risk: overload_added _Z4picki: Overload added to previously non-overloaded function: pick — `&pick` becomes ambiguous and overload resolution may change
risk: overload_ambiguity_introduced _Z4pickd: Overload makes an existing call ambiguous: pick({}) — was (int), new (double)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: public_surface_grew <surface>: public surface grew: 688 → 689 declarations (+1)
```

## `cxx_more.overload_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['pick'], 'functions': ['pick']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 1 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Added function symbol not referenced by debug info:
  [A] _Z4pickd
```

## `cxx_more.pure_virtual_added@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.inline_namespace_bumped@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['f1'], 'functions': ['f1']})
```text
binary: removed _ZN3lib2v12f1Ei
binary: removed _ZN3lib2v12f2Ei
binary: added _ZN3lib2v22f1Ei
binary: added _ZN3lib2v22f2Ei
source: removed _ZN3lib2v12f1Ei
source: removed _ZN3lib2v12f2Ei
source: added _ZN3lib2v22f1Ei
source: added _ZN3lib2v22f2Ei
```

## `cxx_more.inline_namespace_bumped@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['f1'], 'functions': ['f1']})
```text
binary: removed _ZN3lib2v12f1Ei
binary: removed _ZN3lib2v12f2Ei
binary: added _ZN3lib2v22f1Ei
binary: added _ZN3lib2v22f2Ei
source: removed _ZN3lib2v12f1Ei
source: removed _ZN3lib2v12f2Ei
source: added _ZN3lib2v22f1Ei
source: added _ZN3lib2v22f2Ei
```

## `cxx_more.inline_namespace_bumped@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['f1'], 'functions': ['f1']})
```text
breaking: func_removed _ZN3lib2v12f1Ei: Public function removed: f1
breaking: func_removed _ZN3lib2v12f2Ei: Public function removed: f2
compatible: func_added _ZN3lib2v22f1Ei: New public function: f1
compatible: func_added _ZN3lib2v22f2Ei: New public function: f2
breaking: symbol_renamed_batch batch_rename:v1→v2: Batch symbol rename detected (namespace refactoring): namespace segment 'v1' → 'v2' on 2 symbols (lib::v1::f1
breaking: inline_namespace_moved __inline_namespace_move: Inline namespace move detected: 2 symbols appear to have moved between inline namespace versions (e.g.
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
```

## `cxx_more.inline_namespace_bumped@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.inline_namespace_bumped@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['f1'], 'functions': ['f1']})
```text
binary: removed _ZN3lib2v12f1Ei
binary: removed _ZN3lib2v12f2Ei
binary: added _ZN3lib2v22f1Ei
binary: added _ZN3lib2v22f2Ei
source: removed _ZN3lib2v12f1Ei
source: removed _ZN3lib2v12f2Ei
source: added _ZN3lib2v22f1Ei
source: added _ZN3lib2v22f2Ei
```

## `cxx_more.inline_namespace_bumped@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['f1'], 'functions': ['f1']})
```text
breaking: func_removed _ZN3lib2v12f1Ei: Public function removed: f1
breaking: func_removed _ZN3lib2v12f2Ei: Public function removed: f2
compatible: func_added _ZN3lib2v22f1Ei: New public function: f1
compatible: func_added _ZN3lib2v22f2Ei: New public function: f2
breaking: symbol_renamed_batch batch_rename:v1→v2: Batch symbol rename detected (namespace refactoring): namespace segment 'v1' → 'v2' on 2 symbols (lib::v1::f1
breaking: inline_namespace_moved __inline_namespace_move: Inline namespace move detected: 2 symbols appear to have moved between inline namespace versions (e.g.
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
```

## `cxx_more.inline_namespace_bumped@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['f1'], 'functions': ['f1']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 2 Removed, 2 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
2 Removed function symbols not referenced by debug info:
  [D] _ZN3lib2v12f1Ei
  [D] _ZN3lib2v12f2Ei
2 Added function symbols not referenced by debug info:
```

## `cxx_more.abi_tag_added@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'tagf'], 'functions': ['__attribute__', 'tagf']})
```text
binary: removed _Z4tagfi
binary: added _Z4tagfB2v2i
source: removed _Z4tagfi
source: added _Z4tagfB2v2i
```

## `cxx_more.abi_tag_added@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'tagf'], 'functions': ['__attribute__', 'tagf']})
```text
binary: removed _Z4tagfi
```

## `cxx_more.abi_tag_added@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'tagf'], 'functions': ['__attribute__', 'tagf']})
```text
breaking: abi_tag_changed tagf: ABI-tag set changed for 'tagf': gained [abi:v2]. The mangled name encodes the tag, so the old symbol (_Z4tagfi) no longer exists
breaking: func_removed _Z4tagfi: Public function removed: tagf
compatible: func_added _Z4tagfB2v2i: New public function: tagf
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.abi_tag_added@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'tagf'], 'functions': ['__attribute__', 'tagf']})
```text
Functions changes summary: 1 Removed, 0 Changed, 1 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 Removed function:
  [D] 'function int tagf(int)'    {_Z4tagfi}
1 Added function:
  [A] 'function int tagf(int)'    {_Z4tagfB2v2i}
```

## `cxx_more.abi_tag_added@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.abi_tag_added@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'tagf'], 'functions': ['__attribute__', 'tagf']})
```text
binary: removed _Z4tagfi
```

## `cxx_more.abi_tag_added@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'tagf'], 'functions': ['__attribute__', 'tagf']})
```text
breaking: abi_tag_changed tagf: ABI-tag set changed for 'tagf': gained [abi:v2]. The mangled name encodes the tag, so the old symbol (_Z4tagfi) no longer exists
breaking: func_removed _Z4tagfi: Public function removed: tagf
compatible: func_added _Z4tagfB2v2i: New public function: tagf
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.abi_tag_added@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'tagf'], 'functions': ['__attribute__', 'tagf']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z4tagfi
1 Added function symbol not referenced by debug info:
  [A] _Z4tagfB2v2i
```

## `cxx_more.base_became_virtual@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: VD DataType_Size 
```

## `cxx_more.base_became_virtual@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 2 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 1 Added variable symbol not referenced by debug info
1 function with some indirect sub-type change:
  [C] 'method virtual VD::~VD(int)' at edit_seed.cpp:26:1 has some indirect sub-type changes:
    implicit parameter 0 of type 'VD*' has sub-type changes:
      in pointed to type 'struct VD' at edit_seed.h:35:1:
```

## `cxx_more.base_became_virtual@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.base_became_virtual@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: VD DataType_Size 
```

## `cxx_more.base_became_virtual@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 2 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 1 Added variable symbol not referenced by debug info
2 Added function symbols not referenced by debug info:
  [A] _ZTv0_n24_N2VDD0Ev
  [A] _ZTv0_n24_N2VDD1Ev
1 Added variable symbol not referenced by debug info:
```

## `cxx_more.bases_reordered@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: MI Base_Class_Position struct B2
```

## `cxx_more.bases_reordered@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.bases_reordered@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.bases_reordered@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.primary_base_grew@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: MI DataType_Size 
binary/low: B1 Added_Private_Field_And_Size pad
binary/low: B1 DataType_Size 
```

## `cxx_more.primary_base_grew@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.primary_base_grew@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: MI DataType_Size 
binary/low: B1 Added_Private_Field_And_Size pad
binary/low: B1 DataType_Size 
```

## `cxx_more.primary_base_grew@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'fields', 'size'] (expected {'entity': ['B1'], 'fields': ['pad'], 'size': [16, 24]})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 3 Removed, 3 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
3 Removed function symbols not referenced by debug info:
  [D] _ZThn16_N2MI2f2Ev
  [D] _ZThn16_N2MID0Ev
  [D] _ZThn16_N2MID1Ev
```

## `cxx_more.vptr_introduced@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})
```text
binary/low: Plain DataType_Size 
```

## `cxx_more.vptr_introduced@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})
```text
binary/low: Plain DataType_Size 
```

## `cxx_more.vptr_introduced@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})
```text
breaking: type_size_changed Plain: Size changed: Plain (32 → 128 bits)
breaking: type_alignment_changed Plain: Alignment changed: Plain (32 → 64 bits)
breaking: type_field_offset_changed Plain: Field offset changed: Plain::a (0 → 64 bits)
breaking: type_vtable_changed Plain: vtable changed: Plain
breaking: func_virtual_added _ZN5Plain3getEv: Function became virtual: get
breaking: vptr_introduced Plain: 'Plain' gained a vtable pointer (became polymorphic). sizeof grows and every data member's offset shifts by a pointer width; bi
breaking: trivially_copyable_lost Plain: 'Plain' is no longer trivially copyable. It is now passed and returned by value differently (via a hidden reference / n
risk: standard_layout_lost Plain: 'Plain' is no longer standard-layout. `offsetof` and C interoperability are no longer guaranteed and tail-padding reuse rules 
```

## `cxx_more.vptr_introduced@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.vptr_introduced@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})
```text
binary/low: Plain DataType_Size 
```

## `cxx_more.vptr_introduced@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})
```text
breaking: type_size_changed Plain: Size changed: Plain (32 → 128 bits)
breaking: type_alignment_changed Plain: Alignment changed: Plain (32 → 64 bits)
breaking: type_field_offset_changed Plain: Field offset changed: Plain::a (0 → 64 bits)
breaking: type_vtable_changed Plain: vtable changed: Plain
breaking: func_virtual_added _ZN5Plain3getEv: Function became virtual: get
breaking: vptr_introduced Plain: 'Plain' gained a vtable pointer (became polymorphic). sizeof grows and every data member's offset shifts by a pointer width; bi
breaking: trivially_copyable_lost Plain: 'Plain' is no longer trivially copyable. It is now passed and returned by value differently (via a hidden reference / n
risk: standard_layout_lost Plain: 'Plain' is no longer standard-layout. `offsetof` and C interoperability are no longer guaranteed and tail-padding reuse rules 
```

## `cxx_more.vptr_introduced@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 3 Added variable symbols not referenced by debug info
3 Added variable symbols not referenced by debug info:
  [A] _ZTI5Plain
  [A] _ZTS5Plain
  [A] _ZTV5Plain
```

## `cxx_more.method_became_pure_virtual@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})

## `cxx_more.method_became_pure_virtual@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})

## `cxx_more.method_became_pure_virtual@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})
```text
breaking: type_size_changed Plain: Size changed: Plain (32 → 128 bits)
breaking: type_alignment_changed Plain: Alignment changed: Plain (32 → 64 bits)
breaking: type_field_offset_changed Plain: Field offset changed: Plain::a (0 → 64 bits)
breaking: type_vtable_changed Plain: vtable changed: Plain
breaking: func_virtual_added _ZN5Plain3getEv: Function became virtual: get
breaking: vptr_introduced Plain: 'Plain' gained a vtable pointer (became polymorphic). sizeof grows and every data member's offset shifts by a pointer width; bi
breaking: trivially_copyable_lost Plain: 'Plain' is no longer trivially copyable. It is now passed and returned by value differently (via a hidden reference / n
risk: standard_layout_lost Plain: 'Plain' is no longer standard-layout. `offsetof` and C interoperability are no longer guaranteed and tail-padding reuse rules 
```

## `cxx_more.method_became_pure_virtual@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})

## `cxx_more.method_became_pure_virtual@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.method_became_pure_virtual@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})

## `cxx_more.method_became_pure_virtual@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})
```text
breaking: type_size_changed Plain: Size changed: Plain (32 → 128 bits)
breaking: type_alignment_changed Plain: Alignment changed: Plain (32 → 64 bits)
breaking: type_field_offset_changed Plain: Field offset changed: Plain::a (0 → 64 bits)
breaking: type_vtable_changed Plain: vtable changed: Plain
breaking: func_virtual_added _ZN5Plain3getEv: Function became virtual: get
breaking: vptr_introduced Plain: 'Plain' gained a vtable pointer (became polymorphic). sizeof grows and every data member's offset shifts by a pointer width; bi
breaking: trivially_copyable_lost Plain: 'Plain' is no longer trivially copyable. It is now passed and returned by value differently (via a hidden reference / n
risk: standard_layout_lost Plain: 'Plain' is no longer standard-layout. `offsetof` and C interoperability are no longer guaranteed and tail-padding reuse rules 
```

## `cxx_more.method_became_pure_virtual@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})

## `cxx_more.field_lost_mutable@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Quals'], 'fields': ['hits']})

## `cxx_more.field_lost_mutable@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Quals'], 'fields': ['hits']})

## `cxx_more.field_lost_mutable@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_lost_mutable@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Quals'], 'fields': ['hits']})

## `cxx_more.field_lost_const@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
```text
binary/low: Quals Field_Type k
binary/safe: Quals Field_Became_Non_Const k
source/safe: Quals Field_Became_Non_Const k
```

## `cxx_more.field_lost_const@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
```text
binary/low: Quals Field_Type k
binary/safe: Quals Field_Became_Non_Const k
source/safe: Quals Field_Became_Non_Const k
```

## `cxx_more.field_lost_const@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'method int Quals::get() const' at edit_seed.h:52:1 has some indirect sub-type changes:
    implicit parameter 0 of type 'const Quals*' has sub-type changes:
      in pointed to type 'const Quals':
        in unqualified underlying type 'struct Quals' at edit_seed.h:47:1:
          type size hasn't changed
```

## `cxx_more.field_lost_const@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_lost_const@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
```text
binary/low: Quals Field_Type k
binary/safe: Quals Field_Became_Non_Const k
source/safe: Quals Field_Became_Non_Const k
```

## `cxx_more.field_lost_const@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Quals'], 'fields': ['k']})

## `cxx_more.field_lost_volatile@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_lost_volatile@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Quals'], 'fields': ['reg']})

## `cxx_more.static_member_access_narrowed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})
```text
binary/low: _ZN5Quals5countE Global_Data_Became_Private
source/high: _ZN5Quals5countE Global_Data_Became_Private
```

## `cxx_more.static_member_access_narrowed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})
```text
binary/low: _ZN5Quals5countE Global_Data_Became_Private
source/high: _ZN5Quals5countE Global_Data_Became_Private
```

## `cxx_more.static_member_access_narrowed@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})
```text
api_break: var_access_changed _ZN5Quals5countE: Variable access level narrowed: count (public → private)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.static_member_access_narrowed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added variable
```

## `cxx_more.static_member_access_narrowed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.static_member_access_narrowed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})
```text
binary/low: _ZN5Quals5countE Global_Data_Became_Private
source/high: _ZN5Quals5countE Global_Data_Became_Private
```

## `cxx_more.static_member_access_narrowed@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})
```text
api_break: var_access_changed _ZN5Quals5countE: Variable access level narrowed: count (public → private)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.static_member_access_narrowed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['get'], 'functions': ['get']})

## `cxx_more.type_lost_abstract@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['area']})
```text
binary/safe: Shape Virtual_Method_Became_Non_Pure _ZN5Shape4areaEv
binary: added _ZN5Shape4areaEv
source/safe: Shape Virtual_Method_Became_Non_Pure _ZN5Shape4areaEv
```

## `cxx_more.type_lost_abstract@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['area']})
```text
binary/safe: Shape Virtual_Method_Became_Non_Pure _ZN5Shape4areaEv
binary: added _ZN5Shape4areaEv
source/safe: Shape Virtual_Method_Became_Non_Pure _ZN5Shape4areaEv
```

## `cxx_more.type_lost_abstract@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity'] (expected {'entity': ['area']})
```text
compatible: func_export_added _ZN5Shape4areaEv: Function now exported by the binary while its declaration remains present: area
compatible: imported_symbol_removed __cxa_pure_virtual: Imported symbol no longer required: __cxa_pure_virtual@CXXABI_1.3
compatible: type_lost_abstract Shape: Class lost abstract status: Shape
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.type_lost_abstract@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.type_lost_abstract@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['area']})
```text
binary/safe: Shape Virtual_Method_Became_Non_Pure _ZN5Shape4areaEv
binary: added _ZN5Shape4areaEv
source/safe: Shape Virtual_Method_Became_Non_Pure _ZN5Shape4areaEv
```

## `cxx_more.type_lost_abstract@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity'] (expected {'entity': ['area']})
```text
compatible: func_export_added _ZN5Shape4areaEv: Function now exported by the binary while its declaration remains present: area
compatible: imported_symbol_removed __cxa_pure_virtual: Imported symbol no longer required: __cxa_pure_virtual@CXXABI_1.3
compatible: type_lost_abstract Shape: Class lost abstract status: Shape
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.type_lost_abstract@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; exit bits ['abi_change']
- missed details: ['entity'] (expected {'entity': ['area']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 1 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Added function symbol not referenced by debug info:
  [A] _ZN5Shape4areaEv
```

## `cxx_more.override_specifier_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['h']})

## `cxx_more.override_specifier_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['h']})

## `cxx_more.override_specifier_removed@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity'] (expected {'entity': ['h']})
```text
risk: func_override_specifier_removed _ZN4ODer1hEv: Method lost `override` specifier: h
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.override_specifier_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['h']})

## `cxx_more.override_specifier_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.override_specifier_removed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['h']})

## `cxx_more.override_specifier_removed@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity'] (expected {'entity': ['h']})
```text
risk: func_override_specifier_removed _ZN4ODer1hEv: Method lost `override` specifier: h
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.override_specifier_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['h']})

## `cxx_more.field_default_initializer_changed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['4', '8']})

## `cxx_more.field_default_initializer_changed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['4', '8']})

## `cxx_more.field_default_initializer_changed@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['fields'] (expected {'fields': ['4', '8']})
```text
compatible: field_default_initializer_changed Cfg: Field default initializer changed: Cfg::depth (4 → 8)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.field_default_initializer_changed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['4', '8']})

## `cxx_more.field_default_initializer_changed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_default_initializer_changed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['4', '8']})

## `cxx_more.field_default_initializer_changed@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['fields'] (expected {'fields': ['4', '8']})
```text
compatible: field_default_initializer_changed Cfg: Field default initializer changed: Cfg::depth (4 → 8)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.field_default_initializer_changed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['4', '8']})

## `cxx_more.field_default_initializer_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['1', 'mode']})

## `cxx_more.field_default_initializer_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['1', 'mode']})

## `cxx_more.field_default_initializer_removed@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['fields'] (expected {'fields': ['1', 'mode']})
```text
risk: field_default_initializer_removed Cfg: Field lost its default initializer: Cfg::mode
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.field_default_initializer_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['1', 'mode']})

## `cxx_more.field_default_initializer_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_default_initializer_removed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['1', 'mode']})

## `cxx_more.field_default_initializer_removed@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['fields'] (expected {'fields': ['1', 'mode']})
```text
risk: field_default_initializer_removed Cfg: Field lost its default initializer: Cfg::mode
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.field_default_initializer_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['1', 'mode']})

## `cxx_more.field_deprecated_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['legacy']})

## `cxx_more.field_deprecated_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['legacy']})

## `cxx_more.field_deprecated_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['legacy']})

## `cxx_more.field_deprecated_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_deprecated_removed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['legacy']})

## `cxx_more.field_deprecated_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Cfg'], 'fields': ['legacy']})

## `cxx_more.static_member_access_widened@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['sum'], 'functions': ['sum']})

## `cxx_more.static_member_access_widened@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['sum'], 'functions': ['sum']})

## `cxx_more.static_member_access_widened@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['sum'], 'functions': ['sum']})
```text
compatible: var_access_widened _ZN3Cfg5totalE: Variable access level widened: total (private → public)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.static_member_access_widened@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['sum'], 'functions': ['sum']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added variable
```

## `cxx_more.static_member_access_widened@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.static_member_access_widened@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['sum'], 'functions': ['sum']})

## `cxx_more.static_member_access_widened@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['sum'], 'functions': ['sum']})
```text
compatible: var_access_widened _ZN3Cfg5totalE: Variable access level widened: total (private → public)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.static_member_access_widened@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['sum'], 'functions': ['sum']})

## `cxx_more.param_default_value_changed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['tune'], 'functions': ['tune']})

## `cxx_more.param_default_value_changed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['tune'], 'functions': ['tune']})
```text
binary/low: _Z4tuneii Parameter_Default_Value_Changed
source/safe: _Z4tuneii Parameter_Default_Value_Changed
```

## `cxx_more.param_default_value_changed@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['tune'], 'functions': ['tune']})
```text
compatible: param_default_value_changed _Z4tuneii: Parameter default changed: tune param b
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.param_default_value_changed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['tune'], 'functions': ['tune']})

## `cxx_more.param_default_value_changed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.param_default_value_changed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['tune'], 'functions': ['tune']})
```text
binary/low: _Z4tuneii Parameter_Default_Value_Changed
source/safe: _Z4tuneii Parameter_Default_Value_Changed
```

## `cxx_more.param_default_value_changed@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['tune'], 'functions': ['tune']})
```text
compatible: param_default_value_changed _Z4tuneii: Parameter default changed: tune param b
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.param_default_value_changed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['tune'], 'functions': ['tune']})

## `cxx_more.param_default_value_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['shrink'], 'functions': ['shrink']})

## `cxx_more.param_default_value_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['shrink'], 'functions': ['shrink']})
```text
binary/low: _Z6shrinkii Parameter_Default_Value_Removed
source/medium: _Z6shrinkii Parameter_Default_Value_Removed
```

## `cxx_more.param_default_value_removed@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['shrink'], 'functions': ['shrink']})
```text
api_break: param_default_value_removed _Z6shrinkii: Parameter default removed: shrink param b
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.param_default_value_removed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['shrink'], 'functions': ['shrink']})

## `cxx_more.param_default_value_removed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.param_default_value_removed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['shrink'], 'functions': ['shrink']})
```text
binary/low: _Z6shrinkii Parameter_Default_Value_Removed
source/medium: _Z6shrinkii Parameter_Default_Value_Removed
```

## `cxx_more.param_default_value_removed@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['shrink'], 'functions': ['shrink']})
```text
api_break: param_default_value_removed _Z6shrinkii: Parameter default removed: shrink param b
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.param_default_value_removed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['shrink'], 'functions': ['shrink']})

## `cxx_more.param_restrict_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['fill'], 'functions': ['fill']})
```text
binary/low: _Z4fillPii Parameter_Type
binary/safe: _Z4fillPii Parameter_Became_Non_Restrict
source/safe: _Z4fillPii Parameter_Became_Non_Restrict
```

## `cxx_more.param_restrict_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['fill'], 'functions': ['fill']})
```text
binary/low: _Z4fillPii Parameter_Type
binary/safe: _Z4fillPii Parameter_Became_Non_Restrict
source/safe: _Z4fillPii Parameter_Became_Non_Restrict
```

## `cxx_more.param_restrict_removed@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['fill'], 'functions': ['fill']})
```text
compatible: param_restrict_changed _Z4fillPii: Parameter restrict qualifier removed: fill param p
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.param_restrict_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['fill'], 'functions': ['fill']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `cxx_more.param_restrict_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.param_restrict_removed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['fill'], 'functions': ['fill']})
```text
binary/low: _Z4fillPii Parameter_Type
binary/safe: _Z4fillPii Parameter_Became_Non_Restrict
source/safe: _Z4fillPii Parameter_Became_Non_Restrict
```

## `cxx_more.param_restrict_removed@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['fill'], 'functions': ['fill']})
```text
compatible: param_restrict_changed _Z4fillPii: Parameter restrict qualifier removed: fill param p
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.param_restrict_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['fill'], 'functions': ['fill']})

## `cxx_more.extern_c_linkage_removed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.virtual_noexcept_added@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.virtual_noexcept_added@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.virtual_noexcept_added@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity'] (expected {'entity': ['f']})
```text
compatible: func_noexcept_added _ZN2VN1fEv: noexcept specifier added: f
api_break: func_virtual_noexcept_added _ZN2VN1fEv: noexcept added to virtual method: f (an overrider without noexcept no longer compiles)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.virtual_noexcept_added@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.virtual_noexcept_added@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.virtual_noexcept_added@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.virtual_noexcept_added@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity'] (expected {'entity': ['f']})
```text
compatible: func_noexcept_added _ZN2VN1fEv: noexcept specifier added: f
api_break: func_virtual_noexcept_added _ZN2VN1fEv: noexcept added to virtual method: f (an overrider without noexcept no longer compiles)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.virtual_noexcept_added@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.converting_ctor_overload_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['CO'], 'functions': ['CO']})
```text
binary: added _ZN2COC1El
binary: added _ZN2COC2El
source: added _ZN2COC1El
source: added _ZN2COC2El
```

## `cxx_more.converting_ctor_overload_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['CO'], 'functions': ['CO']})
```text
binary: added _ZN2COC1El
binary: added _ZN2COC2El
source: added _ZN2COC1El
source: added _ZN2COC2El
```

## `cxx_more.converting_ctor_overload_added@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['CO'], 'functions': ['CO']})
```text
compatible: func_added __abicheck_ctor__CO(long int): New public function: CO
risk: ctor_overload_ambiguity_risk __abicheck_ctor__CO(long int): Class 'CO' gained a 2nd+ non-explicit converting constructor: CO(long int)
compatible: func_added_elf_only _ZN2COC1El: New exported C++ ABI artifact (constructor) of a class, accounted for by its class's declaration: _ZN2COC1El
compatible: func_added_elf_only _ZN2COC2El: New exported C++ ABI artifact (constructor) of a class, accounted for by its class's declaration: _ZN2COC2El
risk: overload_ambiguity_introduced __abicheck_ctor__CO(long int): Overload makes an existing call ambiguous: CO({}) — was (int), new (long int)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.converting_ctor_overload_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 1 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 Added function:
  [A] 'method CO::CO(long int)'    {_ZN2COC2El, aliases _ZN2COC1El}
```

## `cxx_more.converting_ctor_overload_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.converting_ctor_overload_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['CO'], 'functions': ['CO']})
```text
binary: added _ZN2COC1El
binary: added _ZN2COC2El
source: added _ZN2COC1El
source: added _ZN2COC2El
```

## `cxx_more.converting_ctor_overload_added@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['CO'], 'functions': ['CO']})
```text
compatible: func_added __abicheck_ctor__CO(long int): New public function: CO
risk: ctor_overload_ambiguity_risk __abicheck_ctor__CO(long int): Class 'CO' gained a 2nd+ non-explicit converting constructor: CO(long int)
compatible: func_added_elf_only _ZN2COC1El: New exported C++ ABI artifact (constructor) of a class, accounted for by its class's declaration: _ZN2COC1El
compatible: func_added_elf_only _ZN2COC2El: New exported C++ ABI artifact (constructor) of a class, accounted for by its class's declaration: _ZN2COC2El
risk: overload_ambiguity_introduced __abicheck_ctor__CO(long int): Overload makes an existing call ambiguous: CO({}) — was (int), new (long int)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.converting_ctor_overload_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['CO'], 'functions': ['CO']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 2 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
2 Added function symbols not referenced by debug info:
  [A] _ZN2COC1El, aliases _ZN2COC2El
  [A] _ZN2COC2El
```

## `cxx_more.vtt_grew@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
```text
binary/low: VB2 DataType_Size 
binary: added _ZN2VXD0Ev
binary: added _ZN2VXD1Ev
binary: added _ZN2VXD2Ev
source: added _ZN2VXD0Ev
source: added _ZN2VXD1Ev
source: added _ZN2VXD2Ev
```

## `cxx_more.vtt_grew@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed (2 filtered out), 3 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 4 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 4 Added variable symbols not referenced by debug info
3 Added functions:
  [A] 'method virtual VX::~VX(int, void**)'    {_ZN2VXD0Ev}
    note that this adds a new entry to the vtable of struct VX
  [A] 'method virtual VX::~VX(int, void**)'    {_ZN2VXD1Ev}
```

## `cxx_more.vtt_grew@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.vtt_grew@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
```text
binary/low: VB2 DataType_Size 
binary: added _ZN2VXD0Ev
binary: added _ZN2VXD1Ev
binary: added _ZN2VXD2Ev
source: added _ZN2VXD0Ev
source: added _ZN2VXD1Ev
source: added _ZN2VXD2Ev
```

## `cxx_more.vtt_grew@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 7 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 4 Added variable symbols not referenced by debug info
7 Added function symbols not referenced by debug info:
  [A] _ZN2VXD0Ev
  [A] _ZN2VXD1Ev
  [A] _ZN2VXD2Ev
```

## `cxx_more.field_added_in_tail_padding@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['fc_use']})
```text
binary/low: FC Added_Field c
source/low: FC Added_Field c
```

## `cxx_more.field_added_in_tail_padding@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['fc_use']})
```text
binary/low: FC Added_Field c
source/low: FC Added_Field c
```

## `cxx_more.field_added_in_tail_padding@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int fc_use(FC*)' at edit_seed.cpp:54:1 has some indirect sub-type changes:
    parameter 1 of type 'FC*' has sub-type changes:
      in pointed to type 'struct FC' at edit_seed.h:74:1:
        type size hasn't changed
        1 data member insertion:
```

## `cxx_more.field_added_in_tail_padding@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_added_in_tail_padding@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['fc_use']})
```text
binary/low: FC Added_Field c
source/low: FC Added_Field c
```

## `cxx_more.field_added_in_tail_padding@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['FC'], 'fields': ['c'], 'functions': ['fc_use']})

## `cxx_more.field_inserted_in_padding@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['ip_use']})
```text
binary/low: IP Added_Field x
source/low: IP Added_Field x
```

## `cxx_more.field_inserted_in_padding@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['ip_use']})
```text
binary/low: IP Added_Field x
source/low: IP Added_Field x
```

## `cxx_more.field_inserted_in_padding@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ip_use(IP*)' at edit_seed.cpp:55:1 has some indirect sub-type changes:
    parameter 1 of type 'IP*' has sub-type changes:
      in pointed to type 'struct IP' at edit_seed.h:76:1:
        type size hasn't changed
        1 data member insertion:
```

## `cxx_more.field_inserted_in_padding@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_inserted_in_padding@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['ip_use']})
```text
binary/low: IP Added_Field x
source/low: IP Added_Field x
```

## `cxx_more.field_inserted_in_padding@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['IP'], 'fields': ['x'], 'functions': ['ip_use']})

## `cxx_more.field_removed_without_shrink@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['rp_use']})
```text
binary/medium: RP Removed_Field x
source/high: RP Removed_Field x
```

## `cxx_more.field_removed_without_shrink@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['rp_use']})
```text
binary/medium: RP Removed_Field x
source/high: RP Removed_Field x
```

## `cxx_more.field_removed_without_shrink@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int rp_use(RP*)' at edit_seed.cpp:56:1 has some indirect sub-type changes:
    parameter 1 of type 'RP*' has sub-type changes:
      in pointed to type 'struct RP' at edit_seed.h:78:1:
        type size hasn't changed
        1 data member deletion:
```

## `cxx_more.field_removed_without_shrink@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_removed_without_shrink@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['rp_use']})
```text
binary/medium: RP Removed_Field x
source/high: RP Removed_Field x
```

## `cxx_more.field_removed_without_shrink@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['RP'], 'fields': ['x'], 'functions': ['rp_use']})

## `cxx_more.default_argument_added@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.func_became_extern_c@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.source_only_export_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.source_only_export_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.source_only_export_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.source_only_export_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.record_lost_trivially_copyable@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['LTC'], 'functions': ['ltc_get']})
```text
binary: added _ZN3LTCC1ERKS_
binary: added _ZN3LTCC2ERKS_
source: added _ZN3LTCC1ERKS_
source: added _ZN3LTCC2ERKS_
```

## `cxx_more.record_lost_trivially_copyable@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['LTC'], 'functions': ['ltc_get']})
```text
binary: added _ZN3LTCC1ERKS_
binary: added _ZN3LTCC2ERKS_
source: added _ZN3LTCC1ERKS_
source: added _ZN3LTCC1Ev
source: added _ZN3LTCC2ERKS_
source: added _ZN3LTCC2Ev
```

## `cxx_more.record_lost_trivially_copyable@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; exit bits ['abi_change']
- missed details: ['functions'] (expected {'functions': ['ltc_get']})
```text
Functions changes summary: 0 Removed, 0 Changed, 1 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 Added function:
  [A] 'method LTC::LTC(const LTC&)'    {_ZN3LTCC2ERKS_, aliases _ZN3LTCC1ERKS_}
```

## `cxx_more.record_lost_trivially_copyable@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.record_lost_trivially_copyable@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['LTC'], 'functions': ['ltc_get']})
```text
binary: added _ZN3LTCC1ERKS_
binary: added _ZN3LTCC2ERKS_
source: added _ZN3LTCC1ERKS_
source: added _ZN3LTCC1Ev
source: added _ZN3LTCC2ERKS_
source: added _ZN3LTCC2Ev
```

## `cxx_more.record_lost_trivially_copyable@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['LTC'], 'functions': ['ltc_get']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 2 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
2 Added function symbols not referenced by debug info:
  [A] _ZN3LTCC1ERKS_
  [A] _ZN3LTCC2ERKS_, aliases _ZN3LTCC1ERKS_
```

## `cxx_more.record_lost_standard_layout@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `cxx_more.record_lost_standard_layout@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.record_lost_standard_layout@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.field_inserted_at_head@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['lih_use']})
```text
binary/medium: LIH Added_Field_And_Layout_And_Size z
binary/low: LIH DataType_Size 
source/low: LIH Added_Field z
```

## `cxx_more.field_inserted_at_head@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['lih_use']})
```text
binary/medium: LIH Added_Field_And_Layout_And_Size z
binary/low: LIH DataType_Size 
source/low: LIH Added_Field z
```

## `cxx_more.field_inserted_at_head@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int lih_use(LIH*)' at edit_seed.cpp:59:1 has some indirect sub-type changes:
    parameter 1 of type 'LIH*' has sub-type changes:
      in pointed to type 'struct LIH' at edit_seed.h:88:1:
        type size changed from 64 to 96 (in bits)
        1 data member insertion:
```

## `cxx_more.field_inserted_at_head@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_inserted_at_head@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['lih_use']})
```text
binary/medium: LIH Added_Field_And_Layout_And_Size z
binary/low: LIH DataType_Size 
source/low: LIH Added_Field z
```

## `cxx_more.field_inserted_at_head@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'offsets', 'size'] (expected {'entity': ['LIH'], 'fields': ['z'], 'functions': ['lih_use'], 'offsets': ['a', 'b'], 'size': [8, 12]})

## `cxx_more.field_inserted_in_middle@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['lim_use']})
```text
binary/medium: LIM Added_Field_And_Layout_And_Size z
binary/low: LIM DataType_Size 
source/low: LIM Added_Field z
```

## `cxx_more.field_inserted_in_middle@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['lim_use']})
```text
binary/medium: LIM Added_Field_And_Layout_And_Size z
binary/low: LIM DataType_Size 
source/low: LIM Added_Field z
```

## `cxx_more.field_inserted_in_middle@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int lim_use(LIM*)' at edit_seed.cpp:60:1 has some indirect sub-type changes:
    parameter 1 of type 'LIM*' has sub-type changes:
      in pointed to type 'struct LIM' at edit_seed.h:90:1:
        type size changed from 64 to 96 (in bits)
        1 data member insertion:
```

## `cxx_more.field_inserted_in_middle@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_inserted_in_middle@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['lim_use']})
```text
binary/medium: LIM Added_Field_And_Layout_And_Size z
binary/low: LIM DataType_Size 
source/low: LIM Added_Field z
```

## `cxx_more.field_inserted_in_middle@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'offsets', 'size'] (expected {'entity': ['LIM'], 'fields': ['z'], 'functions': ['lim_use'], 'offsets': ['b'], 'size': [8, 12]})

## `cxx_more.field_removed_at_head@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['lrh_use']})
```text
binary/high: LRH Removed_Field_And_Layout_And_Size z
binary/low: LRH DataType_Size 
source/high: LRH Removed_Field z
```

## `cxx_more.field_removed_at_head@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['lrh_use']})
```text
binary/high: LRH Removed_Field_And_Layout_And_Size z
binary/low: LRH DataType_Size 
source/high: LRH Removed_Field z
```

## `cxx_more.field_removed_at_head@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int lrh_use(LRH*)' at edit_seed.cpp:61:1 has some indirect sub-type changes:
    parameter 1 of type 'LRH*' has sub-type changes:
      in pointed to type 'struct LRH' at edit_seed.h:92:1:
        type size changed from 96 to 64 (in bits)
        1 data member deletion:
```

## `cxx_more.field_removed_at_head@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_removed_at_head@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['lrh_use']})
```text
binary/high: LRH Removed_Field_And_Layout_And_Size z
binary/low: LRH DataType_Size 
source/high: LRH Removed_Field z
```

## `cxx_more.field_removed_at_head@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'offsets', 'size'] (expected {'entity': ['LRH'], 'fields': ['z'], 'functions': ['lrh_use'], 'offsets': ['a', 'b'], 'size': [12, 8]})

## `cxx_more.field_removed_in_middle@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['lrm_use']})
```text
binary/high: LRM Removed_Field_And_Layout_And_Size z
binary/low: LRM DataType_Size 
source/high: LRM Removed_Field z
```

## `cxx_more.field_removed_in_middle@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['lrm_use']})
```text
binary/high: LRM Removed_Field_And_Layout_And_Size z
binary/low: LRM DataType_Size 
source/high: LRM Removed_Field z
```

## `cxx_more.field_removed_in_middle@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int lrm_use(LRM*)' at edit_seed.cpp:62:1 has some indirect sub-type changes:
    parameter 1 of type 'LRM*' has sub-type changes:
      in pointed to type 'struct LRM' at edit_seed.h:94:1:
        type size changed from 96 to 64 (in bits)
        1 data member deletion:
```

## `cxx_more.field_removed_in_middle@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_removed_in_middle@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['lrm_use']})
```text
binary/high: LRM Removed_Field_And_Layout_And_Size z
binary/low: LRM DataType_Size 
source/high: LRM Removed_Field z
```

## `cxx_more.field_removed_in_middle@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'offsets', 'size'] (expected {'entity': ['LRM'], 'fields': ['z'], 'functions': ['lrm_use'], 'offsets': ['b'], 'size': [12, 8]})

## `cxx_more.field_removed_into_tail_padding@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['lrt_use']})
```text
binary/medium: LRT Removed_Field c
source/high: LRT Removed_Field c
```

## `cxx_more.field_removed_into_tail_padding@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['lrt_use']})
```text
binary/medium: LRT Removed_Field c
source/high: LRT Removed_Field c
```

## `cxx_more.field_removed_into_tail_padding@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int lrt_use(LRT*)' at edit_seed.cpp:63:1 has some indirect sub-type changes:
    parameter 1 of type 'LRT*' has sub-type changes:
      in pointed to type 'struct LRT' at edit_seed.h:96:1:
        type size hasn't changed
        1 data member deletion:
```

## `cxx_more.field_removed_into_tail_padding@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_removed_into_tail_padding@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['lrt_use']})
```text
binary/medium: LRT Removed_Field c
source/high: LRT Removed_Field c
```

## `cxx_more.field_removed_into_tail_padding@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['LRT'], 'fields': ['c'], 'functions': ['lrt_use']})

## `cxx_more.field_retyped_same_layout@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['lts_use']})
```text
binary/low: LTS Field_Type b
source/low: LTS Field_Type b
```

## `cxx_more.field_retyped_same_layout@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['lts_use']})
```text
binary/low: LTS Field_Type b
source/low: LTS Field_Type b
```

## `cxx_more.field_retyped_same_layout@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int lts_use(LTS*)' at edit_seed.cpp:64:1 has some indirect sub-type changes:
    parameter 1 of type 'LTS*' has sub-type changes:
      in pointed to type 'struct LTS' at edit_seed.h:98:1:
        type size hasn't changed
        1 data member change:
```

## `cxx_more.field_retyped_same_layout@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_retyped_same_layout@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['lts_use']})
```text
binary/low: LTS Field_Type b
source/low: LTS Field_Type b
```

## `cxx_more.field_retyped_same_layout@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['LTS'], 'fields': ['b'], 'functions': ['lts_use']})

## `cxx_more.field_retyped_smaller@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['ltk_use']})
```text
binary/medium: LTK Field_Type_And_Size_And_Layout_And_Type_Size a
binary/low: LTK DataType_Size 
source/low: LTK Field_Type a
```

## `cxx_more.field_retyped_smaller@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['ltk_use']})
```text
binary/medium: LTK Field_Type_And_Size_And_Layout_And_Type_Size a
binary/low: LTK DataType_Size 
source/low: LTK Field_Type a
```

## `cxx_more.field_retyped_smaller@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ltk_use(LTK*)' at edit_seed.cpp:65:1 has some indirect sub-type changes:
    parameter 1 of type 'LTK*' has sub-type changes:
      in pointed to type 'struct LTK' at edit_seed.h:100:1:
        type size changed from 64 to 32 (in bits)
        2 data member changes:
```

## `cxx_more.field_retyped_smaller@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_retyped_smaller@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['ltk_use']})
```text
binary/medium: LTK Field_Type_And_Size_And_Layout_And_Type_Size a
binary/low: LTK DataType_Size 
source/low: LTK Field_Type a
```

## `cxx_more.field_retyped_smaller@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'offsets', 'size'] (expected {'entity': ['LTK'], 'fields': ['a'], 'functions': ['ltk_use'], 'offsets': ['c'], 'size': [8, 4]})

## `cxx_more.field_retyped_alignment_only@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['lta_use']})
```text
binary/medium: LTA Field_Type_Format b
binary/low: LTA DataType_Size 
source/medium: LTA Field_Type_Format b
```

## `cxx_more.field_retyped_alignment_only@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['lta_use']})
```text
binary/medium: LTA Field_Type_Format b
binary/low: LTA DataType_Size 
source/medium: LTA Field_Type_Format b
```

## `cxx_more.field_retyped_alignment_only@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int lta_use(LTA*)' at edit_seed.cpp:66:1 has some indirect sub-type changes:
    parameter 1 of type 'LTA*' has sub-type changes:
      in pointed to type 'struct LTA' at edit_seed.h:102:1:
        type size changed from 40 to 64 (in bits)
        1 data member change:
```

## `cxx_more.field_retyped_alignment_only@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_retyped_alignment_only@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['lta_use']})
```text
binary/medium: LTA Field_Type_Format b
binary/low: LTA DataType_Size 
source/medium: LTA Field_Type_Format b
```

## `cxx_more.field_retyped_alignment_only@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'offsets', 'size'] (expected {'entity': ['LTA'], 'fields': ['b'], 'functions': ['lta_use'], 'offsets': ['b'], 'size': [5, 8]})

## `cxx_more.array_shrunk_shifting@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['las_use']})
```text
binary/low: LAS DataType_Size 
binary/low: LAS Field_Type a
source/low: LAS Field_Type a
```

## `cxx_more.array_shrunk_shifting@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['las_use']})
```text
binary/low: LAS DataType_Size 
binary/low: LAS Field_Type a
source/low: LAS Field_Type a
```

## `cxx_more.array_shrunk_shifting@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int las_use(LAS*)' at edit_seed.cpp:67:1 has some indirect sub-type changes:
    parameter 1 of type 'LAS*' has sub-type changes:
      in pointed to type 'struct LAS' at edit_seed.h:104:1:
        type size changed from 96 to 64 (in bits)
        2 data member changes:
```

## `cxx_more.array_shrunk_shifting@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.array_shrunk_shifting@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['las_use']})
```text
binary/low: LAS DataType_Size 
binary/low: LAS Field_Type a
source/low: LAS Field_Type a
```

## `cxx_more.array_shrunk_shifting@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'offsets', 'size'] (expected {'entity': ['LAS'], 'fields': ['a'], 'functions': ['las_use'], 'offsets': ['b'], 'size': [12, 8]})

## `cxx_more.array_grown_into_padding@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['lag_use']})
```text
binary/low: LAG Field_Type a
source/low: LAG Field_Type a
```

## `cxx_more.array_grown_into_padding@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['lag_use']})
```text
binary/low: LAG Field_Type a
source/low: LAG Field_Type a
```

## `cxx_more.array_grown_into_padding@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int lag_use(LAG*)' at edit_seed.cpp:68:1 has some indirect sub-type changes:
    parameter 1 of type 'LAG*' has sub-type changes:
      in pointed to type 'struct LAG' at edit_seed.h:106:1:
        type size hasn't changed
        1 data member change:
```

## `cxx_more.array_grown_into_padding@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.array_grown_into_padding@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['lag_use']})
```text
binary/low: LAG Field_Type a
source/low: LAG Field_Type a
```

## `cxx_more.array_grown_into_padding@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['LAG'], 'fields': ['a'], 'functions': ['lag_use']})

## `cxx_more.bitfield_width_within_unit@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['LBW'], 'fields': ['b'], 'functions': ['lbw_use']})

## `cxx_more.bitfield_width_within_unit@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
- missed details: ['functions'] (expected {'functions': ['lbw_use']})
```text
binary/low: LBW Struct_Field_Size_Increased b
```

## `cxx_more.bitfield_width_within_unit@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['lbw_use']})
```text
breaking: field_bitfield_changed LBW: Bitfield layout changed: LBW::b
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.bitfield_width_within_unit@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['LBW'], 'fields': ['b'], 'functions': ['lbw_use']})

## `cxx_more.bitfield_width_within_unit@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.bitfield_width_within_unit@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
- missed details: ['functions'] (expected {'functions': ['lbw_use']})
```text
binary/low: LBW Struct_Field_Size_Increased b
```

## `cxx_more.bitfield_width_within_unit@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['lbw_use']})
```text
breaking: field_bitfield_changed LBW: Bitfield layout changed: LBW::b
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.bitfield_width_within_unit@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['LBW'], 'fields': ['b'], 'functions': ['lbw_use']})

## `cxx_more.bitfield_width_crosses_unit@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['a'], 'functions': ['lbs_use']})
```text
binary/low: LBS DataType_Size 
```

## `cxx_more.bitfield_width_crosses_unit@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['functions'] (expected {'functions': ['lbs_use']})
```text
binary/medium: LBS Field_Size_And_Layout_And_Type_Size a
binary/low: LBS DataType_Size 
```

## `cxx_more.bitfield_width_crosses_unit@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['offsets'] (expected {'offsets': ['c']})
```text
breaking: type_size_changed LBS: Size changed: LBS (64 → 96 bits)
breaking: type_field_offset_changed LBS: Field offset changed: LBS::b (16 → 32 bits)
breaking: type_field_offset_changed LBS: Field offset changed: LBS::c (32 → 64 bits)
breaking: field_bitfield_changed LBS: Bitfield layout changed: LBS::a
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.bitfield_width_crosses_unit@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
- missed details: ['fields', 'offsets'] (expected {'fields': ['a'], 'offsets': ['c']})
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int lbs_use(LBS*)' at edit_seed.cpp:71:1 has some indirect sub-type changes:
    parameter 1 of type 'LBS*' has sub-type changes:
      in pointed to type 'struct LBS' at edit_seed.h:112:1:
        type size changed from 64 to 96 (in bits)
        2 data member changes:
```

## `cxx_more.bitfield_width_crosses_unit@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.bitfield_width_crosses_unit@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['functions'] (expected {'functions': ['lbs_use']})
```text
binary/medium: LBS Field_Size_And_Layout_And_Type_Size a
binary/low: LBS DataType_Size 
```

## `cxx_more.bitfield_width_crosses_unit@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['offsets'] (expected {'offsets': ['c']})
```text
breaking: type_size_changed LBS: Size changed: LBS (64 → 96 bits)
breaking: type_field_offset_changed LBS: Field offset changed: LBS::b (16 → 32 bits)
breaking: type_field_offset_changed LBS: Field offset changed: LBS::c (32 → 64 bits)
breaking: field_bitfield_changed LBS: Bitfield layout changed: LBS::a
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.bitfield_width_crosses_unit@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'offsets', 'size'] (expected {'entity': ['LBS'], 'fields': ['a'], 'functions': ['lbs_use'], 'offsets': ['c'], 'size': [8, 12]})

## `cxx_more.bitfield_became_field@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['lbf_use']})
```text
binary/medium: LBF Added_Field_And_Layout_And_Size a
binary/low: LBF DataType_Size 
source/low: LBF Added_Field a
```

## `cxx_more.bitfield_became_field@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['a'], 'functions': ['lbf_use']})
```text
binary/low: LBF DataType_Size 
```

## `cxx_more.bitfield_became_field@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['offsets'] (expected {'offsets': ['c']})
```text
breaking: type_size_changed LBF: Size changed: LBF (64 → 96 bits)
breaking: type_field_offset_changed LBF: Field offset changed: LBF::b (8 → 32 bits)
breaking: type_field_offset_changed LBF: Field offset changed: LBF::c (32 → 64 bits)
breaking: field_bitfield_changed LBF: Bitfield layout changed: LBF::a
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.bitfield_became_field@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
- missed details: ['fields', 'offsets'] (expected {'fields': ['a'], 'offsets': ['c']})
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int lbf_use(LBF*)' at edit_seed.cpp:72:1 has some indirect sub-type changes:
    parameter 1 of type 'LBF*' has sub-type changes:
      in pointed to type 'struct LBF' at edit_seed.h:114:1:
        type size changed from 64 to 96 (in bits)
        2 data member changes:
```

## `cxx_more.bitfield_became_field@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.bitfield_became_field@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['a'], 'functions': ['lbf_use']})
```text
binary/low: LBF DataType_Size 
```

## `cxx_more.bitfield_became_field@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['offsets'] (expected {'offsets': ['c']})
```text
breaking: type_size_changed LBF: Size changed: LBF (64 → 96 bits)
breaking: type_field_offset_changed LBF: Field offset changed: LBF::b (8 → 32 bits)
breaking: type_field_offset_changed LBF: Field offset changed: LBF::c (32 → 64 bits)
breaking: field_bitfield_changed LBF: Bitfield layout changed: LBF::a
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.bitfield_became_field@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions', 'offsets', 'size'] (expected {'entity': ['LBF'], 'fields': ['a'], 'functions': ['lbf_use'], 'offsets': ['c'], 'size': [8, 12]})

## `cxx_more.record_alignment_raised@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: LRA DataType_Size 
```

## `cxx_more.record_alignment_raised@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: LRA DataType_Size 
```

## `cxx_more.record_alignment_raised@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int lra_use(LRA*)' at edit_seed.cpp:69:1 has some indirect sub-type changes:
    parameter 1 of type 'LRA*' has sub-type changes:
      in pointed to type 'struct LRA' at edit_seed.h:108:1:
        type size changed from 32 to 128 (in bits)
```

## `cxx_more.record_alignment_raised@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.record_alignment_raised@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: LRA DataType_Size 
```

## `cxx_more.record_alignment_raised@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.cxx_record_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['lna_use'], 'functions': ['lna_use']})
```text
binary: added _Z7lna_useP3LNA
source: added _Z7lna_useP3LNA
```

## `cxx_more.cxx_record_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['lna_use'], 'functions': ['lna_use']})
```text
binary: added _Z7lna_useP3LNA
source: added _Z7lna_useP3LNA
```

## `cxx_more.cxx_record_added@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['lna_use'], 'functions': ['lna_use']})
```text
compatible: func_added _Z7lna_useP3LNA: New public function: lna_use
compatible: type_added LNA: New type: LNA
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: public_surface_grew <surface>: public surface grew: 688 → 696 declarations (+8)
```

## `cxx_more.cxx_record_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.cxx_record_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['lna_use'], 'functions': ['lna_use']})
```text
binary: added _Z7lna_useP3LNA
source: added _Z7lna_useP3LNA
```

## `cxx_more.cxx_record_added@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['lna_use'], 'functions': ['lna_use']})
```text
compatible: func_added _Z7lna_useP3LNA: New public function: lna_use
compatible: type_added LNA: New type: LNA
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: public_surface_grew <surface>: public surface grew: 688 → 696 declarations (+8)
```

## `cxx_more.cxx_record_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['lna_use'], 'functions': ['lna_use']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 1 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Added function symbol not referenced by debug info:
  [A] _Z7lna_useP3LNA
```

## `cxx_more.base_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: LD0 DataType_Size 
```

## `cxx_more.base_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: LD0 DataType_Size 
```

## `cxx_more.base_removed@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ld0_use(LD0*)' at edit_seed.cpp:73:1 has some indirect sub-type changes:
    parameter 1 of type 'LD0*' has sub-type changes:
      in pointed to type 'struct LD0' at edit_seed.h:117:1:
        type size changed from 64 to 32 (in bits)
        1 base class deletion:
```

## `cxx_more.base_removed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.base_removed@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: LD0 DataType_Size 
```

## `cxx_more.base_removed@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.base_added_nonvirtual@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: LD1 DataType_Size 
```

## `cxx_more.base_added_nonvirtual@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: LD1 DataType_Size 
```

## `cxx_more.base_added_nonvirtual@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ld1_use(LD1*)' at edit_seed.cpp:74:1 has some indirect sub-type changes:
    parameter 1 of type 'LD1*' has sub-type changes:
      in pointed to type 'struct LD1' at edit_seed.h:120:1:
        type size changed from 32 to 64 (in bits)
        1 base class insertion:
```

## `cxx_more.base_added_nonvirtual@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.base_added_nonvirtual@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: LD1 DataType_Size 
```

## `cxx_more.base_added_nonvirtual@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.base_became_nonvirtual@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: LD2 DataType_Size 
```

## `cxx_more.base_became_nonvirtual@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: LD2 DataType_Size 
```

## `cxx_more.base_became_nonvirtual@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.base_became_nonvirtual@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'NO_CHANGE'}
```text
binary/low: LD2 DataType_Size 
```

## `cxx_more.base_access_narrowed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.base_access_narrowed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.base_access_narrowed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ld3_use(LD3*)' at edit_seed.cpp:79:1 has some indirect sub-type changes:
    parameter 1 of type 'LD3*' has sub-type changes:
      in pointed to type 'struct LD3' at edit_seed.h:127:1:
        type size hasn't changed
        1 base class change:
```

## `cxx_more.base_access_narrowed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.base_access_narrowed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.base_access_narrowed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.return_pointee_const_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['cref'], 'functions': ['cref']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `c_elf.return_pointee_const_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.return_pointee_const_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['cref'], 'functions': ['cref']})

## `c_elf.return_deep_pointee_const_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: cpp@@LIBEDIT_1.0 Return_Type
source/low: cpp Return_Type
```

## `c_elf.return_deep_pointee_const_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: cpp@@LIBEDIT_1.0 Return_Type
source/low: cpp Return_Type
```

## `c_elf.return_deep_pointee_const_removed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['cpp'], 'functions': ['cpp']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `c_elf.return_deep_pointee_const_removed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.return_deep_pointee_const_removed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: cpp@@LIBEDIT_1.0 Return_Type
source/low: cpp Return_Type
```

## `c_elf.return_deep_pointee_const_removed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['cpp'], 'functions': ['cpp']})

## `c_elf.param_pointee_const_to_volatile@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
```text
binary/medium: cread@@LIBEDIT_1.0 Parameter_Became_Non_Const
binary/low: cread@@LIBEDIT_1.0 Parameter_Type
source/medium: cread Parameter_Became_Non_Const
```

## `c_elf.param_pointee_const_to_volatile@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
```text
binary/medium: cread@@LIBEDIT_1.0 Parameter_Became_Non_Const
binary/low: cread@@LIBEDIT_1.0 Parameter_Type
source/medium: cread Parameter_Became_Non_Const
```

## `c_elf.param_pointee_const_to_volatile@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['cread'], 'functions': ['cread']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `c_elf.param_pointee_const_to_volatile@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.param_pointee_const_to_volatile@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
```text
binary/medium: cread@@LIBEDIT_1.0 Parameter_Became_Non_Const
binary/low: cread@@LIBEDIT_1.0 Parameter_Type
source/medium: cread Parameter_Became_Non_Const
```

## `c_elf.param_pointee_const_to_volatile@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['cread'], 'functions': ['cread']})

## `c_elf.var_alignment_raised@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__'], 'functions': ['__attribute__', 'dupc']})

## `c_elf.var_alignment_raised@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__'], 'functions': ['__attribute__', 'dupc']})

## `c_elf.var_alignment_raised@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__'], 'functions': ['__attribute__', 'dupc']})
```text
breaking: var_alignment_changed g_al: Variable alignment changed: g_al (128 → 512 bits)
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.var_alignment_raised@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__'], 'functions': ['__attribute__', 'dupc']})

## `c_elf.var_alignment_raised@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.var_alignment_raised@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__'], 'functions': ['__attribute__', 'dupc']})

## `c_elf.var_alignment_raised@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__'], 'functions': ['__attribute__', 'dupc']})
```text
breaking: var_alignment_changed g_al: Variable alignment changed: g_al (128 → 512 bits)
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.var_alignment_raised@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__'], 'functions': ['__attribute__', 'dupc']})

## `c_elf.source_only_var_export_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.source_only_var_export_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.source_only_var_export_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.source_only_var_export_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.func_became_ms_abi@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'msf'], 'functions': ['__attribute__', 'dupc', 'msf']})

## `c_elf.func_became_ms_abi@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'msf'], 'functions': ['__attribute__', 'dupc', 'msf']})

## `c_elf.func_became_ms_abi@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'msf'], 'functions': ['__attribute__', 'dupc', 'msf']})
```text
breaking: calling_convention_changed msf: Calling-convention attribute changed for msf: (default) → ms_abi
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.func_became_ms_abi@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'msf'], 'functions': ['__attribute__', 'dupc', 'msf']})

## `c_elf.func_became_ms_abi@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.func_became_ms_abi@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'msf'], 'functions': ['__attribute__', 'dupc', 'msf']})

## `c_elf.func_became_ms_abi@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'msf'], 'functions': ['__attribute__', 'dupc', 'msf']})
```text
breaking: calling_convention_changed msf: Calling-convention attribute changed for msf: (default) → ms_abi
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.func_became_ms_abi@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['__attribute__', 'msf'], 'functions': ['__attribute__', 'dupc', 'msf']})

## `c_elf.func_contract_attribute_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['put'], 'functions': ['put']})

## `c_elf.func_contract_attribute_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['put'], 'functions': ['put']})

## `c_elf.func_contract_attribute_added@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**
- missed details: ['entity', 'functions'] (expected {'entity': ['put'], 'functions': ['put']})
```text
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.func_contract_attribute_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['put'], 'functions': ['put']})

## `c_elf.func_contract_attribute_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.func_contract_attribute_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['put'], 'functions': ['put']})

## `c_elf.func_contract_attribute_added@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**
- missed details: ['entity', 'functions'] (expected {'entity': ['put'], 'functions': ['put']})
```text
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.func_contract_attribute_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['put'], 'functions': ['put']})

## `c_elf.func_contract_attribute_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['dupc'], 'functions': ['dupc']})

## `c_elf.func_contract_attribute_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['dupc'], 'functions': ['dupc']})

## `c_elf.func_contract_attribute_removed@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**
- missed details: ['entity', 'functions'] (expected {'entity': ['dupc'], 'functions': ['dupc']})
```text
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.func_contract_attribute_removed@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['dupc'], 'functions': ['dupc']})

## `c_elf.func_contract_attribute_removed@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.func_contract_attribute_removed@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['dupc'], 'functions': ['dupc']})

## `c_elf.func_contract_attribute_removed@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**
- missed details: ['entity', 'functions'] (expected {'entity': ['dupc'], 'functions': ['dupc']})
```text
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
```

## `c_elf.func_contract_attribute_removed@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['dupc'], 'functions': ['dupc']})

- `cxx_more.func_exception_spec_widened@dwarf+headers`: not run (infeasible: c++17 is outside the standards this edit is defined in: c++ c++11-on (cited: ISO/IEC 14882:1998 [except.spec] (dynamic exception specifications)); last in c++14 (cited: P0003R5 (removed from C++17)))
- `cxx_more.func_exception_spec_widened@stripped+headers`: not run (infeasible: c++17 is outside the standards this edit is defined in: c++ c++11-on (cited: ISO/IEC 14882:1998 [except.spec] (dynamic exception specifications)); last in c++14 (cited: P0003R5 (removed from C++17)))
## `c_elf.declared_exports_defined@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.inline_function_outlined@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['inl_add'], 'functions': ['inl_add']})
```text
binary: added _Z7inl_addii
source: added _Z7inl_addii
```

## `cxx_more.inline_function_outlined@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['inl_add'], 'functions': ['inl_add']})
```text
binary: added _Z7inl_addii
```

## `cxx_more.inline_function_outlined@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['inl_add'], 'functions': ['inl_add']})
```text
compatible: func_export_added _Z7inl_addii: Function now exported by the binary while its declaration remains present: inl_add
compatible: func_lost_inline _Z7inl_addii: Function lost inline attribute: inl_add
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.inline_function_outlined@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.inline_function_outlined@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['inl_add'], 'functions': ['inl_add']})
```text
binary: added _Z7inl_addii
```

## `cxx_more.inline_function_outlined@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['inl_add'], 'functions': ['inl_add']})
```text
compatible: func_export_added _Z7inl_addii: Function now exported by the binary while its declaration remains present: inl_add
compatible: func_lost_inline _Z7inl_addii: Function lost inline attribute: inl_add
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.inline_function_outlined@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['inl_add'], 'functions': ['inl_add']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 1 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Added function symbol not referenced by debug info:
  [A] _Z7inl_addii
```

## `c_elf.param_became_va_list@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: vlog@@LIBEDIT_1.0 Parameter_Type
source/low: vlog Parameter_Type
```

## `c_elf.param_became_va_list@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: vlog@@LIBEDIT_1.0 Parameter_Type
source/low: vlog Parameter_Type
```

## `c_elf.param_became_va_list@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int vlog(const char*, void*)' at edit_seed.c:36:1 has some indirect sub-type changes:
```

## `c_elf.param_became_va_list@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.param_became_va_list@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: vlog@@LIBEDIT_1.0 Parameter_Type
source/low: vlog Parameter_Type
```

## `c_elf.param_became_va_list@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['vlog'], 'functions': ['vlog']})

## `c_elf.param_lost_va_list@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: vlog2@@LIBEDIT_1.0 Parameter_Type
source/low: vlog2 Parameter_Type
```

## `c_elf.param_lost_va_list@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: vlog2@@LIBEDIT_1.0 Parameter_Type
source/low: vlog2 Parameter_Type
```

## `c_elf.param_lost_va_list@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int vlog2(const char*, __va_list_tag*)' at edit_seed.c:37:1 has some indirect sub-type changes:
```

## `c_elf.param_lost_va_list@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.param_lost_va_list@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: vlog2@@LIBEDIT_1.0 Parameter_Type
source/low: vlog2 Parameter_Type
```

## `c_elf.param_lost_va_list@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['vlog2'], 'functions': ['vlog2']})

## `c_elf.serialization_tag_swapped@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['widget_tag']})
```text
breaking: enum_member_value_changed widget_tag_id::WIDGET_A: Enum member value changed: widget_tag_id::WIDGET_A (1 → 2)
breaking: enum_member_value_changed widget_tag_id::WIDGET_B: Enum member value changed: widget_tag_id::WIDGET_B (2 → 1)
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
breaking: serialization_tag_changed widget_tag_id::WIDGET_A: Serialization tag 'widget_tag_id::WIDGET_A' value changed 1 → 2; this is the same value previously 
breaking: serialization_tag_changed widget_tag_id::WIDGET_B: Serialization tag 'widget_tag_id::WIDGET_B' value changed 2 → 1; this is the same value previously 
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.serialization_tag_swapped@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int widget_tag(widget_tag_id)' at edit_seed.c:38:1 has some indirect sub-type changes:
    parameter 1 of type 'enum widget_tag_id' has sub-type changes:
      type size hasn't changed
      2 enumerator changes:
        'widget_tag_id::WIDGET_A' from value '1' to '2' at edit_seed.h:46:1
```

## `c_elf.serialization_tag_swapped@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.serialization_tag_swapped@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['widget_tag']})
```text
breaking: enum_member_value_changed widget_tag_id::WIDGET_A: Enum member value changed: widget_tag_id::WIDGET_A
breaking: enum_member_value_changed widget_tag_id::WIDGET_B: Enum member value changed: widget_tag_id::WIDGET_B
risk: public_not_exported g_late: Public header declares extern variable 'g_late' (expected symbol 'g_late') but the binary does not export it. Consumers linkin
risk: public_not_exported late_f: Public header declares 'late_f' (expected symbol 'late_f') but the binary does not export it. Code that compiles against the h
breaking: serialization_tag_changed widget_tag_id::WIDGET_A: Serialization tag 'widget_tag_id::WIDGET_A' value changed 1 → 2; this is the same value previously 
breaking: serialization_tag_changed widget_tag_id::WIDGET_B: Serialization tag 'widget_tag_id::WIDGET_B' value changed 2 → 1; this is the same value previously 
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `c_elf.serialization_tag_swapped@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['widget_tag_id'], 'functions': ['widget_tag']})

## `c_elf.symbols_prefixed_batch@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.internal_table_grown@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
- missed details: ['entity'] (expected {'entity': ['_lib_table']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 1 Changed, 0 Added variable
1 Changed variable:
  [C] 'int _lib_table[4]' was changed to 'int _lib_table[8]' at edit_seed.h:50:1:
    size of symbol changed from 16 to 32
    type of variable changed:
      type name changed from 'int[4]' to 'int[8]'
      array type size changed from 128 to 256
```

## `c_elf.internal_table_grown@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.internal_table_grown@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['_lib_table']})

## `cxx_more.virtual_bases_reordered@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.virtual_bases_reordered@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.virtual_bases_reordered@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int kvd_use(KVD*)' at edit_seed.cpp:82:1 has some indirect sub-type changes:
    parameter 1 of type 'KVD*' has sub-type changes:
      in pointed to type 'struct KVD' at edit_seed.h:135:1:
        type size hasn't changed
        base classes of 'struct KVD' are re-ordered from: 'virtual KVA, virtual KVB' to: 'virtual KVB, virtual KVA'
```

## `cxx_more.virtual_bases_reordered@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.virtual_bases_reordered@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.virtual_bases_reordered@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.secondary_base_became_polymorphic@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
binary/low: KSD DataType_Size 
binary: added _ZN3KSB1gEv
source: added _ZN3KSB1gEv
```

## `cxx_more.secondary_base_became_polymorphic@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
binary/low: KSD DataType_Size 
binary: added _ZN3KSB1gEv
source: added _ZN3KSB1gEv
```

## `cxx_more.secondary_base_became_polymorphic@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
breaking: type_size_changed KSB: Size changed: KSB (32 → 128 bits)
breaking: type_alignment_changed KSB: Alignment changed: KSB (32 → 64 bits)
breaking: type_field_offset_changed KSB: Field offset changed: KSB::x (0 → 64 bits)
breaking: type_vtable_changed KSB: vtable changed: KSB
breaking: type_size_changed KSD: Size changed: KSD (128 → 192 bits)
breaking: type_field_offset_changed KSD: Field offset changed: KSD::d (96 → 160 bits)
breaking: type_vtable_changed KSD: vtable changed: KSD
breaking: vtable_slot_count_changed _ZTV3KSD: Vtable for 'KSD' changed size: 24 → 48 bytes (+3 pointer-sized words). Virtual functions were net added or removed
```

## `cxx_more.secondary_base_became_polymorphic@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.secondary_base_became_polymorphic@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
binary/low: KSD DataType_Size 
binary: added _ZN3KSB1gEv
source: added _ZN3KSB1gEv
```

## `cxx_more.secondary_base_became_polymorphic@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
breaking: type_size_changed KSB: Size changed: KSB (32 → 128 bits)
breaking: type_alignment_changed KSB: Alignment changed: KSB (32 → 64 bits)
breaking: type_field_offset_changed KSB: Field offset changed: KSB::x (0 → 64 bits)
breaking: type_vtable_changed KSB: vtable changed: KSB
breaking: type_size_changed KSD: Size changed: KSD (128 → 192 bits)
breaking: type_field_offset_changed KSD: Field offset changed: KSD::d (96 → 160 bits)
breaking: type_vtable_changed KSD: vtable changed: KSD
breaking: vtable_slot_count_changed _ZTV3KSD: Vtable for 'KSD' changed size: 24 → 48 bytes (+3 pointer-sized words). Virtual functions were net added or removed
```

## `cxx_more.secondary_base_became_polymorphic@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 3 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 1 Added variable symbol not referenced by debug info
3 Added function symbols not referenced by debug info:
  [A] _ZN3KSB1gEv
  [A] _ZN3KSBC1Ev
  [A] _ZN3KSBC2Ev, aliases _ZN3KSBC1Ev
```

## `cxx_more.reserved_field_used@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['flags', 'reserved1'], 'functions': ['krs_get']})
```text
binary/low: KRS Used_Reserved_Field reserved1
source/safe: KRS Used_Reserved_Field reserved1
```

## `cxx_more.reserved_field_used@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['flags', 'reserved1'], 'functions': ['krs_get']})
```text
binary/low: KRS Used_Reserved_Field reserved1
source/safe: KRS Used_Reserved_Field reserved1
```

## `cxx_more.reserved_field_used@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['flags', 'reserved1'], 'functions': ['krs_get']})
```text
compatible: used_reserved_field KRS: Reserved field put into use: KRS::reserved1 → flags
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.reserved_field_used@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['KRS'], 'fields': ['flags', 'reserved1'], 'functions': ['krs_get']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `cxx_more.reserved_field_used@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.reserved_field_used@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **wrong**; sides {'binary': 'ADVISORY', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['flags', 'reserved1'], 'functions': ['krs_get']})
```text
binary/low: KRS Used_Reserved_Field reserved1
source/safe: KRS Used_Reserved_Field reserved1
```

## `cxx_more.reserved_field_used@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['flags', 'reserved1'], 'functions': ['krs_get']})
```text
compatible: used_reserved_field KRS: Reserved field put into use: KRS::reserved1 → flags
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.reserved_field_used@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['KRS'], 'fields': ['flags', 'reserved1'], 'functions': ['krs_get']})

## `cxx_more.inline_namespace_version_bumped@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['kv_f']})
```text
binary: removed _ZN2kv2v14kv_fEi
binary: added _ZN2kv2v24kv_fEi
source: removed _ZN2kv2v14kv_fEi
source: added _ZN2kv2v24kv_fEi
```

## `cxx_more.inline_namespace_version_bumped@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['kv_f']})
```text
binary: removed _ZN2kv2v14kv_fEi
binary: added _ZN2kv2v24kv_fEi
source: removed _ZN2kv2v14kv_fEi
source: added _ZN2kv2v24kv_fEi
```

## `cxx_more.inline_namespace_version_bumped@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['kv_f']})
```text
breaking: func_removed _ZN2kv2v14kv_fEi: Public function removed: kv_f
compatible: func_added _ZN2kv2v24kv_fEi: New public function: kv_f
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
breaking: inline_namespace_version_bumped kv::v2::kv_f(int): Inline namespace version bumped: 'kv::v1::kv_f(int)' → 'kv::v2::kv_f(int)' (version segment changed
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.inline_namespace_version_bumped@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.inline_namespace_version_bumped@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['kv_f']})
```text
binary: removed _ZN2kv2v14kv_fEi
binary: added _ZN2kv2v24kv_fEi
source: removed _ZN2kv2v14kv_fEi
source: added _ZN2kv2v24kv_fEi
```

## `cxx_more.inline_namespace_version_bumped@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['kv_f']})
```text
breaking: func_removed _ZN2kv2v14kv_fEi: Public function removed: kv_f
compatible: func_added _ZN2kv2v24kv_fEi: New public function: kv_f
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
breaking: inline_namespace_version_bumped kv::v2::kv_f(int): Inline namespace version bumped: 'kv::v1::kv_f(int)' → 'kv::v2::kv_f(int)' (version segment changed
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.inline_namespace_version_bumped@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity'] (expected {'entity': ['kv_f']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _ZN2kv2v14kv_fEi
1 Added function symbol not referenced by debug info:
  [A] _ZN2kv2v24kv_fEi
```

## `cxx_more.experimental_api_graduated@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['kx_f']})
```text
binary: added _ZN2kx4kx_fEi
source: added _ZN2kx4kx_fEi
```

## `cxx_more.experimental_api_graduated@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['kx_f']})
```text
binary: added _ZN2kx4kx_fEi
source: added _ZN2kx4kx_fEi
```

## `cxx_more.experimental_api_graduated@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity'] (expected {'entity': ['kx_f']})
```text
compatible: func_added _ZN2kx4kx_fEi: New public function: kx_f
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: experimental_graduated kx::kx_f(int): Experimental declaration 'kx::experimental::kx_f(int)' graduated to stable name 'kx::kx_f(int)'; experimental 
compatible: public_surface_grew <surface>: public surface grew: 688 → 689 declarations (+1)
```

## `cxx_more.experimental_api_graduated@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.experimental_api_graduated@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['kx_f']})
```text
binary: added _ZN2kx4kx_fEi
source: added _ZN2kx4kx_fEi
```

## `cxx_more.experimental_api_graduated@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity'] (expected {'entity': ['kx_f']})
```text
compatible: func_added _ZN2kx4kx_fEi: New public function: kx_f
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: experimental_graduated kx::kx_f(int): Experimental declaration 'kx::experimental::kx_f(int)' graduated to stable name 'kx::kx_f(int)'; experimental 
compatible: public_surface_grew <surface>: public surface grew: 688 → 689 declarations (+1)
```

## `cxx_more.experimental_api_graduated@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; exit bits ['abi_change']
- missed details: ['entity'] (expected {'entity': ['kx_f']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 1 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Added function symbol not referenced by debug info:
  [A] _ZN2kx4kx_fEi
```

## `cxx_more.experimental_api_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['kx_g']})
```text
binary: removed _ZN2kx12experimental4kx_gEi
source: removed _ZN2kx12experimental4kx_gEi
```

## `cxx_more.experimental_api_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['kx_g']})
```text
binary: removed _ZN2kx12experimental4kx_gEi
source: removed _ZN2kx12experimental4kx_gEi
```

## `cxx_more.experimental_api_removed@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['kx_g']})
```text
breaking: func_removed _ZN2kx12experimental4kx_gEi: Public function removed: kx_g
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
api_break: experimental_removed_without_replacement kx::experimental::kx_g(int): Experimental declaration 'kx::experimental::kx_g(int)' was removed and no decla
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_shrank <surface>: public surface shrank: 688 → 687 declarations (-1)
```

## `cxx_more.experimental_api_removed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.experimental_api_removed@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['kx_g']})
```text
binary: removed _ZN2kx12experimental4kx_gEi
source: removed _ZN2kx12experimental4kx_gEi
```

## `cxx_more.experimental_api_removed@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['kx_g']})
```text
breaking: func_removed _ZN2kx12experimental4kx_gEi: Public function removed: kx_g
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
api_break: experimental_removed_without_replacement kx::experimental::kx_g(int): Experimental declaration 'kx::experimental::kx_g(int)' was removed and no decla
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_shrank <surface>: public surface shrank: 688 → 687 declarations (-1)
```

## `cxx_more.experimental_api_removed@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity'] (expected {'entity': ['kx_g']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _ZN2kx12experimental4kx_gEi
```

## `cxx_more.function_became_customization_object@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['kc_swap', 'operator']})
```text
binary: removed _ZN2kc7kc_swapEi
binary: added _ZN2kc7kc_swapE
binary: added _ZNK2kc10kc_swap_fnclEi
binary/high: _ZN2kc7kc_swapEi Symbol_Changed_Parameters
source: removed _ZN2kc7kc_swapEi
source: added _ZN2kc7kc_swapE
source: added _ZNK2kc10kc_swap_fnclEi
source/medium: _ZN2kc7kc_swapEi Symbol_Changed_Parameters
```

## `cxx_more.function_became_customization_object@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['kc_swap', 'operator']})
```text
binary: removed _ZN2kc7kc_swapEi
binary: added _ZN2kc7kc_swapE
binary/high: _ZN2kc7kc_swapEi Symbol_Changed_Parameters
source: removed _ZN2kc7kc_swapEi
source: added _ZN2kc7kc_swapE
source/medium: _ZN2kc7kc_swapEi Symbol_Changed_Parameters
```

## `cxx_more.function_became_customization_object@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['kc_swap', 'operator']})
```text
breaking: func_removed _ZN2kc7kc_swapEi: Public function removed: kc_swap
compatible: func_added _ZNK2kc10kc_swap_fnclEi: New public function: operator()
compatible: var_added _ZN2kc7kc_swapE: New public variable: kc_swap
compatible: type_added kc_swap_fn: New type: kc_swap_fn
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
breaking: cpo_kind_changed kc::kc_swap: Public name 'kc::kc_swap' was a function in old and is a variable (function-object / CPO) in new. Call syntax preserved;
```

## `cxx_more.function_became_customization_object@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.function_became_customization_object@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['kc_swap', 'operator']})
```text
binary: removed _ZN2kc7kc_swapEi
binary: added _ZN2kc7kc_swapE
binary/high: _ZN2kc7kc_swapEi Symbol_Changed_Parameters
source: removed _ZN2kc7kc_swapEi
source: added _ZN2kc7kc_swapE
source/medium: _ZN2kc7kc_swapEi Symbol_Changed_Parameters
```

## `cxx_more.function_became_customization_object@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['kc_swap', 'operator']})
```text
breaking: func_removed _ZN2kc7kc_swapEi: Public function removed: kc_swap
compatible: func_added _ZNK2kc10kc_swap_fnclEi: New public function: operator()
compatible: var_added _ZN2kc7kc_swapE: New public variable: kc_swap
compatible: type_added kc_swap_fn: New type: kc_swap_fn
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
breaking: cpo_kind_changed kc::kc_swap: Public name 'kc::kc_swap' was a function in old and is a variable (function-object / CPO) in new. Call syntax preserved;
```

## `cxx_more.function_became_customization_object@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity'] (expected {'entity': ['kc_swap', 'operator']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 1 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _ZN2kc7kc_swapEi
1 Added function symbol not referenced by debug info:
  [A] _ZNK2kc10kc_swap_fnclEi
```

## `cxx_more.template_return_argument_changed@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'ADVISORY'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kbx_get'], 'functions': ['kbx_get']})
```text
binary/medium: _Z7kbx_getv Return_Type_And_Size
source/low: _Z7kbx_getv Return_Type
```

## `cxx_more.template_return_argument_changed@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kbx_get'], 'functions': ['kbx_get']})
```text
binary/low: _Z7kbx_getv Return_Type
source/low: _Z7kbx_getv Return_Type
```

## `cxx_more.template_return_argument_changed@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['kbx_get'], 'functions': ['kbx_get']})
```text
breaking: func_return_changed _Z7kbx_getv: Return type changed: kbx_get
breaking: template_return_type_changed _Z7kbx_getv: Template return type inner argument changed: kbx_get (KBx<int> → KBx<long>)
compatible: type_added KBx<long>: New type: KBx<long>
risk: declaration_renamed KBx<long>: Graph evidence reconciles 'KBx<int>' (old) with 'KBx<long>' (new) as the same declaration, renamed (match evidence: structu
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.template_return_argument_changed@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function KBx<int> kbx_get()' at edit_seed.cpp:116:1 has some indirect sub-type changes:
    return type changed:
      type name changed from 'KBx<int>' to 'KBx<long int>'
      type size changed from 32 to 64 (in bits)
      1 data member change:
```

## `cxx_more.template_return_argument_changed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.template_return_argument_changed@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kbx_get'], 'functions': ['kbx_get']})
```text
binary/low: _Z7kbx_getv Return_Type
source/low: _Z7kbx_getv Return_Type
```

## `cxx_more.template_return_argument_changed@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['kbx_get'], 'functions': ['kbx_get']})
```text
breaking: func_return_changed _Z7kbx_getv: Return type changed: kbx_get
breaking: template_return_type_changed _Z7kbx_getv: Template return type inner argument changed: kbx_get (KBx<int> → KBx<long>)
compatible: type_added KBx<long>: New type: KBx<long>
risk: declaration_renamed KBx<long>: Graph evidence reconciles 'KBx<int>' (old) with 'KBx<long>' (new) as the same declaration, renamed (match evidence: structu
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.template_return_argument_changed@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['kbx_get'], 'functions': ['kbx_get']})

## `cxx_more.template_param_argument_changed@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: kpb_take Parameter_Type
source/low: kpb_take Parameter_Type
```

## `cxx_more.template_param_argument_changed@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int kpb_take(KPb<int>)' at edit_seed.cpp:117:1 has some indirect sub-type changes:
    parameter 1 of type 'struct KPb<int>' changed:
      type name changed from 'KPb<int>' to 'KPb<long int>'
      type size changed from 32 to 64 (in bits)
      1 data member change:
```

## `cxx_more.template_param_argument_changed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.template_param_argument_changed@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: kpb_take Parameter_Type
source/low: kpb_take Parameter_Type
```

## `cxx_more.template_param_argument_changed@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['kpb_take'], 'functions': ['kpb_take']})

## `cxx_more.field_retyped_abi_equivalent@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['kae_get']})
```text
binary/low: KAE Field_Type a
source/low: KAE Field_Type a
```

## `cxx_more.field_retyped_abi_equivalent@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['kae_get']})
```text
binary/low: KAE Field_Type a
source/low: KAE Field_Type a
```

## `cxx_more.field_retyped_abi_equivalent@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['a'], 'functions': ['kae_get']})
```text
risk: abi_equivalent_type_changed KAE::a: Type spelling changed between ABI-identical types: KAE::a long int -> long long int (same size, alignment and register
risk: abi_equivalent_type_changed KAE: Type spelling changed between ABI-identical types: KAE long int -> long long int (same size, alignment and register class
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.field_retyped_abi_equivalent@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.field_retyped_abi_equivalent@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['kae_get']})
```text
binary/low: KAE Field_Type a
source/low: KAE Field_Type a
```

## `cxx_more.field_retyped_abi_equivalent@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['a'], 'functions': ['kae_get']})
```text
risk: abi_equivalent_type_changed KAE: Type spelling changed between ABI-identical types: KAE long int -> long long int (same size, alignment and register class
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.field_retyped_abi_equivalent@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['KAE'], 'fields': ['a'], 'functions': ['kae_get']})

## `cxx_more.declared_function_lost_definition@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.declared_function_export_became_c_namesake@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.deduced_lambda_return_named@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.deduced_lambda_return_named@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.deduced_lambda_return_named@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.deduced_lambda_return_named@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.std_reexport_dropped@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['krx_f']})

## `cxx_more.std_reexport_dropped@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['krx_f']})

## `cxx_more.std_reexport_dropped@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity'] (expected {'entity': ['krx_f']})
```text
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
api_break: std_reexport_removed krx::abs: Public re-export 'krx::abs' of standard-library entity 'std::abs' was removed. Consumer code that named 'krx::abs' no 
```

## `cxx_more.std_reexport_dropped@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity'] (expected {'entity': ['krx_f']})

## `cxx_more.std_reexport_dropped@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.std_reexport_dropped@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['krx_f']})

## `cxx_more.std_reexport_dropped@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity'] (expected {'entity': ['krx_f']})
```text
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
api_break: std_reexport_removed krx::abs: Public re-export 'krx::abs' of standard-library entity 'std::abs' was removed. Consumer code that named 'krx::abs' no 
```

## `cxx_more.std_reexport_dropped@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity'] (expected {'entity': ['krx_f']})

## `cxx_more.unnamed_type_api_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kanon_use'], 'functions': ['kanon_use']})
```text
binary: added _Z9kanon_usePN3KAnUt_E
source: added _Z9kanon_usePN3KAnUt_E
```

## `cxx_more.unnamed_type_api_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; sides {'binary': 'NO_CHANGE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kanon_use'], 'functions': ['kanon_use']})
```text
source: added _Z9kanon_usePN3KAn9._anon_18E
```

## `cxx_more.unnamed_type_api_added@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['kanon_use'], 'functions': ['kanon_use']})
```text
compatible: func_added _Z9kanon_usePN3KAnUt_E: New public function: kanon_use
compatible: func_added _ZN3KAnUt_aSERKS0_: New public header-only function (no exported symbol): operator=
compatible: func_added _ZN3KAnUt_aSEOS0_: New public header-only function (no exported symbol): operator=
compatible: type_added KAn: New type: KAn
risk: unnamed_type_in_public_abi _Z9kanon_usePN3KAnUt_E: Unnamed type leaks into the public ABI: kanon_use(KAn::{unnamed type#1}*) (unnamed struct/enum) — its m
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.unnamed_type_api_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 1 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 Added function:
  [A] 'function int kanon_use(struct {int v;}*)'    {_Z9kanon_usePN3KAnUt_E}
```

## `cxx_more.unnamed_type_api_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.unnamed_type_api_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; sides {'binary': 'NO_CHANGE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kanon_use'], 'functions': ['kanon_use']})
```text
source: added _Z9kanon_usePN3KAn9._anon_18E
```

## `cxx_more.unnamed_type_api_added@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['kanon_use'], 'functions': ['kanon_use']})
```text
compatible: func_added _Z9kanon_usePN3KAnUt_E: New public function: kanon_use
compatible: func_added _ZN3KAnUt_aSERKS0_: New public header-only function (no exported symbol): operator=
compatible: func_added _ZN3KAnUt_aSEOS0_: New public header-only function (no exported symbol): operator=
compatible: type_added KAn: New type: KAn
risk: unnamed_type_in_public_abi _Z9kanon_usePN3KAnUt_E: Unnamed type leaks into the public ABI: kanon_use(KAn::{unnamed type#1}*) (unnamed struct/enum) — its m
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.unnamed_type_api_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['kanon_use'], 'functions': ['kanon_use']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 1 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Added function symbol not referenced by debug info:
  [A] _Z9kanon_usePN3KAnUt_E
```

## `cxx_more.pimpl_member_renamed_under_inline_body@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Impl'], 'fields': ['count', 'size_']})

## `cxx_more.pimpl_member_renamed_under_inline_body@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Impl'], 'fields': ['count', 'size_']})

## `cxx_more.pimpl_member_renamed_under_inline_body@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['fields'] (expected {'fields': ['count', 'size_']})
```text
api_break: field_renamed kib::detail::Impl: Field renamed: kib::detail::Impl::count → size_
api_break: field_renamed Impl: Field renamed: Impl::count → size_
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
breaking: inline_body_references_renamed_member KW: Public class 'KW' has inline accessors (3 found) reaching into 'kib::detail::Impl' by name. Field 'count' wa
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.pimpl_member_renamed_under_inline_body@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Impl'], 'fields': ['count', 'size_']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `cxx_more.pimpl_member_renamed_under_inline_body@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.pimpl_member_renamed_under_inline_body@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields'] (expected {'entity': ['Impl'], 'fields': ['count', 'size_']})

## `cxx_more.pimpl_member_renamed_under_inline_body@stripped+headers` · abicheck compare
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['fields'] (expected {'fields': ['count', 'size_']})
```text
api_break: field_renamed Impl: Field renamed: Impl::count → size_
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
breaking: inline_body_references_renamed_member KW: Public class 'KW' has inline accessors (3 found) reaching into 'kib::detail::Impl' by name. Field 'count' wa
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.pimpl_member_renamed_under_inline_body@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields'] (expected {'entity': ['Impl'], 'fields': ['count', 'size_']})

## `cxx_more.cpu_dispatch_variants_dropped@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kdot_avx2', 'kscl_avx2', 'ksum_avx2', 'ksum_sse2'], 'functions': ['kdot_avx2', 'kscl_avx2', 'ksum_avx2', 'ksum_sse2']})
```text
binary: removed kdot_avx2
binary: removed kscl_avx2
binary: removed ksum_avx2
source: removed kdot_avx2
source: removed kscl_avx2
source: removed ksum_avx2
```

## `cxx_more.cpu_dispatch_variants_dropped@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kdot_avx2', 'kscl_avx2', 'ksum_avx2', 'ksum_sse2'], 'functions': ['kdot_avx2', 'kscl_avx2', 'ksum_avx2', 'ksum_sse2']})
```text
binary: removed kdot_avx2
binary: removed kscl_avx2
binary: removed ksum_avx2
source: removed kdot_avx2
source: removed kscl_avx2
source: removed ksum_avx2
```

## `cxx_more.cpu_dispatch_variants_dropped@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['kdot_avx2', 'kscl_avx2', 'ksum_avx2', 'ksum_sse2'], 'functions': ['kdot_avx2', 'kscl_avx2', 'ksum_avx2', 'ksum_sse2']})
```text
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
breaking: cpu_dispatch_isa_dropped <isa:avx2>: CPU dispatch ISA 'avx2' tier removed: 3 specialisations across 3 algorithms (kdot, kscl, ksum). Runtime dispatche
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.cpu_dispatch_variants_dropped@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['kdot_avx2', 'kscl_avx2', 'ksum_avx2', 'ksum_sse2'], 'functions': ['kdot_avx2', 'kscl_avx2', 'ksum_avx2', 'ksum_sse2']})
```text
Functions changes summary: 3 Removed, 0 Changed, 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
3 Removed functions:
  [D] 'function int kdot_avx2(int)'    {kdot_avx2}
  [D] 'function int kscl_avx2(int)'    {kscl_avx2}
  [D] 'function int ksum_avx2(int)'    {ksum_avx2}
```

## `cxx_more.cpu_dispatch_variants_dropped@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.cpu_dispatch_variants_dropped@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kdot_avx2', 'kscl_avx2', 'ksum_avx2', 'ksum_sse2'], 'functions': ['kdot_avx2', 'kscl_avx2', 'ksum_avx2', 'ksum_sse2']})
```text
binary: removed kdot_avx2
binary: removed kscl_avx2
binary: removed ksum_avx2
source: removed kdot_avx2
source: removed kscl_avx2
source: removed ksum_avx2
```

## `cxx_more.cpu_dispatch_variants_dropped@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['kdot_avx2', 'kscl_avx2', 'ksum_avx2', 'ksum_sse2'], 'functions': ['kdot_avx2', 'kscl_avx2', 'ksum_avx2', 'ksum_sse2']})
```text
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
breaking: cpu_dispatch_isa_dropped <isa:avx2>: CPU dispatch ISA 'avx2' tier removed: 3 specialisations across 3 algorithms (kdot, kscl, ksum). Runtime dispatche
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.cpu_dispatch_variants_dropped@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['kdot_avx2', 'kscl_avx2', 'ksum_avx2', 'ksum_sse2'], 'functions': ['kdot_avx2', 'kscl_avx2', 'ksum_avx2', 'ksum_sse2']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 3 Removed, 0 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
3 Removed function symbols not referenced by debug info:
  [D] kdot_avx2
  [D] kscl_avx2
  [D] ksum_avx2
```

## `cxx_more.handle_typedef_retargeted@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['kh_new']})
```text
binary/low: khandle Typedef_BaseType 
source/low: khandle Typedef_BaseType 
```

## `cxx_more.handle_typedef_retargeted@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['kh_new']})
```text
binary/low: khandle Typedef_BaseType 
source/low: khandle Typedef_BaseType 
```

## `cxx_more.handle_typedef_retargeted@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
- missed details: ['entity'] (expected {'entity': ['khandle']})
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function khandle kh_new()' at edit_seed.cpp:91:1 has some indirect sub-type changes:
    return type changed:
      underlying type 'KHC*' changed:
        in pointed to type 'struct KHC':
          entity changed from 'struct KHC' to 'void'
```

## `cxx_more.handle_typedef_retargeted@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.handle_typedef_retargeted@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['kh_new']})
```text
binary/low: khandle Typedef_BaseType 
source/low: khandle Typedef_BaseType 
```

## `cxx_more.handle_typedef_retargeted@stripped+headers` · libabigail abidiff
- expected: API_BREAK..BREAKING (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['khandle'], 'functions': ['kh_new']})

## `cxx_more.opaque_record_defined@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.opaque_record_defined@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.opaque_record_defined@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.opaque_record_defined@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.opaque_record_defined@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.opaque_record_defined@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..BREAKING (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.overload_retyped@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kput'], 'functions': ['kput']})
```text
binary: removed _Z4kputi
binary: added _Z4kputl
binary/high: _Z4kputi Symbol_Changed_Parameters
source: removed _Z4kputi
source: added _Z4kputl
source/medium: _Z4kputi Symbol_Changed_Parameters
```

## `cxx_more.overload_retyped@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kput'], 'functions': ['kput']})
```text
binary: removed _Z4kputi
binary: added _Z4kputl
binary/high: _Z4kputi Symbol_Changed_Parameters
source: removed _Z4kputi
source: added _Z4kputl
source/medium: _Z4kputi Symbol_Changed_Parameters
```

## `cxx_more.overload_retyped@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.overload_retyped@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kput'], 'functions': ['kput']})
```text
binary: removed _Z4kputi
binary: added _Z4kputl
binary/high: _Z4kputi Symbol_Changed_Parameters
source: removed _Z4kputi
source: added _Z4kputl
source/medium: _Z4kputi Symbol_Changed_Parameters
```

## `cxx_more.overload_retyped@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['kput'], 'functions': ['kput']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z4kputi
1 Added function symbol not referenced by debug info:
  [A] _Z4kputl
```

## `cxx_more.version_sentinel_typedef_bumped@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..API_BREAK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['kfoo_version_1_2_3', 'kfoo_version_1_2_4']})

## `cxx_more.version_sentinel_typedef_bumped@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..API_BREAK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['kfoo_version_1_2_3', 'kfoo_version_1_2_4']})

## `cxx_more.version_sentinel_typedef_bumped@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..API_BREAK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity'] (expected {'entity': ['kfoo_version_1_2_3', 'kfoo_version_1_2_4']})
```text
compatible: typedef_version_sentinel kfoo_version_1_2_3: Version-stamped typedef removed (compile-time sentinel, not an ABI break): kfoo_version_1_2_3
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.version_sentinel_typedef_bumped@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..API_BREAK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['kfoo_version_1_2_3', 'kfoo_version_1_2_4']})

## `cxx_more.version_sentinel_typedef_bumped@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..API_BREAK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.version_sentinel_typedef_bumped@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..API_BREAK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['kfoo_version_1_2_3', 'kfoo_version_1_2_4']})

## `cxx_more.version_sentinel_typedef_bumped@stripped+headers` · abicheck compare
- expected: COMPATIBLE..API_BREAK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity'] (expected {'entity': ['kfoo_version_1_2_3', 'kfoo_version_1_2_4']})
```text
compatible: typedef_version_sentinel kfoo_version_1_2_3: Version-stamped typedef removed (compile-time sentinel, not an ABI break): kfoo_version_1_2_3
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.version_sentinel_typedef_bumped@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..API_BREAK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['kfoo_version_1_2_3', 'kfoo_version_1_2_4']})

## `cxx_more.explicit_instantiation_dropped@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.explicit_instantiation_dropped@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'NO_CHANGE', 'source': 'INCOMPATIBLE'}
```text
source: removed _Z6ktwiceIdET_S0_
source: added _Z6ktwiceIdEdd
```

## `cxx_more.explicit_instantiation_dropped@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.explicit_instantiation_dropped@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'NO_CHANGE', 'source': 'INCOMPATIBLE'}
```text
source: removed _Z6ktwiceIdET_S0_
source: added _Z6ktwiceIdEdd
```

## `cxx_more.exported_instantiation_default_changed@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['__attribute__']})

## `cxx_more.exported_instantiation_default_changed@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'NO_CHANGE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['__attribute__']})
```text
source: removed _Z4kdtaIiiET0_T_
source: added _Z4kdtaIilET0_T_
```

## `cxx_more.exported_instantiation_default_changed@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['__attribute__']})
```text
breaking: func_visibility_changed _Z4kdtaIiiET0_T_: Function kdta is no longer exported by the new binary; its declaration remains in the new header
compatible: func_added _Z4kdtaIilET0_T_: New public function: kdta
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
breaking: instantiation_missing_from_binary _Z4kdtaIiiET0_T_: Template instantiation 'kdta' was exported by the old library but is missing from the new binary. 
breaking: default_template_arg_changed _Z4kdtaIiiET0_T_: Template instantiation 'kdta' substitutes to different arguments than its surviving sibling 'kdta'. Thi
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.exported_instantiation_default_changed@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity'] (expected {'entity': ['__attribute__']})
```text
Functions changes summary: 1 Removed, 0 Changed, 1 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 Removed function:
  [D] 'function int kdta<int, int>(int)'    {_Z4kdtaIiiET0_T_}
1 Added function:
  [A] 'function long int kdta<int, long int>(int)'    {_Z4kdtaIilET0_T_}
```

## `cxx_more.exported_instantiation_default_changed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.exported_instantiation_default_changed@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'NO_CHANGE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['__attribute__']})
```text
source: removed _Z4kdtaIiiET0_T_
source: added _Z4kdtaIilET0_T_
```

## `cxx_more.exported_instantiation_default_changed@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['__attribute__']})
```text
breaking: func_visibility_changed _Z4kdtaIiiET0_T_: Function kdta is no longer exported by the new binary; its declaration remains in the new header
compatible: func_added _Z4kdtaIilET0_T_: New public function: kdta
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
breaking: instantiation_missing_from_binary _Z4kdtaIiiET0_T_: Template instantiation 'kdta' was exported by the old library but is missing from the new binary. 
breaking: default_template_arg_changed _Z4kdtaIiiET0_T_: Template instantiation 'kdta' substitutes to different arguments than its surviving sibling 'kdta'. Thi
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.exported_instantiation_default_changed@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity'] (expected {'entity': ['__attribute__']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z4kdtaIiiET0_T_
1 Added function symbol not referenced by debug info:
  [A] _Z4kdtaIilET0_T_
```

## `cxx_more.struct_became_class@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.struct_became_class@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.struct_became_class@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.struct_became_class@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.struct_became_class@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.struct_became_class@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.tag_type_renamed@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['ktag_a', 'ktag_b']})

## `cxx_more.tag_type_renamed@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['ktag_a', 'ktag_b']})

## `cxx_more.tag_type_renamed@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity'] (expected {'entity': ['ktag_a', 'ktag_b']})
```text
Functions changes summary: 1 Removed, 0 Changed, 1 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 Removed function:
  [D] 'function int kfam<ktag_a>()'    {_Z4kfamI6ktag_aEiv}
1 Added function:
  [A] 'function int kfam<ktag_b>()'    {_Z4kfamI6ktag_bEiv}
```

## `cxx_more.tag_type_renamed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.tag_type_renamed@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['ktag_a', 'ktag_b']})

## `cxx_more.tag_type_renamed@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity'] (expected {'entity': ['ktag_a', 'ktag_b']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z4kfamI6ktag_aEiv
1 Added function symbol not referenced by debug info:
  [A] _Z4kfamI6ktag_bEiv
```

## `cxx_more.mandatory_template_param_added@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kmb_use'], 'functions': ['kmb_use']})
```text
binary: removed _Z7kmb_useP3KMbIiE
binary: added _Z7kmb_useP3KMbIicE
binary/high: _Z7kmb_useP3KMbIiE Symbol_Changed_Parameters
source: removed _Z7kmb_useP3KMbIiE
source: added _Z7kmb_useP3KMbIicE
source/medium: _Z7kmb_useP3KMbIiE Symbol_Changed_Parameters
```

## `cxx_more.mandatory_template_param_added@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kmb_use'], 'functions': ['kmb_use']})
```text
binary: removed _Z7kmb_useP3KMbIiE
binary: added _Z7kmb_useP3KMbIicE
binary/high: _Z7kmb_useP3KMbIiE Symbol_Changed_Parameters
source: removed _Z7kmb_useP3KMbIiE
source: added _Z7kmb_useP3KMbIicE
source/medium: _Z7kmb_useP3KMbIiE Symbol_Changed_Parameters
```

## `cxx_more.mandatory_template_param_added@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['kmb_use'], 'functions': ['kmb_use']})
```text
breaking: func_removed _Z7kmb_useP3KMbIiE: Public function removed: kmb_use
compatible: func_added _Z7kmb_useP3KMbIicE: New public function: kmb_use
compatible: type_added KMb<int, char>: New type: KMb<int, char>
risk: declaration_renamed KMb<int, char>: Graph evidence reconciles 'KMb<int>' (old) with 'KMb<int, char>' (new) as the same declaration, renamed (match evidenc
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
api_break: mandatory_template_param_added KMb: Template 'KMb' minimum effective argument count grew from 1 to 2. Consumers that wrote 'KMb<...1 args...>' withou
```

## `cxx_more.mandatory_template_param_added@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.mandatory_template_param_added@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kmb_use'], 'functions': ['kmb_use']})
```text
binary: removed _Z7kmb_useP3KMbIiE
binary: added _Z7kmb_useP3KMbIicE
binary/high: _Z7kmb_useP3KMbIiE Symbol_Changed_Parameters
source: removed _Z7kmb_useP3KMbIiE
source: added _Z7kmb_useP3KMbIicE
source/medium: _Z7kmb_useP3KMbIiE Symbol_Changed_Parameters
```

## `cxx_more.mandatory_template_param_added@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['kmb_use'], 'functions': ['kmb_use']})
```text
breaking: func_removed _Z7kmb_useP3KMbIiE: Public function removed: kmb_use
compatible: func_added _Z7kmb_useP3KMbIicE: New public function: kmb_use
compatible: type_added KMb<int, char>: New type: KMb<int, char>
risk: declaration_renamed KMb<int, char>: Graph evidence reconciles 'KMb<int>' (old) with 'KMb<int, char>' (new) as the same declaration, renamed (match evidenc
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
api_break: mandatory_template_param_added KMb: Template 'KMb' minimum effective argument count grew from 1 to 2. Consumers that wrote 'KMb<...1 args...>' withou
```

## `cxx_more.mandatory_template_param_added@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['kmb_use'], 'functions': ['kmb_use']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z7kmb_useP3KMbIiE
1 Added function symbol not referenced by debug info:
  [A] _Z7kmb_useP3KMbIicE
```

## `cxx_more.nonpod_field_added_in_tail_padding@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['ktp_get']})
```text
binary/low: KTP Added_Field d
source/low: KTP Added_Field d
```

## `cxx_more.nonpod_field_added_in_tail_padding@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['ktp_get']})
```text
binary/low: KTP Added_Field d
source/low: KTP Added_Field d
```

## `cxx_more.nonpod_field_added_in_tail_padding@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; exit bits ['abi_change']
- missed details: ['functions'] (expected {'functions': ['ktp_get']})
```text
Functions changes summary: 0 Removed, 1 Changed (1 filtered out), 0 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'method KTP::KTP()' at edit_seed.h:142:1 has some indirect sub-type changes:
    implicit parameter 0 of type 'KTP*' has sub-type changes:
      in pointed to type 'struct KTP' at edit_seed.h:142:1:
        type size hasn't changed
        1 data member insertion:
```

## `cxx_more.nonpod_field_added_in_tail_padding@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.nonpod_field_added_in_tail_padding@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['functions'] (expected {'functions': ['ktp_get']})
```text
binary/low: KTP Added_Field d
source/low: KTP Added_Field d
```

## `cxx_more.nonpod_field_added_in_tail_padding@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..BREAKING (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['KTP'], 'fields': ['d'], 'functions': ['ktp_get']})

## `cxx_more.polymorphic_type_added_without_virtual_dtor@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kpn_make', 'run'], 'functions': ['kpn_make']})
```text
binary: added _Z8kpn_makev
binary: added _ZN3KPn3runEv
source: added _Z8kpn_makev
source: added _ZN3KPn3runEv
```

## `cxx_more.polymorphic_type_added_without_virtual_dtor@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kpn_make', 'run'], 'functions': ['kpn_make']})
```text
binary: added _Z8kpn_makev
binary: added _ZN3KPn3runEv
source: added _Z8kpn_makev
source: added _ZN3KPn3runEv
```

## `cxx_more.polymorphic_type_added_without_virtual_dtor@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['kpn_make', 'run'], 'functions': ['kpn_make']})
```text
compatible: func_added _Z8kpn_makev: New public function: kpn_make
compatible: func_added _ZN3KPn3runEv: New public function: run
compatible: type_added KPn: New type: KPn
compatible: func_added_elf_only _ZN3KPnC1Ev: New exported C++ ABI artifact (constructor) of a class, accounted for by its class's declaration: _ZN3KPnC1Ev
compatible: func_added_elf_only _ZN3KPnC2Ev: New exported C++ ABI artifact (constructor) of a class, accounted for by its class's declaration: _ZN3KPnC2Ev
compatible: var_added_elf_only _ZTI3KPn: New exported C++ ABI artifact (typeinfo) of class KPn: _ZTI3KPn
compatible: var_added_elf_only _ZTS3KPn: New exported C++ ABI artifact (typeinfo name) of class KPn: _ZTS3KPn
compatible: var_added_elf_only _ZTV3KPn: New exported C++ ABI artifact (vtable) of class KPn: _ZTV3KPn
```

## `cxx_more.polymorphic_type_added_without_virtual_dtor@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 2 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 2 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 3 Added variable symbols not referenced by debug info
2 Added functions:
  [A] 'method virtual int KPn::run()'    {_ZN3KPn3runEv}
    note that this adds a new entry to the vtable of struct KPn
  [A] 'function KPn* kpn_make()'    {_Z8kpn_makev}
```

## `cxx_more.polymorphic_type_added_without_virtual_dtor@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.polymorphic_type_added_without_virtual_dtor@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kpn_make', 'run'], 'functions': ['kpn_make']})
```text
binary: added _Z8kpn_makev
binary: added _ZN3KPn3runEv
source: added _Z8kpn_makev
source: added _ZN3KPn3runEv
```

## `cxx_more.polymorphic_type_added_without_virtual_dtor@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['kpn_make', 'run'], 'functions': ['kpn_make']})
```text
compatible: func_added _Z8kpn_makev: New public function: kpn_make
compatible: func_added _ZN3KPn3runEv: New public function: run
compatible: type_added KPn: New type: KPn
compatible: func_added_elf_only _ZN3KPnC1Ev: New exported C++ ABI artifact (constructor) of a class, accounted for by its class's declaration: _ZN3KPnC1Ev
compatible: func_added_elf_only _ZN3KPnC2Ev: New exported C++ ABI artifact (constructor) of a class, accounted for by its class's declaration: _ZN3KPnC2Ev
compatible: var_added_elf_only _ZTI3KPn: New exported C++ ABI artifact (typeinfo) of class KPn: _ZTI3KPn
compatible: var_added_elf_only _ZTS3KPn: New exported C++ ABI artifact (typeinfo name) of class KPn: _ZTS3KPn
compatible: var_added_elf_only _ZTV3KPn: New exported C++ ABI artifact (vtable) of class KPn: _ZTV3KPn
```

## `cxx_more.polymorphic_type_added_without_virtual_dtor@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['kpn_make', 'run'], 'functions': ['kpn_make']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 4 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 3 Added variable symbols not referenced by debug info
4 Added function symbols not referenced by debug info:
  [A] _Z8kpn_makev
  [A] _ZN3KPn3runEv
  [A] _ZN3KPnC1Ev, aliases _ZN3KPnC2Ev
```

## `cxx_more.stl_by_value_api_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kstl_len'], 'functions': ['kstl_len']})
```text
binary: added _Z8kstl_lenNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
source: added _Z8kstl_lenNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
```

## `cxx_more.stl_by_value_api_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kstl_len'], 'functions': ['kstl_len']})
```text
binary: added _Z8kstl_lenNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
source: added _Z8kstl_lenNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
```

## `cxx_more.stl_by_value_api_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 1 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 Added function:
  [A] 'function int kstl_len(std::string)'    {_Z8kstl_lenNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE}
```

## `cxx_more.stl_by_value_api_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.stl_by_value_api_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['kstl_len'], 'functions': ['kstl_len']})
```text
binary: added _Z8kstl_lenNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
source: added _Z8kstl_lenNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
```

## `cxx_more.stl_by_value_api_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **wrong**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['kstl_len'], 'functions': ['kstl_len']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 1 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Added function symbol not referenced by debug info:
  [A] _Z8kstl_lenNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
```

## `cxx_more.class_visibility_hidden@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['__attribute__', 'kget']})

## `cxx_more.class_visibility_hidden@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['__attribute__', 'kget']})

## `cxx_more.class_visibility_hidden@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['__attribute__', 'kget']})
```text
breaking: var_removed_elf_only _ZTI3KTV: Removed exported C++ ABI artifact (typeinfo) of class KTV: _ZTI3KTV
breaking: var_removed_elf_only _ZTS3KTV: Removed exported C++ ABI artifact (typeinfo name) of class KTV: _ZTS3KTV
breaking: var_removed_elf_only _ZTV3KTV: Removed exported C++ ABI artifact (vtable) of class KTV: _ZTV3KTV
breaking: type_visibility_changed KTV: Type visibility narrowed: KTV (default → hidden); its members stay exported but its typeinfo/vtable symbols are no longer
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 4 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.class_visibility_hidden@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity'] (expected {'entity': ['__attribute__', 'kget']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 3 Removed, 0 Added variable symbols not referenced by debug info
3 Removed variable symbols not referenced by debug info:
  [D] _ZTI3KTV
  [D] _ZTS3KTV
  [D] _ZTV3KTV
```

## `cxx_more.class_visibility_hidden@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.class_visibility_hidden@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['__attribute__', 'kget']})

## `cxx_more.class_visibility_hidden@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['__attribute__', 'kget']})
```text
breaking: var_removed_elf_only _ZTI3KTV: Removed exported C++ ABI artifact (typeinfo) of class KTV: _ZTI3KTV
breaking: var_removed_elf_only _ZTS3KTV: Removed exported C++ ABI artifact (typeinfo name) of class KTV: _ZTS3KTV
breaking: var_removed_elf_only _ZTV3KTV: Removed exported C++ ABI artifact (vtable) of class KTV: _ZTV3KTV
breaking: type_visibility_changed KTV: Type visibility narrowed: KTV (default → hidden); its members stay exported but its typeinfo/vtable symbols are no longer
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 4 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.class_visibility_hidden@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity'] (expected {'entity': ['__attribute__', 'kget']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 3 Removed, 0 Added variable symbols not referenced by debug info
3 Removed variable symbols not referenced by debug info:
  [D] _ZTI3KTV
  [D] _ZTS3KTV
  [D] _ZTV3KTV
```

- `cxx_more.new_side_dumped_without_headers@stripped+headers`: not run (input_violation: stripped side carries DWARF)
## `cxx_more.virtual_appended_after_last_slot@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
binary: added _ZN3VAp1gEv
source: added _ZN3VAp1gEv
```

## `cxx_more.virtual_appended_after_last_slot@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
binary/high: VAp Added_Virtual_Method _ZN3VAp1gEv
binary: added _ZN3VAp1gEv
source: added _ZN3VAp1gEv
```

## `cxx_more.virtual_appended_after_last_slot@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
breaking: type_vtable_changed VAp: vtable changed: VAp
breaking: vtable_slot_count_changed _ZTV3VAp: Vtable for 'VAp' changed size: 40 → 48 bytes (+1 pointer-sized word). Virtual functions were net added or removed,
compatible: func_added _ZN3VAp1gEv: New public function: g
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_grew <surface>: public surface grew: 688 → 689 declarations (+1)
```

## `cxx_more.virtual_appended_after_last_slot@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.virtual_appended_after_last_slot@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
binary/high: VAp Added_Virtual_Method _ZN3VAp1gEv
binary: added _ZN3VAp1gEv
source: added _ZN3VAp1gEv
```

## `cxx_more.virtual_appended_after_last_slot@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
breaking: type_vtable_changed VAp: vtable changed: VAp
breaking: vtable_slot_count_changed _ZTV3VAp: Vtable for 'VAp' changed size: 40 → 48 bytes (+1 pointer-sized word). Virtual functions were net added or removed,
compatible: func_added _ZN3VAp1gEv: New public function: g
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_grew <surface>: public surface grew: 688 → 689 declarations (+1)
```

## `cxx_more.virtual_appended_after_last_slot@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; exit bits ['abi_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 1 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Added function symbol not referenced by debug info:
  [A] _ZN3VAp1gEv
```

## `cxx_more.method_became_virtual@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})

## `cxx_more.method_became_virtual@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
binary/high: VMv Added_Virtual_Method _ZN3VMv1gEv
```

## `cxx_more.method_became_virtual@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
breaking: type_vtable_changed VMv: vtable changed: VMv
breaking: vtable_slot_count_changed _ZTV3VMv: Vtable for 'VMv' changed size: 32 → 40 bytes (+1 pointer-sized word). Virtual functions were net added or removed,
breaking: func_virtual_added _ZN3VMv1gEv: Function became virtual: g
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 3 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.method_became_virtual@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.method_became_virtual@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
binary/high: VMv Added_Virtual_Method _ZN3VMv1gEv
```

## `cxx_more.method_became_virtual@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
breaking: type_vtable_changed VMv: vtable changed: VMv
breaking: vtable_slot_count_changed _ZTV3VMv: Vtable for 'VMv' changed size: 32 → 40 bytes (+1 pointer-sized word). Virtual functions were net added or removed,
breaking: func_virtual_added _ZN3VMv1gEv: Function became virtual: g
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 3 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.method_became_virtual@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})

## `cxx_more.method_became_nonvirtual@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
binary/high: VNv Removed_Virtual_Method _ZN3VNv1gEv
```

## `cxx_more.method_became_nonvirtual@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
binary/high: VNv Removed_Virtual_Method _ZN3VNv1gEv
```

## `cxx_more.method_became_nonvirtual@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
breaking: type_vtable_changed VNv: vtable changed: VNv
breaking: vtable_slot_count_changed _ZTV3VNv: Vtable for 'VNv' changed size: 40 → 32 bytes (-1 pointer-sized word). Virtual functions were net added or removed,
breaking: func_virtual_removed _ZN3VNv1gEv: Function is no longer virtual: g
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 3 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.method_became_nonvirtual@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.method_became_nonvirtual@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
binary/high: VNv Removed_Virtual_Method _ZN3VNv1gEv
```

## `cxx_more.method_became_nonvirtual@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})
```text
breaking: type_vtable_changed VNv: vtable changed: VNv
breaking: vtable_slot_count_changed _ZTV3VNv: Vtable for 'VNv' changed size: 40 → 32 bytes (-1 pointer-sized word). Virtual functions were net added or removed,
breaking: func_virtual_removed _ZN3VNv1gEv: Function is no longer virtual: g
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 3 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.method_became_nonvirtual@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['g'], 'functions': ['g']})

## `cxx_more.override_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['entity'] (expected {'entity': ['f']})
```text
binary/low: VOD Overridden_Virtual_Method 
binary: added _ZN3VOD1fEv
source/low: VOD Overridden_Virtual_Method 
source: added _ZN3VOD1fEv
```

## `cxx_more.override_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['entity'] (expected {'entity': ['f']})
```text
binary/low: VOD Overridden_Virtual_Method 
binary: added _ZN3VOD1fEv
source/low: VOD Overridden_Virtual_Method 
source: added _ZN3VOD1fEv
```

## `cxx_more.override_added@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity'] (expected {'entity': ['f']})
```text
compatible: func_added _ZN3VOD1fEv: New public function: f
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: public_surface_grew <surface>: public surface grew: 688 → 689 declarations (+1)
```

## `cxx_more.override_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.override_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['entity'] (expected {'entity': ['f']})
```text
binary/low: VOD Overridden_Virtual_Method 
binary: added _ZN3VOD1fEv
source/low: VOD Overridden_Virtual_Method 
source: added _ZN3VOD1fEv
```

## `cxx_more.override_added@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity'] (expected {'entity': ['f']})
```text
compatible: func_added _ZN3VOD1fEv: New public function: f
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: public_surface_grew <surface>: public surface grew: 688 → 689 declarations (+1)
```

## `cxx_more.override_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; exit bits ['abi_change']
- missed details: ['entity'] (expected {'entity': ['f']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 1 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Added function symbol not referenced by debug info:
  [A] _ZN3VOD1fEv
```

## `cxx_more.override_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['f']})
```text
binary/low: VRD Overridden_Virtual_Method_B 
binary: removed _ZN3VRD1fEv
source/low: VRD Overridden_Virtual_Method_B 
source: removed _ZN3VRD1fEv
```

## `cxx_more.override_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['f']})
```text
binary/low: VRD Overridden_Virtual_Method_B 
binary: removed _ZN3VRD1fEv
source/low: VRD Overridden_Virtual_Method_B 
source: removed _ZN3VRD1fEv
```

## `cxx_more.override_removed@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['f']})
```text
breaking: func_removed _ZN3VRD1fEv: Public function removed: f
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_shrank <surface>: public surface shrank: 688 → 687 declarations (-1)
```

## `cxx_more.override_removed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.override_removed@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity'] (expected {'entity': ['f']})
```text
binary/low: VRD Overridden_Virtual_Method_B 
binary: removed _ZN3VRD1fEv
source/low: VRD Overridden_Virtual_Method_B 
source: removed _ZN3VRD1fEv
```

## `cxx_more.override_removed@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['f']})
```text
breaking: func_removed _ZN3VRD1fEv: Public function removed: f
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
compatible: public_surface_shrank <surface>: public surface shrank: 688 → 687 declarations (-1)
```

## `cxx_more.override_removed@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity'] (expected {'entity': ['f']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _ZN3VRD1fEv
```

## `cxx_more.virtual_became_final@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.virtual_became_final@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.virtual_became_final@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity'] (expected {'entity': ['f']})
```text
api_break: func_became_final _ZN3VFn1fEv: Virtual method became final: f
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.virtual_became_final@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.virtual_became_final@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.virtual_became_final@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.virtual_became_final@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['entity'] (expected {'entity': ['f']})
```text
api_break: func_became_final _ZN3VFn1fEv: Virtual method became final: f
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.virtual_became_final@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.virtual_lost_final@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.virtual_lost_final@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.virtual_lost_final@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity'] (expected {'entity': ['f']})
```text
risk: func_lost_final _ZN3VUf1fEv: Virtual method lost final: f
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.virtual_lost_final@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.virtual_lost_final@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.virtual_lost_final@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.virtual_lost_final@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity'] (expected {'entity': ['f']})
```text
risk: func_lost_final _ZN3VUf1fEv: Virtual method lost final: f
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.virtual_lost_final@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['f']})

## `cxx_more.destructor_became_virtual@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
```text
binary: added _ZN3VDaD0Ev
source: added _ZN3VDaD0Ev
```

## `cxx_more.destructor_became_virtual@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; sides {'binary': 'COMPATIBLE', 'source': 'NO_CHANGE'}
```text
binary/safe: VDa Added_Virtual_Method_At_End_Of_Leaf_Allocable_Class _ZN3VDaD1Ev
binary: added _ZN3VDaD0Ev
```

## `cxx_more.destructor_became_virtual@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.destructor_became_virtual@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; sides {'binary': 'COMPATIBLE', 'source': 'NO_CHANGE'}
```text
binary/safe: VDa Added_Virtual_Method_At_End_Of_Leaf_Allocable_Class _ZN3VDaD0Ev
binary: added _ZN3VDaD0Ev
```

## `cxx_more.destructor_became_virtual@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 1 Added function symbol not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Added function symbol not referenced by debug info:
  [A] _ZN3VDaD0Ev
```

## `cxx_more.destructor_became_nonvirtual@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.key_function_inlined@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['VKy'], 'fields': ['k'], 'functions': ['vky_make']})

## `cxx_more.key_function_inlined@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['VKy'], 'fields': ['k'], 'functions': ['vky_make']})

## `cxx_more.key_function_inlined@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['VKy'], 'fields': ['k'], 'functions': ['vky_make']})
```text
risk: func_became_inline _ZN3VKy1fEv: Function became inline, symbol still exported: f
compatible: symbol_binding_changed _ZN3VKy1fEv: Symbol binding changed: _ZN3VKy1fEv (global → weak)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.key_function_inlined@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['VKy'], 'fields': ['k'], 'functions': ['vky_make']})

## `cxx_more.key_function_inlined@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.key_function_inlined@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['VKy'], 'fields': ['k'], 'functions': ['vky_make']})

## `cxx_more.key_function_inlined@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['VKy'], 'fields': ['k'], 'functions': ['vky_make']})
```text
risk: func_became_inline _ZN3VKy1fEv: Function became inline, symbol still exported: f
compatible: symbol_binding_changed _ZN3VKy1fEv: Symbol binding changed: _ZN3VKy1fEv (global → weak)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.key_function_inlined@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['VKy'], 'fields': ['k'], 'functions': ['vky_make']})

## `cxx_more.override_return_became_covariant@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['entity'] (expected {'entity': ['clone']})
```text
binary/low: _ZN3VCD5cloneEv Return_BaseType
source/low: _ZN3VCD5cloneEv Return_BaseType
```

## `cxx_more.override_return_became_covariant@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['entity'] (expected {'entity': ['clone']})
```text
binary/low: _ZN3VCD5cloneEv Return_BaseType
source/low: _ZN3VCD5cloneEv Return_BaseType
```

## `cxx_more.override_return_became_covariant@dwarf+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity'] (expected {'entity': ['clone']})
```text
risk: func_return_covariant_narrowed _ZN3VCD5cloneEv: Return type narrowed to a derived class at offset 0: _ZN3VCD5cloneEv VCB* -> VCD* (same address, same mang
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.override_return_became_covariant@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; exit bits ['abi_change', 'incompatible_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'method virtual VCB* VCD::clone()' at edit_seed.cpp:165:1 has some indirect sub-type changes:
    return type changed:
      in pointed to type 'struct VCB' at edit_seed.h:220:1:
        type name changed from 'VCB' to 'VCD'
        type size hasn't changed
```

## `cxx_more.override_return_became_covariant@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.override_return_became_covariant@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
- missed details: ['entity'] (expected {'entity': ['clone']})
```text
binary/low: _ZN3VCD5cloneEv Return_BaseType
source/low: _ZN3VCD5cloneEv Return_BaseType
```

## `cxx_more.override_return_became_covariant@stripped+headers` · abicheck compare
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **correct**
- missed details: ['entity'] (expected {'entity': ['clone']})
```text
risk: func_return_covariant_narrowed _ZN3VCD5cloneEv: Return type narrowed to a derived class at offset 0: _ZN3VCD5cloneEv VCB* -> VCD* (same address, same mang
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.override_return_became_covariant@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['clone']})

## `cxx_more.last_virtual_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['f']})
```text
binary/high: VUp Removed_Last_Virtual_Method _ZN3VUp1fEv
binary/high: VUp Removed_Virtual_Method _ZN3VUp1fEv
binary/low: VUp DataType_Size 
```

## `cxx_more.last_virtual_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['f']})
```text
binary/high: VUp Removed_Last_Virtual_Method _ZN3VUp1fEv
binary/low: VUp DataType_Size 
```

## `cxx_more.last_virtual_removed@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['f']})
```text
breaking: struct_field_removed VUp::_vptr.VUp: Struct field removed: VUp::_vptr.VUp
breaking: type_size_changed VUp: Size changed: VUp (128 → 32 bits)
breaking: type_alignment_changed VUp: Alignment changed: VUp (64 → 32 bits)
breaking: type_field_offset_changed VUp: Field offset changed: VUp::a (64 → 0 bits)
breaking: type_vtable_changed VUp: vtable changed: VUp
breaking: func_virtual_removed _ZN3VUp1fEv: Function is no longer virtual: f
breaking: var_removed_elf_only _ZTI3VUp: Removed exported C++ ABI artifact (typeinfo) of class VUp: _ZTI3VUp
breaking: var_removed_elf_only _ZTS3VUp: Removed exported C++ ABI artifact (typeinfo name) of class VUp: _ZTS3VUp
```

## `cxx_more.last_virtual_removed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.last_virtual_removed@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['f']})
```text
binary/high: VUp Removed_Last_Virtual_Method _ZN3VUp1fEv
binary/low: VUp DataType_Size 
```

## `cxx_more.last_virtual_removed@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['entity'] (expected {'entity': ['f']})
```text
breaking: type_size_changed VUp: Size changed: VUp (128 → 32 bits)
breaking: type_alignment_changed VUp: Alignment changed: VUp (64 → 32 bits)
breaking: type_field_offset_changed VUp: Field offset changed: VUp::a (64 → 0 bits)
breaking: type_vtable_changed VUp: vtable changed: VUp
breaking: func_virtual_removed _ZN3VUp1fEv: Function is no longer virtual: f
breaking: var_removed_elf_only _ZTI3VUp: Removed exported C++ ABI artifact (typeinfo) of class VUp: _ZTI3VUp
breaking: var_removed_elf_only _ZTS3VUp: Removed exported C++ ABI artifact (typeinfo name) of class VUp: _ZTS3VUp
breaking: var_removed_elf_only _ZTV3VUp: Removed exported C++ ABI artifact (vtable) of class VUp: _ZTV3VUp
```

## `cxx_more.last_virtual_removed@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity'] (expected {'entity': ['f']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 0 Removed, 0 Added function symbol not referenced by debug info
Variable symbols changes summary: 3 Removed, 0 Added variable symbols not referenced by debug info
3 Removed variable symbols not referenced by debug info:
  [D] _ZTI3VUp
  [D] _ZTS3VUp
  [D] _ZTV3VUp
```

## `cxx_more.enum_enumerator_alias_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['en_alias_use']})
```text
binary/safe: EN_alias Added_Enum_Member ENALIAS_ALIAS
source/safe: EN_alias Added_Enum_Member ENALIAS_ALIAS
```

## `cxx_more.enum_enumerator_alias_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['en_alias_use']})
```text
binary/safe: EN_alias Added_Enum_Member ENALIAS_ALIAS
source/safe: EN_alias Added_Enum_Member ENALIAS_ALIAS
```

## `cxx_more.enum_enumerator_alias_added@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['functions'] (expected {'functions': ['en_alias_use']})
```text
compatible: enum_member_added EN_alias::ENALIAS_ALIAS: Enum member added: EN_alias::ENALIAS_ALIAS
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.enum_enumerator_alias_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EN_alias'], 'functions': ['en_alias_use']})

## `cxx_more.enum_enumerator_alias_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.enum_enumerator_alias_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['en_alias_use']})
```text
binary/safe: EN_alias Added_Enum_Member ENALIAS_ALIAS
source/safe: EN_alias Added_Enum_Member ENALIAS_ALIAS
```

## `cxx_more.enum_enumerator_alias_added@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['functions'] (expected {'functions': ['en_alias_use']})
```text
compatible: enum_member_added EN_alias::ENALIAS_ALIAS: Enum member added: EN_alias::ENALIAS_ALIAS
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.enum_enumerator_alias_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EN_alias'], 'functions': ['en_alias_use']})

## `cxx_more.enum_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EN_added']})

## `cxx_more.enum_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EN_added']})

## `cxx_more.enum_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['EN_added']})

## `cxx_more.enum_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.enum_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EN_added']})

## `cxx_more.enum_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['EN_added']})

## `cxx_more.enum_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EN_removed']})

## `cxx_more.enum_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EN_removed']})

## `cxx_more.enum_removed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity'] (expected {'entity': ['EN_removed']})

## `cxx_more.enum_removed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.enum_removed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EN_removed']})

## `cxx_more.enum_removed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity'] (expected {'entity': ['EN_removed']})

## `cxx_more.fixed_enum_enumerator_appended@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_append_use']})
```text
binary/safe: EF_append Added_Enum_Member EFAPPEND_D
source/safe: EF_append Added_Enum_Member EFAPPEND_D
```

## `cxx_more.fixed_enum_enumerator_appended@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_append_use']})
```text
binary/safe: EF_append Added_Enum_Member EFAPPEND_D
source/safe: EF_append Added_Enum_Member EFAPPEND_D
```

## `cxx_more.fixed_enum_enumerator_appended@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_append_use']})
```text
compatible: enum_member_added EF_append::EFAPPEND_D: Enum member added: EF_append::EFAPPEND_D
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.fixed_enum_enumerator_appended@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_append'], 'functions': ['ef_append_use']})
```text
Functions changes summary: 0 Removed, 0 Changed (1 filtered out), 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
```

## `cxx_more.fixed_enum_enumerator_appended@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.fixed_enum_enumerator_appended@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_append_use']})
```text
binary/safe: EF_append Added_Enum_Member EFAPPEND_D
source/safe: EF_append Added_Enum_Member EFAPPEND_D
```

## `cxx_more.fixed_enum_enumerator_appended@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_append_use']})
```text
compatible: enum_member_added EF_append::EFAPPEND_D: Enum member added: EF_append::EFAPPEND_D
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.fixed_enum_enumerator_appended@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_append'], 'functions': ['ef_append_use']})

## `cxx_more.fixed_enum_enumerator_inserted@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_insert_use']})
```text
binary/medium: EF_insert Enum_Member_Value EFINSERT_B
binary/medium: EF_insert Enum_Member_Value EFINSERT_C
binary/safe: EF_insert Added_Enum_Member EFINSERT_X
source/safe: EF_insert Added_Enum_Member EFINSERT_X
source/safe: EF_insert Enum_Member_Value EFINSERT_B
source/safe: EF_insert Enum_Member_Value EFINSERT_C
```

## `cxx_more.fixed_enum_enumerator_inserted@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_insert_use']})
```text
binary/medium: EF_insert Enum_Member_Value EFINSERT_B
binary/medium: EF_insert Enum_Member_Value EFINSERT_C
binary/safe: EF_insert Added_Enum_Member EFINSERT_X
source/safe: EF_insert Added_Enum_Member EFINSERT_X
source/safe: EF_insert Enum_Member_Value EFINSERT_B
source/safe: EF_insert Enum_Member_Value EFINSERT_C
```

## `cxx_more.fixed_enum_enumerator_inserted@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_insert_use']})
```text
breaking: enum_member_value_changed EF_insert::EFINSERT_B: Enum member value changed: EF_insert::EFINSERT_B (1 → 2)
breaking: enum_member_value_changed EF_insert::EFINSERT_C: Enum member value changed: EF_insert::EFINSERT_C (2 → 3)
compatible: enum_member_added EF_insert::EFINSERT_X: Enum member added: EF_insert::EFINSERT_X
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.fixed_enum_enumerator_inserted@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ef_insert_use(EF_insert)' at edit_seed.cpp:171:1 has some indirect sub-type changes:
    parameter 1 of type 'enum EF_insert' has sub-type changes:
      type size hasn't changed
      1 enumerator insertion:
        'EF_insert::EFINSERT_X' value '1'
```

## `cxx_more.fixed_enum_enumerator_inserted@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.fixed_enum_enumerator_inserted@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_insert_use']})
```text
binary/medium: EF_insert Enum_Member_Value EFINSERT_B
binary/medium: EF_insert Enum_Member_Value EFINSERT_C
binary/safe: EF_insert Added_Enum_Member EFINSERT_X
source/safe: EF_insert Added_Enum_Member EFINSERT_X
source/safe: EF_insert Enum_Member_Value EFINSERT_B
source/safe: EF_insert Enum_Member_Value EFINSERT_C
```

## `cxx_more.fixed_enum_enumerator_inserted@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_insert_use']})
```text
breaking: enum_member_value_changed EF_insert::EFINSERT_B: Enum member value changed: EF_insert::EFINSERT_B
breaking: enum_member_value_changed EF_insert::EFINSERT_C: Enum member value changed: EF_insert::EFINSERT_C
compatible: enum_member_added EF_insert::EFINSERT_X: Enum member added: EF_insert::EFINSERT_X
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.fixed_enum_enumerator_inserted@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_insert'], 'functions': ['ef_insert_use']})

## `cxx_more.fixed_enum_enumerator_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_remove_use']})
```text
binary/low: EF_remove Enum_Member_Removed EFREMOVE_C
source/high: EF_remove Enum_Member_Removed EFREMOVE_C
```

## `cxx_more.fixed_enum_enumerator_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_remove_use']})
```text
binary/low: EF_remove Enum_Member_Removed EFREMOVE_C
source/high: EF_remove Enum_Member_Removed EFREMOVE_C
```

## `cxx_more.fixed_enum_enumerator_removed@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_remove_use']})
```text
breaking: enum_member_removed EF_remove::EFREMOVE_C: Enum member removed: EF_remove::EFREMOVE_C
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.fixed_enum_enumerator_removed@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ef_remove_use(EF_remove)' at edit_seed.cpp:172:1 has some indirect sub-type changes:
    parameter 1 of type 'enum EF_remove' has sub-type changes:
      type size hasn't changed
      1 enumerator deletion:
        'EF_remove::EFREMOVE_C' value '2'
```

## `cxx_more.fixed_enum_enumerator_removed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.fixed_enum_enumerator_removed@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_remove_use']})
```text
binary/low: EF_remove Enum_Member_Removed EFREMOVE_C
source/high: EF_remove Enum_Member_Removed EFREMOVE_C
```

## `cxx_more.fixed_enum_enumerator_removed@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_remove_use']})
```text
breaking: enum_member_removed EF_remove::EFREMOVE_C: Enum member removed: EF_remove::EFREMOVE_C
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 1 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.fixed_enum_enumerator_removed@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_remove'], 'functions': ['ef_remove_use']})

## `cxx_more.fixed_enum_enumerator_value_changed@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_value_use']})
```text
binary/medium: EF_value Enum_Member_Value EFVALUE_B
binary/medium: EF_value Enum_Member_Value EFVALUE_C
source/safe: EF_value Enum_Member_Value EFVALUE_B
source/safe: EF_value Enum_Member_Value EFVALUE_C
```

## `cxx_more.fixed_enum_enumerator_value_changed@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_value_use']})
```text
binary/medium: EF_value Enum_Member_Value EFVALUE_B
binary/medium: EF_value Enum_Member_Value EFVALUE_C
source/safe: EF_value Enum_Member_Value EFVALUE_B
source/safe: EF_value Enum_Member_Value EFVALUE_C
```

## `cxx_more.fixed_enum_enumerator_value_changed@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_value_use']})
```text
breaking: enum_member_value_changed EF_value::EFVALUE_B: Enum member value changed: EF_value::EFVALUE_B (1 → 10)
breaking: enum_member_value_changed EF_value::EFVALUE_C: Enum member value changed: EF_value::EFVALUE_C (2 → 11)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.fixed_enum_enumerator_value_changed@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ef_value_use(EF_value)' at edit_seed.cpp:173:1 has some indirect sub-type changes:
    parameter 1 of type 'enum EF_value' has sub-type changes:
      type size hasn't changed
      2 enumerator changes:
        'EF_value::EFVALUE_B' from value '1' to '10' at edit_seed.h:233:1
```

## `cxx_more.fixed_enum_enumerator_value_changed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.fixed_enum_enumerator_value_changed@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_value_use']})
```text
binary/medium: EF_value Enum_Member_Value EFVALUE_B
binary/medium: EF_value Enum_Member_Value EFVALUE_C
source/safe: EF_value Enum_Member_Value EFVALUE_B
source/safe: EF_value Enum_Member_Value EFVALUE_C
```

## `cxx_more.fixed_enum_enumerator_value_changed@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_value_use']})
```text
breaking: enum_member_value_changed EF_value::EFVALUE_B: Enum member value changed: EF_value::EFVALUE_B
breaking: enum_member_value_changed EF_value::EFVALUE_C: Enum member value changed: EF_value::EFVALUE_C
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.fixed_enum_enumerator_value_changed@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_value'], 'functions': ['ef_value_use']})

## `cxx_more.fixed_enum_enumerator_values_swapped@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_swap_use']})
```text
binary/medium: EF_swap Enum_Member_Value EFSWAP_B
binary/medium: EF_swap Enum_Member_Value EFSWAP_C
source/safe: EF_swap Enum_Member_Value EFSWAP_B
source/safe: EF_swap Enum_Member_Value EFSWAP_C
```

## `cxx_more.fixed_enum_enumerator_values_swapped@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_swap_use']})
```text
binary/medium: EF_swap Enum_Member_Value EFSWAP_B
binary/medium: EF_swap Enum_Member_Value EFSWAP_C
source/safe: EF_swap Enum_Member_Value EFSWAP_B
source/safe: EF_swap Enum_Member_Value EFSWAP_C
```

## `cxx_more.fixed_enum_enumerator_values_swapped@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_swap_use']})
```text
breaking: enum_member_value_changed EF_swap::EFSWAP_B: Enum member value changed: EF_swap::EFSWAP_B (1 → 2)
breaking: enum_member_value_changed EF_swap::EFSWAP_C: Enum member value changed: EF_swap::EFSWAP_C (2 → 1)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.fixed_enum_enumerator_values_swapped@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ef_swap_use(EF_swap)' at edit_seed.cpp:174:1 has some indirect sub-type changes:
    parameter 1 of type 'enum EF_swap' has sub-type changes:
      type size hasn't changed
      2 enumerator changes:
        'EF_swap::EFSWAP_B' from value '1' to '2' at edit_seed.h:235:1
```

## `cxx_more.fixed_enum_enumerator_values_swapped@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.fixed_enum_enumerator_values_swapped@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_swap_use']})
```text
binary/medium: EF_swap Enum_Member_Value EFSWAP_B
binary/medium: EF_swap Enum_Member_Value EFSWAP_C
source/safe: EF_swap Enum_Member_Value EFSWAP_B
source/safe: EF_swap Enum_Member_Value EFSWAP_C
```

## `cxx_more.fixed_enum_enumerator_values_swapped@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_swap_use']})
```text
breaking: enum_member_value_changed EF_swap::EFSWAP_B: Enum member value changed: EF_swap::EFSWAP_B
breaking: enum_member_value_changed EF_swap::EFSWAP_C: Enum member value changed: EF_swap::EFSWAP_C
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.fixed_enum_enumerator_values_swapped@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_swap'], 'functions': ['ef_swap_use']})

## `cxx_more.fixed_enum_enumerator_renamed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_rename_use']})
```text
binary/low: EF_rename Enum_Member_Name 1
source/high: EF_rename Enum_Member_Name 1
```

## `cxx_more.fixed_enum_enumerator_renamed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_rename_use']})
```text
binary/low: EF_rename Enum_Member_Name 1
source/high: EF_rename Enum_Member_Name 1
```

## `cxx_more.fixed_enum_enumerator_renamed@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_rename_use']})
```text
api_break: enum_member_renamed EF_rename: Enum member renamed: EF_rename::EFRENAME_B → EFRENAME_BB (value=1)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.fixed_enum_enumerator_renamed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **unsupported**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ef_rename_use(EF_rename)' at edit_seed.cpp:175:1 has some indirect sub-type changes:
    parameter 1 of type 'enum EF_rename' has sub-type changes:
      type size hasn't changed
      1 enumerator deletion:
        'EF_rename::EFRENAME_B' value '1'
```

## `cxx_more.fixed_enum_enumerator_renamed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.fixed_enum_enumerator_renamed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_rename_use']})
```text
binary/low: EF_rename Enum_Member_Name 1
source/high: EF_rename Enum_Member_Name 1
```

## `cxx_more.fixed_enum_enumerator_renamed@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_rename_use']})
```text
api_break: enum_member_renamed EF_rename: Enum member renamed: EF_rename::EFRENAME_B → EFRENAME_BB (value=1)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.fixed_enum_enumerator_renamed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_rename'], 'functions': ['ef_rename_use']})

## `cxx_more.fixed_enum_enumerator_alias_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_alias_use']})
```text
binary/safe: EF_alias Added_Enum_Member EFALIAS_ALIAS
source/safe: EF_alias Added_Enum_Member EFALIAS_ALIAS
```

## `cxx_more.fixed_enum_enumerator_alias_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_alias_use']})
```text
binary/safe: EF_alias Added_Enum_Member EFALIAS_ALIAS
source/safe: EF_alias Added_Enum_Member EFALIAS_ALIAS
```

## `cxx_more.fixed_enum_enumerator_alias_added@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_alias_use']})
```text
compatible: enum_member_added EF_alias::EFALIAS_ALIAS: Enum member added: EF_alias::EFALIAS_ALIAS
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.fixed_enum_enumerator_alias_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_alias'], 'functions': ['ef_alias_use']})

## `cxx_more.fixed_enum_enumerator_alias_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.fixed_enum_enumerator_alias_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_alias_use']})
```text
binary/safe: EF_alias Added_Enum_Member EFALIAS_ALIAS
source/safe: EF_alias Added_Enum_Member EFALIAS_ALIAS
```

## `cxx_more.fixed_enum_enumerator_alias_added@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_alias_use']})
```text
compatible: enum_member_added EF_alias::EFALIAS_ALIAS: Enum member added: EF_alias::EFALIAS_ALIAS
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.fixed_enum_enumerator_alias_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_alias'], 'functions': ['ef_alias_use']})

## `cxx_more.fixed_enum_became_scoped@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_scoped'], 'functions': ['ef_scoped_use']})

## `cxx_more.fixed_enum_became_scoped@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_scoped'], 'functions': ['ef_scoped_use']})

## `cxx_more.fixed_enum_became_scoped@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_scoped_use']})
```text
api_break: enum_became_scoped EF_scoped: Enum became scoped: EF_scoped — unqualified enumerator lookup and implicit int conversion no longer compile
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.fixed_enum_became_scoped@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_scoped'], 'functions': ['ef_scoped_use']})

## `cxx_more.fixed_enum_became_scoped@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.fixed_enum_became_scoped@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_scoped'], 'functions': ['ef_scoped_use']})

## `cxx_more.fixed_enum_became_scoped@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_scoped_use']})
```text
api_break: enum_became_scoped EF_scoped: Enum became scoped: EF_scoped — unqualified enumerator lookup and implicit int conversion no longer compile
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.fixed_enum_became_scoped@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_scoped'], 'functions': ['ef_scoped_use']})

## `cxx_more.fixed_enum_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EF_added']})

## `cxx_more.fixed_enum_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EF_added']})

## `cxx_more.fixed_enum_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['EF_added']})

## `cxx_more.fixed_enum_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.fixed_enum_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EF_added']})

## `cxx_more.fixed_enum_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['EF_added']})

## `cxx_more.fixed_enum_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EF_removed']})

## `cxx_more.fixed_enum_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EF_removed']})

## `cxx_more.fixed_enum_removed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity'] (expected {'entity': ['EF_removed']})

## `cxx_more.fixed_enum_removed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.fixed_enum_removed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EF_removed']})

## `cxx_more.fixed_enum_removed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity'] (expected {'entity': ['EF_removed']})

## `cxx_more.fixed_enum_became_opaque@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_opaque_use']})
```text
binary/low: EF_opaque Enum_Member_Removed EFOPAQUE_A
binary/low: EF_opaque Enum_Member_Removed EFOPAQUE_B
binary/low: EF_opaque Enum_Member_Removed EFOPAQUE_C
source/high: EF_opaque Enum_Member_Removed EFOPAQUE_A
source/high: EF_opaque Enum_Member_Removed EFOPAQUE_B
source/high: EF_opaque Enum_Member_Removed EFOPAQUE_C
```

## `cxx_more.fixed_enum_became_opaque@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_opaque_use']})
```text
binary/low: EF_opaque Enum_Member_Removed EFOPAQUE_A
binary/low: EF_opaque Enum_Member_Removed EFOPAQUE_B
binary/low: EF_opaque Enum_Member_Removed EFOPAQUE_C
source/high: EF_opaque Enum_Member_Removed EFOPAQUE_A
source/high: EF_opaque Enum_Member_Removed EFOPAQUE_B
source/high: EF_opaque Enum_Member_Removed EFOPAQUE_C
```

## `cxx_more.fixed_enum_became_opaque@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_opaque_use']})
```text
breaking: enum_member_removed EF_opaque::EFOPAQUE_A: Enum member removed: EF_opaque::EFOPAQUE_A
breaking: enum_member_removed EF_opaque::EFOPAQUE_B: Enum member removed: EF_opaque::EFOPAQUE_B
breaking: enum_member_removed EF_opaque::EFOPAQUE_C: Enum member removed: EF_opaque::EFOPAQUE_C
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 3 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.fixed_enum_became_opaque@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ef_opaque_use(EF_opaque)' at edit_seed.cpp:178:1 has some indirect sub-type changes:
    parameter 1 of type 'enum EF_opaque' has sub-type changes:
      type size hasn't changed
      3 enumerator deletions:
        'EF_opaque::EFOPAQUE_A' value '0'
```

## `cxx_more.fixed_enum_became_opaque@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.fixed_enum_became_opaque@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ef_opaque_use']})
```text
binary/low: EF_opaque Enum_Member_Removed EFOPAQUE_A
binary/low: EF_opaque Enum_Member_Removed EFOPAQUE_B
binary/low: EF_opaque Enum_Member_Removed EFOPAQUE_C
source/high: EF_opaque Enum_Member_Removed EFOPAQUE_A
source/high: EF_opaque Enum_Member_Removed EFOPAQUE_B
source/high: EF_opaque Enum_Member_Removed EFOPAQUE_C
```

## `cxx_more.fixed_enum_became_opaque@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['ef_opaque_use']})
```text
breaking: enum_member_removed EF_opaque::EFOPAQUE_A: Enum member removed: EF_opaque::EFOPAQUE_A
breaking: enum_member_removed EF_opaque::EFOPAQUE_B: Enum member removed: EF_opaque::EFOPAQUE_B
breaking: enum_member_removed EF_opaque::EFOPAQUE_C: Enum member removed: EF_opaque::EFOPAQUE_C
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 3 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.fixed_enum_became_opaque@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EF_opaque'], 'functions': ['ef_opaque_use']})

## `cxx_more.enum_class_enumerator_inserted@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['ECINSERT_C'], 'functions': ['ec_insert_use']})
```text
binary/medium: EC_insert Enum_Member_Value ECINSERT_B
binary/medium: EC_insert Enum_Member_Value ECINSERT_C
binary/safe: EC_insert Added_Enum_Member ECINSERT_X
source/safe: EC_insert Added_Enum_Member ECINSERT_X
source/safe: EC_insert Enum_Member_Value ECINSERT_B
source/safe: EC_insert Enum_Member_Value ECINSERT_C
```

## `cxx_more.enum_class_enumerator_inserted@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['ECINSERT_C'], 'functions': ['ec_insert_use']})
```text
binary/medium: EC_insert Enum_Member_Value ECINSERT_B
binary/medium: EC_insert Enum_Member_Value ECINSERT_C
binary/safe: EC_insert Added_Enum_Member ECINSERT_X
source/safe: EC_insert Added_Enum_Member ECINSERT_X
source/safe: EC_insert Enum_Member_Value ECINSERT_B
source/safe: EC_insert Enum_Member_Value ECINSERT_C
```

## `cxx_more.enum_class_enumerator_inserted@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['ec_insert_use']})
```text
breaking: enum_member_value_changed EC_insert::ECINSERT_B: Enum member value changed: EC_insert::ECINSERT_B (1 → 2)
breaking: enum_member_value_changed EC_insert::ECINSERT_C: Enum member value changed: EC_insert::ECINSERT_C (2 → 3)
compatible: enum_member_added EC_insert::ECINSERT_X: Enum member added: EC_insert::ECINSERT_X
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.enum_class_enumerator_inserted@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
- missed details: ['fields'] (expected {'fields': ['ECINSERT_C']})
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ec_insert_use(EC_insert)' at edit_seed.cpp:179:1 has some indirect sub-type changes:
    parameter 1 of type 'enum EC_insert' has sub-type changes:
      type size hasn't changed
      1 enumerator insertion:
        'EC_insert::ECINSERT_X' value '1'
```

## `cxx_more.enum_class_enumerator_inserted@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.enum_class_enumerator_inserted@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['ECINSERT_C'], 'functions': ['ec_insert_use']})
```text
binary/medium: EC_insert Enum_Member_Value ECINSERT_B
binary/medium: EC_insert Enum_Member_Value ECINSERT_C
binary/safe: EC_insert Added_Enum_Member ECINSERT_X
source/safe: EC_insert Added_Enum_Member ECINSERT_X
source/safe: EC_insert Enum_Member_Value ECINSERT_B
source/safe: EC_insert Enum_Member_Value ECINSERT_C
```

## `cxx_more.enum_class_enumerator_inserted@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['ec_insert_use']})
```text
breaking: enum_member_value_changed EC_insert::ECINSERT_B: Enum member value changed: EC_insert::ECINSERT_B
breaking: enum_member_value_changed EC_insert::ECINSERT_C: Enum member value changed: EC_insert::ECINSERT_C
compatible: enum_member_added EC_insert::ECINSERT_X: Enum member added: EC_insert::ECINSERT_X
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.enum_class_enumerator_inserted@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['EC_insert'], 'fields': ['ECINSERT_C'], 'functions': ['ec_insert_use']})

## `cxx_more.enum_class_enumerator_values_swapped@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['1', 'ECSWAP_C'], 'functions': ['ec_swap_use']})
```text
binary/medium: EC_swap Enum_Member_Value ECSWAP_B
binary/medium: EC_swap Enum_Member_Value ECSWAP_C
source/safe: EC_swap Enum_Member_Value ECSWAP_B
source/safe: EC_swap Enum_Member_Value ECSWAP_C
```

## `cxx_more.enum_class_enumerator_values_swapped@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['1', 'ECSWAP_C'], 'functions': ['ec_swap_use']})
```text
binary/medium: EC_swap Enum_Member_Value ECSWAP_B
binary/medium: EC_swap Enum_Member_Value ECSWAP_C
source/safe: EC_swap Enum_Member_Value ECSWAP_B
source/safe: EC_swap Enum_Member_Value ECSWAP_C
```

## `cxx_more.enum_class_enumerator_values_swapped@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['1', 'ECSWAP_C'], 'functions': ['ec_swap_use']})
```text
breaking: enum_member_value_changed EC_swap::ECSWAP_B: Enum member value changed: EC_swap::ECSWAP_B (1 → 2)
breaking: enum_member_value_changed EC_swap::ECSWAP_C: Enum member value changed: EC_swap::ECSWAP_C (2 → 1)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.enum_class_enumerator_values_swapped@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
- missed details: ['fields'] (expected {'fields': ['1', 'ECSWAP_C']})
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ec_swap_use(EC_swap)' at edit_seed.cpp:180:1 has some indirect sub-type changes:
    parameter 1 of type 'enum EC_swap' has sub-type changes:
      type size hasn't changed
      2 enumerator changes:
        'EC_swap::ECSWAP_B' from value '1' to '2' at edit_seed.h:248:1
```

## `cxx_more.enum_class_enumerator_values_swapped@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.enum_class_enumerator_values_swapped@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['1', 'ECSWAP_C'], 'functions': ['ec_swap_use']})
```text
binary/medium: EC_swap Enum_Member_Value ECSWAP_B
binary/medium: EC_swap Enum_Member_Value ECSWAP_C
source/safe: EC_swap Enum_Member_Value ECSWAP_B
source/safe: EC_swap Enum_Member_Value ECSWAP_C
```

## `cxx_more.enum_class_enumerator_values_swapped@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['1', 'ECSWAP_C'], 'functions': ['ec_swap_use']})
```text
breaking: enum_member_value_changed EC_swap::ECSWAP_B: Enum member value changed: EC_swap::ECSWAP_B
breaking: enum_member_value_changed EC_swap::ECSWAP_C: Enum member value changed: EC_swap::ECSWAP_C
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 2 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.enum_class_enumerator_values_swapped@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['EC_swap'], 'fields': ['1', 'ECSWAP_C'], 'functions': ['ec_swap_use']})

## `cxx_more.enum_class_enumerator_renamed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['ECRENAME_C'], 'functions': ['ec_rename_use']})
```text
binary/low: EC_rename Enum_Member_Name 1
source/high: EC_rename Enum_Member_Name 1
```

## `cxx_more.enum_class_enumerator_renamed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['ECRENAME_C'], 'functions': ['ec_rename_use']})
```text
binary/low: EC_rename Enum_Member_Name 1
source/high: EC_rename Enum_Member_Name 1
```

## `cxx_more.enum_class_enumerator_renamed@dwarf+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['ECRENAME_C'], 'functions': ['ec_rename_use']})
```text
api_break: enum_member_renamed EC_rename: Enum member renamed: EC_rename::ECRENAME_B → ECRENAME_BB (value=1)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.enum_class_enumerator_renamed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **unsupported**; exit bits ['abi_change']
- missed details: ['fields'] (expected {'fields': ['ECRENAME_C']})
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ec_rename_use(EC_rename)' at edit_seed.cpp:181:1 has some indirect sub-type changes:
    parameter 1 of type 'enum EC_rename' has sub-type changes:
      type size hasn't changed
      1 enumerator deletion:
        'EC_rename::ECRENAME_B' value '1'
```

## `cxx_more.enum_class_enumerator_renamed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.enum_class_enumerator_renamed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['ECRENAME_C'], 'functions': ['ec_rename_use']})
```text
binary/low: EC_rename Enum_Member_Name 1
source/high: EC_rename Enum_Member_Name 1
```

## `cxx_more.enum_class_enumerator_renamed@stripped+headers` · abicheck compare
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['ECRENAME_C'], 'functions': ['ec_rename_use']})
```text
api_break: enum_member_renamed EC_rename: Enum member renamed: EC_rename::ECRENAME_B → ECRENAME_BB (value=1)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.enum_class_enumerator_renamed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['EC_rename'], 'fields': ['ECRENAME_C'], 'functions': ['ec_rename_use']})

## `cxx_more.enum_class_enumerator_alias_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['ECALIAS_B', 'ECALIAS_C'], 'functions': ['ec_alias_use']})
```text
binary/safe: EC_alias Added_Enum_Member ECALIAS_ALIAS
source/safe: EC_alias Added_Enum_Member ECALIAS_ALIAS
```

## `cxx_more.enum_class_enumerator_alias_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['ECALIAS_B', 'ECALIAS_C'], 'functions': ['ec_alias_use']})
```text
binary/safe: EC_alias Added_Enum_Member ECALIAS_ALIAS
source/safe: EC_alias Added_Enum_Member ECALIAS_ALIAS
```

## `cxx_more.enum_class_enumerator_alias_added@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['ECALIAS_B', 'ECALIAS_C'], 'functions': ['ec_alias_use']})
```text
compatible: enum_member_added EC_alias::ECALIAS_ALIAS: Enum member added: EC_alias::ECALIAS_ALIAS
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.enum_class_enumerator_alias_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['EC_alias'], 'fields': ['ECALIAS_B', 'ECALIAS_C'], 'functions': ['ec_alias_use']})

## `cxx_more.enum_class_enumerator_alias_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.enum_class_enumerator_alias_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**; sides {'binary': 'COMPATIBLE', 'source': 'COMPATIBLE'}
- missed details: ['fields', 'functions'] (expected {'fields': ['ECALIAS_B', 'ECALIAS_C'], 'functions': ['ec_alias_use']})
```text
binary/safe: EC_alias Added_Enum_Member ECALIAS_ALIAS
source/safe: EC_alias Added_Enum_Member ECALIAS_ALIAS
```

## `cxx_more.enum_class_enumerator_alias_added@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['fields', 'functions'] (expected {'fields': ['ECALIAS_B', 'ECALIAS_C'], 'functions': ['ec_alias_use']})
```text
compatible: enum_member_added EC_alias::ECALIAS_ALIAS: Enum member added: EC_alias::ECALIAS_ALIAS
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
```

## `cxx_more.enum_class_enumerator_alias_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'fields', 'functions'] (expected {'entity': ['EC_alias'], 'fields': ['ECALIAS_B', 'ECALIAS_C'], 'functions': ['ec_alias_use']})

## `cxx_more.enum_class_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EC_added']})

## `cxx_more.enum_class_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EC_added']})

## `cxx_more.enum_class_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['EC_added']})

## `cxx_more.enum_class_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.enum_class_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EC_added']})

## `cxx_more.enum_class_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['EC_added']})

## `cxx_more.enum_class_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EC_removed']})

## `cxx_more.enum_class_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EC_removed']})

## `cxx_more.enum_class_removed@dwarf+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity'] (expected {'entity': ['EC_removed']})

## `cxx_more.enum_class_removed@stripped+headers` · ABI Dumper + ABICC
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.enum_class_removed@stripped+headers` · ABICC (XML descriptors)
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity'] (expected {'entity': ['EC_removed']})

## `cxx_more.enum_class_removed@stripped+headers` · libabigail abidiff
- expected: API_BREAK..API_BREAK (source_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **unsupported**; exit bits []
- missed details: ['entity'] (expected {'entity': ['EC_removed']})

## `cxx_more.enum_class_became_opaque@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ec_opaque_use']})
```text
binary/low: EC_opaque Enum_Member_Removed ECOPAQUE_A
binary/low: EC_opaque Enum_Member_Removed ECOPAQUE_B
binary/low: EC_opaque Enum_Member_Removed ECOPAQUE_C
source/high: EC_opaque Enum_Member_Removed ECOPAQUE_A
source/high: EC_opaque Enum_Member_Removed ECOPAQUE_B
source/high: EC_opaque Enum_Member_Removed ECOPAQUE_C
```

## `cxx_more.enum_class_became_opaque@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ec_opaque_use']})
```text
binary/low: EC_opaque Enum_Member_Removed ECOPAQUE_A
binary/low: EC_opaque Enum_Member_Removed ECOPAQUE_B
binary/low: EC_opaque Enum_Member_Removed ECOPAQUE_C
source/high: EC_opaque Enum_Member_Removed ECOPAQUE_A
source/high: EC_opaque Enum_Member_Removed ECOPAQUE_B
source/high: EC_opaque Enum_Member_Removed ECOPAQUE_C
```

## `cxx_more.enum_class_became_opaque@dwarf+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['ec_opaque_use']})
```text
breaking: enum_member_removed EC_opaque::ECOPAQUE_A: Enum member removed: EC_opaque::ECOPAQUE_A
breaking: enum_member_removed EC_opaque::ECOPAQUE_B: Enum member removed: EC_opaque::ECOPAQUE_B
breaking: enum_member_removed EC_opaque::ECOPAQUE_C: Enum member removed: EC_opaque::ECOPAQUE_C
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 3 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.enum_class_became_opaque@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 1 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 function with some indirect sub-type change:
  [C] 'function int ec_opaque_use(EC_opaque)' at edit_seed.cpp:183:1 has some indirect sub-type changes:
    parameter 1 of type 'enum EC_opaque' has sub-type changes:
      type size hasn't changed
      3 enumerator deletions:
        'EC_opaque::ECOPAQUE_A' value '0'
```

## `cxx_more.enum_class_became_opaque@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.enum_class_became_opaque@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: API_BREAK → **wrong**; sides {'binary': 'ADVISORY', 'source': 'INCOMPATIBLE'}
- missed details: ['functions'] (expected {'functions': ['ec_opaque_use']})
```text
binary/low: EC_opaque Enum_Member_Removed ECOPAQUE_A
binary/low: EC_opaque Enum_Member_Removed ECOPAQUE_B
binary/low: EC_opaque Enum_Member_Removed ECOPAQUE_C
source/high: EC_opaque Enum_Member_Removed ECOPAQUE_A
source/high: EC_opaque Enum_Member_Removed ECOPAQUE_B
source/high: EC_opaque Enum_Member_Removed ECOPAQUE_C
```

## `cxx_more.enum_class_became_opaque@stripped+headers` · abicheck compare
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**
- missed details: ['functions'] (expected {'functions': ['ec_opaque_use']})
```text
breaking: enum_member_removed EC_opaque::ECOPAQUE_A: Enum member removed: EC_opaque::ECOPAQUE_A
breaking: enum_member_removed EC_opaque::ECOPAQUE_B: Enum member removed: EC_opaque::ECOPAQUE_B
breaking: enum_member_removed EC_opaque::ECOPAQUE_C: Enum member removed: EC_opaque::ECOPAQUE_C
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: soname_bump_recommended DT_SONAME: 3 binary-incompatible change(s) detected but SONAME remains 'libedit.so'. Consumers linked against 'libedit.so' w
```

## `cxx_more.enum_class_became_opaque@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['EC_opaque'], 'functions': ['ec_opaque_use']})

## `cxx_more.object_shrank@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 1 Changed, 0 Added variable
1 Changed variable:
  [C] 'long long int g_vshr' was changed to 'int g_vshr' at edit_seed.h:257:1:
    size of symbol changed from 8 to 4
    type of variable changed:
      type name changed from 'long long int' to 'int'
      type size changed from 64 to 32 (in bits)
```

## `cxx_more.object_shrank@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.object_shrank@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['g_vshr']})

## `cxx_more.object_retyped_same_size@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: g_vsame Global_Data_Type
source/low: g_vsame Global_Data_Type
```

## `cxx_more.object_retyped_same_size@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: g_vsame Global_Data_Type
source/low: g_vsame Global_Data_Type
```

## `cxx_more.object_retyped_same_size@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; exit bits ['abi_change']
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 1 Changed, 0 Added variable
1 Changed variable:
  [C] 'int g_vsame' was changed to 'unsigned int g_vsame' at edit_seed.h:258:1:
    type of variable changed:
      type name changed from 'int' to 'unsigned int'
      type size hasn't changed
```

## `cxx_more.object_retyped_same_size@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.object_retyped_same_size@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: ADVISORY → **advisory**; sides {'binary': 'ADVISORY', 'source': 'ADVISORY'}
```text
binary/low: g_vsame Global_Data_Type
source/low: g_vsame Global_Data_Type
```

## `cxx_more.object_retyped_same_size@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['g_vsame']})

## `cxx_more.object_became_weak@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.object_became_weak@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.object_became_weak@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.object_became_weak@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.object_became_weak@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.object_became_weak@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `cxx_more.object_renamed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.object_became_inline_variable@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; sides {'binary': 'INCOMPATIBLE', 'source': 'NO_CHANGE'}
```text
binary: removed g_vinl
```

## `cxx_more.object_became_inline_variable@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
```text
binary: removed g_vinl
source: removed g_vinl
source: added _Z6g_vinl
```

## `cxx_more.object_became_inline_variable@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['g_vinl']})

## `cxx_more.object_became_inline_variable@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.object_became_inline_variable@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **wrong**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
```text
binary: removed g_vinl
source: removed g_vinl
source: added _Z6g_vinl
```

## `cxx_more.object_became_inline_variable@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity'] (expected {'entity': ['g_vinl']})

## `c_elf.object_moved_version_node@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.typedef_retargeted_same_size@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['TdS'], 'functions': ['tds_use']})
```text
binary: removed _Z7tds_usei
binary: added _Z7tds_usej
binary/high: _Z7tds_usei Symbol_Changed_Parameters
source: removed _Z7tds_usei
source: added _Z7tds_usej
source/medium: _Z7tds_usei Symbol_Changed_Parameters
```

## `cxx_more.typedef_retargeted_same_size@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['TdS'], 'functions': ['tds_use']})
```text
binary: removed _Z7tds_usei
binary: added _Z7tds_usej
binary/high: _Z7tds_usei Symbol_Changed_Parameters
source: removed _Z7tds_usei
source: added _Z7tds_usej
source/medium: _Z7tds_usei Symbol_Changed_Parameters
```

## `cxx_more.typedef_retargeted_same_size@dwarf+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity'] (expected {'entity': ['TdS']})
```text
Functions changes summary: 1 Removed, 0 Changed, 1 Added functions
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
1 Removed function:
  [D] 'function int tds_use(TdS)'    {_Z7tds_usei}
1 Added function:
  [A] 'function int tds_use(TdS)'    {_Z7tds_usej}
```

## `cxx_more.typedef_retargeted_same_size@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.typedef_retargeted_same_size@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; sides {'binary': 'INCOMPATIBLE', 'source': 'INCOMPATIBLE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['TdS'], 'functions': ['tds_use']})
```text
binary: removed _Z7tds_usei
binary: added _Z7tds_usej
binary/high: _Z7tds_usei Symbol_Changed_Parameters
source: removed _Z7tds_usei
source: added _Z7tds_usej
source/medium: _Z7tds_usei Symbol_Changed_Parameters
```

## `cxx_more.typedef_retargeted_same_size@stripped+headers` · libabigail abidiff
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: BREAKING → **correct**; exit bits ['abi_change', 'incompatible_change']
- missed details: ['entity', 'functions'] (expected {'entity': ['TdS'], 'functions': ['tds_use']})
```text
Functions changes summary: 0 Removed, 0 Changed, 0 Added function
Variables changes summary: 0 Removed, 0 Changed, 0 Added variable
Function symbols changes summary: 1 Removed, 1 Added function symbols not referenced by debug info
Variable symbols changes summary: 0 Removed, 0 Added variable symbol not referenced by debug info
1 Removed function symbol not referenced by debug info:
  [D] _Z7tds_usei
1 Added function symbol not referenced by debug info:
  [A] _Z7tds_usej
```

## `cxx_more.typedef_added@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.typedef_respelled_as_alias@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.template_added@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.template_param_added_defaulted@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.template_param_removed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.template_nontype_param_retyped@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.template_instantiation_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.template_instantiation_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.template_specialization_added@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['tps_use'], 'functions': ['tps_use']})

## `cxx_more.template_specialization_added@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['tps_use'], 'functions': ['tps_use']})

## `cxx_more.template_specialization_added@dwarf+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['tps_use'], 'functions': ['tps_use']})
```text
compatible: func_added _Z3tpsIiEiT_: New public function: tps
compatible: symbol_binding_strengthened _Z3tpsIiEiT_: Symbol binding changed: _Z3tpsIiEiT_ (weak → global)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: public_surface_grew <surface>: public surface grew: 688 → 689 declarations (+1)
```

## `cxx_more.template_specialization_added@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['tps_use'], 'functions': ['tps_use']})

## `cxx_more.template_specialization_added@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.template_specialization_added@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}
- missed details: ['entity', 'functions'] (expected {'entity': ['tps_use'], 'functions': ['tps_use']})

## `cxx_more.template_specialization_added@stripped+headers` · abicheck compare
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: COMPATIBLE → **correct**
- missed details: ['entity', 'functions'] (expected {'entity': ['tps_use'], 'functions': ['tps_use']})
```text
compatible: func_added _Z3tpsIiEiT_: New public function: tps
compatible: symbol_binding_strengthened _Z3tpsIiEiT_: Symbol binding changed: _Z3tpsIiEiT_ (weak → global)
risk: exported_not_public _Z3tpsIiEiT_: Symbol '_Z3tpsIiEiT_' is an exported C++ template instantiation with no matching public declaration (the public headers 
risk: exported_not_public _Z4kfamI6ktag_aEiv: Symbol '_Z4kfamI6ktag_aEiv' is this library's own instantiation of an external (standard/third-party) template ove
risk: exported_not_public _ZZ5kmakevENKUliE_clEi: Symbol '_ZZ5kmakevENKUliE_clEi' is exported by the binary but declared in no public header. It is accidental A
compatible: public_surface_grew <surface>: public surface grew: 688 → 689 declarations (+1)
```

## `cxx_more.template_specialization_added@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE..COMPATIBLE_WITH_RISK (compatible; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []
- missed details: ['entity', 'functions'] (expected {'entity': ['tps_use'], 'functions': ['tps_use']})

## `cxx_more.template_specialization_removed@dwarf+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.template_specialization_removed@dwarf+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `cxx_more.template_specialization_removed@stripped+headers` · ABI Dumper + ABICC
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.template_specialization_removed@stripped+headers` · ABICC (XML descriptors)
- expected: BREAKING..BREAKING (abi_break; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

- `c_elf.l3_exceptions_enabled@dwarf+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `c_elf.l3_exceptions_enabled@stripped+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `c_elf.l3_tls_model_local_dynamic@dwarf+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `c_elf.l3_tls_model_local_dynamic@stripped+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `c_elf.l3_lto_enabled@dwarf+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `c_elf.l3_lto_enabled@stripped+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `c_elf.l3_sanitizer_enabled@dwarf+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `c_elf.l3_sanitizer_enabled@stripped+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `c_elf.l3_asan_enabled@dwarf+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `c_elf.l3_asan_enabled@stripped+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `c_elf.l3_struct_packing_8@dwarf+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `c_elf.l3_struct_packing_8@stripped+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `c_elf.l3_language_standard_raised@dwarf+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `c_elf.l3_language_standard_raised@stripped+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `cxx_alt.l3_threadsafe_statics_disabled@dwarf+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `cxx_alt.l3_threadsafe_statics_disabled@stripped+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `cxx_alt.l3_rtti_disabled@dwarf+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `cxx_alt.l3_rtti_disabled@stripped+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `cxx_alt.l3_stdlib_assertions@dwarf+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `cxx_alt.l3_stdlib_assertions@stripped+headers`: not run (infeasible: the flag is recorded only in the build's compile commands (L3); needs a build_data config)
- `cxx_alt.l3_whole_program_vtables@dwarf+headers`: not run (infeasible: -fwhole-program-vtables is a clang option)
- `cxx_alt.l3_whole_program_vtables@stripped+headers`: not run (infeasible: -fwhole-program-vtables is a clang option)
- `c_elf.import_left_unprovided@dwarf+headers`: not run (infeasible: whether an import has a provider is a fact about the DT_NEEDED closure; needs a follow_deps config)
- `c_elf.import_left_unprovided@stripped+headers`: not run (infeasible: whether an import has a provider is a fact about the DT_NEEDED closure; needs a follow_deps config)
## `c_elf.glibc_floor_raised@dwarf+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.glibc_floor_raised@dwarf+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.glibc_floor_raised@dwarf+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

## `c_elf.glibc_floor_raised@stripped+headers` · ABI Dumper + ABICC
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.glibc_floor_raised@stripped+headers` · ABICC (XML descriptors)
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; sides {'binary': 'NO_CHANGE', 'source': 'NO_CHANGE'}

## `c_elf.glibc_floor_raised@stripped+headers` · libabigail abidiff
- expected: COMPATIBLE_WITH_RISK..COMPATIBLE_WITH_RISK (risk; operator language-rule expectation (EditOp.base + rules))
- tool decision: NO_CHANGE → **no_signal**; exit bits []

- `cxx_src.src_macro_value_changed@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_macro_value_changed@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_macro_removed@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_macro_removed@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_default_argument_changed@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_default_argument_changed@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_inline_body_changed@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_inline_body_changed@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_template_body_changed@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_template_body_changed@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_uninstantiated_template_removed@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_uninstantiated_template_removed@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_public_entry_calls_internal@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_public_entry_calls_internal@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_public_entry_depends_on_hidden@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_public_entry_depends_on_hidden@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_virtual_dispatch_target_added@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_virtual_dispatch_target_added@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_public_function_added@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_public_function_added@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_public_function_removed@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_public_function_removed@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_undocumented_export_added@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_src.src_undocumented_export_added@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_tree.tree_internal_rtti_exported@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_tree.tree_internal_rtti_exported@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_tree.tree_private_declaration_exported@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_tree.tree_private_declaration_exported@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_tree.tree_type_definition_diverges_per_tu@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_tree.tree_type_definition_diverges_per_tu@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_tree.tree_anonymous_type_coordinates_shifted@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_tree.tree_anonymous_type_coordinates_shifted@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_tree.tree_pointee_type_renamed@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_tree.tree_pointee_type_renamed@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_tree.tree_private_pointee_type_renamed@dwarf+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
- `cxx_tree.tree_private_pointee_type_renamed@stripped+headers`: not run (infeasible: only source replay or the source graph sees it; needs a sources config)
## `c_core.control_identity@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; identity rebuild)
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_classes.control_identity@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; identity rebuild)
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_stdlib.control_identity@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; identity rebuild)
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf.control_identity@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; identity rebuild)
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `c_elf_alt.control_identity@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; identity rebuild)
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_alt.control_identity@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; identity rebuild)
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_more.control_identity@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; identity rebuild)
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_src.control_identity@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; identity rebuild)
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

## `cxx_tree.control_identity@stripped+headers` · ABI Dumper + ABICC
- expected: NO_CHANGE..NO_CHANGE (unchanged; identity rebuild)
- tool decision: None → **unsupported**
- reason: abi-dumper needs DWARF; stripped library (exit 10: ERROR: can't find debug info in object(s))

